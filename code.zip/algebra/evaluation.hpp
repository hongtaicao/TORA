/*
 * evaluation.hpp
 *
 *  Created on: 2020-4-6
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_EVALUATION_HPP_
#define ALGEBRA_EVALUATION_HPP_

#include <string>
#include <vector>

#include "algebra/argparser.hpp"
#include "algebra/basetype.hpp"
#include "algebra/construction.hpp"
#include "algebra/io/logger.hpp"

namespace algebra {

class Evaluation {
public:
    Evaluation(ArgParser &);
    ~Evaluation() {
        delete this->graph_;
    }

    void EvaluateAdjacency();
    void EvaluateSubgraphMatching();
    void EvaluateExpression();

private:
    typedef typename Construction::graph_t graph_t;

    double EvaluateConstruct(Construction *, const size_type);
    double EvaluateLeaf(Construction *, const size_type);
    // the following evaluate one or more expressions at the same time
    size_type ExecuteAdjacency(Construction *, size_type &);
    size_type ExecuteInducedSubgraphMatching(Construction *, size_type &);
    // the following evaluate the given index directly
    size_type ExecuteSingleAdjacency(Construction *, const size_type, double &);
    size_type ExecuteSingleInducedSubgraphMatching(Construction *,
            const size_type, double &);

    inline void WriteLogger(const size_type best_cursor) {
        this->logger_best_.CopyFrom(this->logger_detail_, best_cursor);
        this->logger_best_.WriteFile();
        this->logger_detail_.WriteFile();
    }

    ArgParser &argparser_;
    Logger logger_best_;
    Logger logger_detail_;
    // status variable
    graph_t *graph_;
    double expression_cost_;
};

namespace execution {

void ReportAdjacency(Logger &, const double, const double, const size_type,
        const std::string &, const std::string &, const std::string &);
void ReportConstruction(Logger &, const ArgParser &, const double,
        const size_type, const size_type, const std::string &);
void ReportLeaf(Logger &, const ArgParser &, const double, const int);
void ReportSavePercent(Logger &, const std::vector<double> &);
void ReportSubgraph(Logger &, const ArgParser &, const double, const double,
        const size_type, const std::string &, const std::string &);
void ReportSubnode(Logger &, const double, const double, const size_type,
        const size_type, const std::string &);
bool ShouldSkip(int, const Construction *, const size_type);

} // namespace execution

} // namespace algebra

#endif /* ALGEBRA_EVALUATION_HPP_ */
