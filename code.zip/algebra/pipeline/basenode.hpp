/*
 * basenode.hpp
 *
 *  Created on: 2020-3-2 11:45
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_PIPELINE_BASENODE_HPP_
#define ALGEBRA_PIPELINE_BASENODE_HPP_

#include <iostream>
#include <memory>
#include <string>

#include "algebra/basetype.hpp"
#include "algebra/graphnode/basenode.hpp"

namespace pipeline {

typedef graphnode::BaseOperand_t BaseOperand_t;
typedef graphnode::data_size_t data_size_t;
typedef graphnode::relation_t relation_t;
typedef graphnode::size_type size_type;

typedef algebra::T_1D<data_size_t> data_size_1D_t;
typedef std::shared_ptr<data_size_1D_t> tuple_t;

class BaseNode {
public:
    explicit BaseNode(const std::string &represent)
            : cursor_(0), represent_(represent) {
#ifndef NDEBUG
        std::cout << "PipelineBaseNode Constructor: " << this << " "
                << this->represent_ << std::endl;
#endif
    }
    virtual ~BaseNode() {
#ifndef NDEBUG
        std::cout << "~PipelineBaseNode: " << this << ":" << this->represent_
                << std::endl;
#endif
    }

    BaseNode(BaseNode *other)
            : cursor_(0), represent_(other->represent_) {
#ifndef NDEBUG
        std::cout << "PipelineBaseNode Copy Constructor: " << this << " "
                << this->represent_ << std::endl;
#endif
    }

    BaseNode(const BaseNode &) = delete;
    BaseNode &operator=(const BaseNode &) = delete;

    // external api
    virtual BaseOperand_t *Evaluate() = 0;
    inline const std::string &GetRepresent() const {
        return this->represent_;
    }
    virtual void Print(size_type leading_space) {
        while (leading_space > 0) {
            std::cout << " ";
            leading_space--;
        }
        std::cout << this << " " << this->represent_ << std::endl;
    }
    // should maintain its own cursor_
    virtual BaseNode *ShallowCopy() = 0;
    inline void SetRepresent(const std::string &represent) {
        this->represent_ = represent;
    }

    // use within pipeline
    inline void AdvanceCursor() {
        this->cursor_++;
    }
    inline size_type GetCursor() {
        return this->cursor_;
    }
    virtual inline tuple_t Front() {
        return this->NextAt(this->GetCursor());
    }
    virtual inline tuple_t FrontAt(size_type cursor) {
        return this->NextAt(cursor);
    }
    virtual inline tuple_t Next() {
        // advance the corresponding cursor
        tuple_t tuple = this->NextAt(this->GetCursor());
        this->AdvanceCursor();
        return tuple;
    }
    virtual tuple_t NextAt(size_type) = 0;
    inline size_type SetCursor(size_type cursor) {
        size_type prev_cursor = this->cursor_;
        this->cursor_ = cursor;
        return prev_cursor;
    }

    friend tuple_t PipelineMask(BaseNode *, relation_t *);
    friend tuple_t PipelineMerge(BaseNode *, relation_t *);
    friend tuple_t PipelineMinus(BaseNode *, relation_t *);

private:
    // cursor to the last read position
    // advance cursor first, then read the new data
    size_type cursor_;
    std::string represent_;
};

}

#endif /* ALGEBRA_PIPELINE_BASENODE_HPP_ */
