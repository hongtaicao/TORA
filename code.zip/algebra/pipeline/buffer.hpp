/*
 * buffer.hpp
 *
 *  Created on: 2020-03-2 13:25
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_PIPELINE_BUFFER_HPP_
#define ALGEBRA_PIPELINE_BUFFER_HPP_

#include <assert.h>
#include <unordered_set>

#include "algebra/basetype.hpp"
#include "algebra/pipeline/basenode.hpp"

namespace pipeline {

class Buffer {
public:
    Buffer(BaseNode *basenode) {
        this->node_pool_.insert(basenode);
    }
    ~Buffer() {
        //assert(this->node_pool_.size() == 0);
        //assert(this->result_pool_.size() == 0);
    }
    Buffer(const Buffer&) = delete;
    Buffer &operator=(const Buffer&) = delete;

    inline void Add(size_type cursor, const tuple_t &data) {
        // adjust result pool size
        if (this->result_pool_.size() % 10000 == 9999) {
            size_type min_read = 0;
            for (const auto &node : this->node_pool_) {
                min_read = std::min(min_read, node->GetCursor());
            }
            size_type min_add = 0;
            for (const auto &pair : this->result_pool_) {
                min_add = std::min(min_add, pair.first);
            }
            // delete result [min_add, min_read]
            for (size_type key = min_add; key <= min_read; key++) {
                this->result_pool_.erase(key);
            }
        }
        // add to result pool
        this->result_pool_[cursor] = data;
    }
    inline void Erase(BaseNode *basenode) {
        this->node_pool_.erase(basenode);
        if (this->node_pool_.size() == 0) {
            this->result_pool_.clear();
        }
    }
    inline tuple_t Get(BaseNode *basenode, size_type pointer) {
        if (this->node_pool_.count(basenode) == 0) {
            return std::make_shared<data_size_1D_t>();
        }
        return this->result_pool_[pointer];
    }
    inline bool Has(BaseNode *basenode, size_type pointer) {
        return (this->node_pool_.count(basenode) == 0)
                || (this->result_pool_.count(pointer) != 0);
    }
    inline void Insert(BaseNode *basenode) {
        this->node_pool_.insert(basenode);
    }

private:
    std::unordered_set<BaseNode *> node_pool_;
    std::unordered_map<size_type, tuple_t> result_pool_;
};

}

#endif /* ALGEBRA_PIPELINE_BUFFER_HPP_ */
