/*
 * childnode.hpp
 *
 *  Created on: 2020-3-4 20:12
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_PIPELINE_CHILDNODE_HPP_
#define ALGEBRA_PIPELINE_CHILDNODE_HPP_

#include "algebra/pipeline/basenode.hpp"
#include "algebra/pipeline/graphnode.hpp"

namespace pipeline {

// error: 'pipeline::BaseNode' is an inaccessible base of 'pipeline::ChildNode'
// https://stackoverflow.com/a/13870040/11193802
// default is private inheritance
class ChildNode: public BaseNode {
public:
    ChildNode(BaseNode *parent)
            : BaseNode(parent), cache_(nullptr), parent_(parent) {
    }
    virtual ~ChildNode() {
    }

    // exposed API
    inline BaseOperand_t *Evaluate() {
        if (this->cache_ == nullptr) {
            this->cache_ = this->parent_->Evaluate()->ShallowCopy();
        }
        return this->cache_;
    }
    inline void Print(size_type leading_space) {
        BaseNode::Print(leading_space);
    }
    inline BaseNode *ShallowCopy() {
        return this->parent_->ShallowCopy();
    }

    // use within pipeline}
    inline tuple_t NextAt(size_type cursor) {
        // call parent NextAt with correct context
        return this->parent_->NextAt(cursor);
    }

private:
    BaseOperand_t *cache_;
    BaseNode *parent_;
};

class BinaryNode;
class ComplementNode;

class BinaryChild: public ChildNode {
public:
    BinaryChild(BinaryNode *parent)
            : ChildNode(parent), parent_(parent) {
    }

    inline tuple_t Front() {
        return this->parent_->NextAt(this, this->GetCursor(), this->parent_);
    }
    inline tuple_t NextAt(size_type cursor) {
        return this->parent_->NextAt(this, cursor, this->parent_);
    }

private:
    BinaryNode *parent_;
};

class ComplementChild: public ChildNode {
public:
    ComplementChild(ComplementNode *parent)
            : ChildNode(parent), parent_(parent) {
    }

    inline tuple_t Front() {
        return this->parent_->NextAt(this, this->GetCursor(), this->parent_);
    }
    inline tuple_t NextAt(size_type cursor) {
        return this->parent_->NextAt(this, cursor, this->parent_);
    }

private:
    ComplementNode *parent_;
};

}

#endif /* ALGEBRA_PIPELINE_CHILDNODE_HPP_ */
