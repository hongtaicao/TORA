/*
 * graphnode.hpp
 *
 *  Created on: 2020-3-2 12:05
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_PIPELINE_GRAPHNODE_HPP_
#define ALGEBRA_PIPELINE_GRAPHNODE_HPP_

#include <algorithm>
#include <memory>

#include "algebra/basetype.hpp"
#include "algebra/graphnode/basenode.hpp"
#include "algebra/operand/relation.hpp"
#include "algebra/pipeline/basenode.hpp"
#include "algebra/pipeline/buffer.hpp"

namespace pipeline {

typedef algebra::OPERATION OPERATION;

// represent graph node using algebra operation
class AdjacencyNode: public BaseNode {
public:
    typedef algebra::data_size_2D_t data_size_2D_t;
    typedef algebra::rlt::AscendVector AscendVector;

    AdjacencyNode(const std::string &represent, data_size_2D_t *edgelist)
            : BaseNode(represent), edgelist_(edgelist), sorted_(false),
              cache_(nullptr) {
    }

    // exposed API
    inline BaseOperand_t *Evaluate() {
        if (this->cache_ == nullptr) {
            relation_t *result = new relation_t(algebra::ADJACENCY_OP,
                    nullptr);
            result->data_ = this->Sorted();
            this->cache_ = result;
        }
        return this->cache_;
    }
    BaseNode *ShallowCopy();

    // within pipeline
    inline tuple_t NextAt(size_type cursor) {
        data_size_1D_t *result = nullptr;
        if (cursor < this->edgelist_->size()) {
            result = algebra::Get2D(this->Sorted(), cursor);
        }
        if (result != nullptr) {
            return std::make_shared<data_size_1D_t>(*result);
        }
        return std::make_shared<data_size_1D_t>();
    }

private:
    // algebra
    inline data_size_2D_t *Sorted() {
        if (this->sorted_) {
            return this->edgelist_;
        }
        std::sort(this->edgelist_->begin(), this->edgelist_->end(),
                AscendVector());
        this->sorted_ = true;
        return this->edgelist_;
    }

    data_size_2D_t *edgelist_;
    bool sorted_;
    BaseOperand_t *cache_;
};

// represent graph node using operation based on axis
class AxisNode: public BaseNode {
public:
    typedef BaseOperand_t::axis_t axis_t;

    AxisNode(const std::string &represent, OPERATION operation,
            BaseNode *graphnode, axis_t *axis)
            : BaseNode(represent), operation_(operation),
              graphnode_(graphnode), axis_(axis), cache_(nullptr) {
    }
    ~AxisNode() {
        delete this->graphnode_;
        delete this->axis_;
        delete this->cache_;
    }

    BaseOperand_t *Evaluate();
    inline void Print(size_type leading_space) {
        BaseNode::Print(leading_space);
        this->graphnode_->Print(leading_space + 2);
    }
    BaseNode *ShallowCopy();

    // within pipeline
    inline tuple_t NextAt(size_type cursor) {
        data_size_1D_t *result = this->Evaluate()->NextAt(cursor);
        if (result != nullptr) {
            return std::make_shared<data_size_1D_t>(*result);
        }
        return std::make_shared<data_size_1D_t>();
    }

private:
    OPERATION operation_;
    BaseNode *graphnode_;
    axis_t *axis_;
    BaseOperand_t *cache_;
};

// represent graph node using binary operation on two graph node *
class BinaryNode: public BaseNode {
public:
    BinaryNode(const std::string represent, OPERATION operation, BaseNode *left,
            BaseNode *right)
            : BaseNode(represent), operation_(operation), left_(left),
              right_(right), cache_(nullptr) {
        this->buffer_ = new Buffer(this);
    }
    ~BinaryNode() {
        delete this->buffer_;
        delete this->left_;
        delete this->right_;
        if (this->cache_ != nullptr) {
            delete this->cache_;
        }
    }

    // exposed API
    BaseOperand_t *Evaluate();
    inline void Print(size_type leading_space) {
        BaseNode::Print(leading_space);
        this->left_->Print(leading_space + 2);
        this->right_->Print(leading_space + 2);
    }
    BaseNode *ShallowCopy();

    // within pipeline
    inline tuple_t Front() {
        return this->NextAt(this, this->GetCursor(), this);
    }
    inline tuple_t Next() {
        tuple_t tuple = this->NextAt(this, this->GetCursor(), this);
        this->AdvanceCursor();
        return tuple;
    }
    inline tuple_t NextAt(size_type cursor) {
        return this->NextAt(this, cursor, this);
    }
    tuple_t NextAt(BaseNode *self, size_type cursor, BinaryNode *binary_node);

    Buffer *buffer_;

private:
    OPERATION operation_;
    BaseNode *left_;
    BaseNode *right_;
    BaseOperand_t *cache_;
};

// represent graphnode using non-edge operation
class ComplementNode: public BaseNode {
public:
    typedef std::unordered_map<std::string, BaseNode *> index_t;

    ComplementNode(const std::string &represent, index_t *index,
            const size_type graph_size)
            : BaseNode(represent), graph_size_(graph_size), cache_(nullptr),
              from_node_(0), to_node_(0) {
        this->left_node_ = algebra::GetMap<std::string, BaseNode *>(index,
                "A");
        this->right_node_ = algebra::GetMap<std::string, BaseNode *>(index,
                "UT");
        this->buffer_ = new Buffer(this);
    }
    ~ComplementNode() {
        delete this->buffer_;
    }

    // API
    BaseOperand_t *Evaluate();
    BaseNode *ShallowCopy();

    // within pipeline
    inline tuple_t Front() {
        return this->NextAt(this, this->GetCursor(), this);
    }
    inline tuple_t Next() {
        tuple_t tuple = this->NextAt(this, this->GetCursor(), this);
        this->AdvanceCursor();
        return tuple;
    }
    inline tuple_t NextAt(size_type cursor) {
        this->AdvanceCursor();
        return this->NextAt(this, this->GetCursor(), this);
    }
    tuple_t NextAt(BaseNode *self, size_type cursor, ComplementNode *comp_node);

    Buffer *buffer_;

private:
    // nonedge
    bool FindEdge(BaseNode *node, const data_size_1D_t &target);

    const size_type graph_size_;
    BaseNode *left_node_;
    BaseNode *right_node_;
    BaseOperand_t *cache_;
    data_size_t from_node_;
    data_size_t to_node_;
};

// represent graph node using scaling operation
class ScaleNode: public BaseNode {
public:
    typedef algebra::scalar_t scalar_t;
    ScaleNode(const std::string &represent, BaseNode *graphnode,
            scalar_t scalar)
            : BaseNode(represent), graphnode_(graphnode), scalar_(scalar),
              cache_(nullptr) {
    }
    ~ScaleNode() {
        delete this->graphnode_;
        delete this->cache_;
    }

    inline BaseOperand_t *Evaluate() {
        if (this->cache_ == nullptr) {
            this->cache_ = this->graphnode_->Evaluate()->Scale(this->scalar_);
        }
        return this->cache_;
    }
    inline void Print(size_type leading_space) {
        BaseNode::Print(leading_space);
        this->graphnode_->Print(leading_space + 2);
    }
    BaseNode *ShallowCopy();

    // within pipeline
    inline tuple_t NextAt(size_type cursor) {
        data_size_1D_t *result = this->Evaluate()->NextAt(cursor);
        if (result != nullptr) {
            return std::make_shared<data_size_1D_t>(*result);
        }
        return std::make_shared<data_size_1D_t>();
    }

private:
    BaseNode *graphnode_;
    scalar_t scalar_;
    BaseOperand_t *cache_;
};

// represent graph node using sum operation
// Created on: 2020-2-21 21:41
class SumNode: public BaseNode {
public:
    typedef algebra::T_1D<BaseNode *> graphnode_1D_t;
    typedef graphnode::matrix_t matrix_t;
    SumNode(const std::string &represent, graphnode_1D_t *nodelist)
            : BaseNode(represent), nodelist_(nodelist) {
    }
    ~SumNode() {
        algebra::DeleteContent(*this->nodelist_);
        delete this->nodelist_;
    }

    // API
    BaseOperand_t *Evaluate();
    void Print(size_type leading_space) {
        BaseNode::Print(leading_space);
        for (const auto &node : *this->nodelist_) {
            node->Print(leading_space + 2);
        }
    }
    BaseNode *ShallowCopy();

    // within pipeline
    inline tuple_t NextAt(size_type cursor) {
        data_size_1D_t *result = this->Evaluate()->NextAt(cursor);
        if (result != nullptr) {
            return std::make_shared<data_size_1D_t>(*result);
        }
        return std::make_shared<data_size_1D_t>();
    }

private:
    graphnode_1D_t *nodelist_;
};

}

#endif /* ALGEBRA_PIPELINE_GRAPHNODE_HPP_ */
