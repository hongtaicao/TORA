/*
 * graphnode.cpp
 *
 *  Created on: 2020-3-8 20:38
 *      Author: Hongtai Cao
 */

#ifndef NDBUG
#include <iostream>
#endif

#include "algebra/pipeline/childnode.hpp"
#include "algebra/pipeline/graphnode.hpp"

namespace pipeline {

BaseNode *AdjacencyNode::ShallowCopy() {
    return new ChildNode(this);
}

BaseOperand_t *AxisNode::Evaluate() {
    if (this->cache_ == nullptr) {
#ifndef NDEBUG
        std::cout << this << " AxisNode evaluate start " << this->GetRepresent()
                << std::endl;
#endif
        BaseOperand_t *result = this->graphnode_->Evaluate();
        switch (this->operation_) {
        case algebra::REDUCE_OP: {
            this->cache_ = result->Reduce(this->axis_);
            break;
        }
        case algebra::TRANSPOSE_OP: {
            this->cache_ = result->Transpose(this->axis_);
            break;
        }
        default: {
            assert(false);
        }
        }
#ifndef NDEBUG
        std::cout << this << " size " << result->Size2String()
                << " AxisNode evaluate done " << this->GetRepresent()
                << std::endl;
        result->WriteData(this->GetRepresent());
#endif
    }
    return this->cache_;
}

BaseNode *AxisNode::ShallowCopy() {
    return new ChildNode(this);
}

BaseOperand_t *BinaryNode::Evaluate() {
    if (this->cache_ == nullptr) {
#ifndef NDEBUG
        std::cout << this << " BinaryNode evaluate start "
                << this->GetRepresent() << std::endl;
#endif
        size_type cursor = this->SetCursor(0);
        relation_t *result = new relation_t(this->operation_, nullptr);
        for (auto tuple = this->Next(); tuple->size() != 0; tuple =
                this->Next()) {
            result->data_->push_back(new data_size_1D_t(*tuple.get()));
        }
        this->cache_ = result;
        this->SetCursor(cursor);
#ifndef NDEBUG
        std::cout << this << " size " << result->Size2String()
                << " BinaryNode evaluate done " << this->GetRepresent()
                << std::endl;
        result->WriteData(this->GetRepresent());
#endif
    }
    return this->cache_;
}

BaseNode *BinaryNode::ShallowCopy() {
    BaseNode *child = new BinaryChild(this);
    this->buffer_->Insert(child);
    return child;
}

tuple_t PipelineMask(BaseNode *left, relation_t *right) {
    // Relation<item_T>::Mask2
    // scan / binary search
    while (left->Front()->size() != 0) {
        size_type i = left->GetCursor();
        tuple_t current = left->Front();
        left->AdvanceCursor();
        auto target = current->front();
        bool same_head = (i > 0) && (target == left->FrontAt(i - 1)->front());
#ifndef NDEBUG
        if (left->GetRepresent().substr(0, 5) == "Merge") {
            if (target == 1) {
                std::cout << "left:MergeResult=";
                algebra::Print1D(*current.get());
                std::cout << "right:searchRange[" << right->head_ << ","
                        << right->tail_ << ")=" << right->Front() << ",";
                if (right->InRangeAt(right->tail_)) {
                    std::cout << right->FrontAt(right->tail_) << std::endl;
                } else {
                    std::cout << std::endl;
                }
            }
        }
#endif
        if (same_head || right->BinarySearchHeadRange(target)) {
            if (right->BinarySearchTail(current->back())) {
                return current;
            }
        }
    }
    return std::make_shared<data_size_1D_t>();
}

tuple_t PipelineMerge(BaseNode *left, relation_t *right) {
    // Relation<item_T>::Merge
    // scan / binary search
    tuple_t front = left->Front();
    while (front->size() != 0) {
        // find range
        data_size_1D_t *left_vec = front.get();
        if (right->BinarySearchInRight(*left_vec)) {
            while ((right->InRange())
                    && (!algebra::rlt::MergeCompare(*left_vec, *right->Get()))) {
                tuple_t result = std::make_shared<data_size_1D_t>(*left_vec);
                result->push_back(right->Back());
                right->head_++;
                return result;
            }
        }
        left->AdvanceCursor();
        right->Initialize();
        front = left->Front();
    }
    return std::make_shared<data_size_1D_t>();
}

tuple_t PipelineMinus(BaseNode *left, relation_t *right) {
    while (left->Front()->size() != 0) {
        tuple_t current = left->Front();
        left->AdvanceCursor();
        if (!right->BinarySearch(*current.get())) {
            return current;
        }
    }
    return std::make_shared<data_size_1D_t>();
}

tuple_t BinaryNode::NextAt(BaseNode *self, size_type cursor,
        BinaryNode *binary_node) {
    if (this->cache_ != nullptr) {
        auto *result = this->cache_->NextAt(cursor);
        if (result != nullptr) {
            return std::make_shared<data_size_1D_t>(*result);
        }
        return std::make_shared<data_size_1D_t>();
    }
    if (binary_node->buffer_->Has(self, cursor)) {
        return binary_node->buffer_->Get(self, cursor);
    }
    // try to compute Next result
    BaseNode *left = binary_node->left_;
    relation_t *right = (relation_t *) binary_node->right_->Evaluate();
    tuple_t result = std::make_shared<data_size_1D_t>();
    switch (binary_node->operation_) {
    case algebra::MASK_OP: {
        result = PipelineMask(left, right);
        break;
    }
    case algebra::MERGE_OP: {
        result = PipelineMerge(left, right);
        break;
    }
    case algebra::MINUS_OP: {
        result = PipelineMinus(left, right);
        break;
    }
    default: {
        assert(false);
    }
    }
    if (result->size() == 0) {
        binary_node->buffer_->Erase(self);
    } else {
        this->buffer_->Add(cursor, result);
    }
    return result;
}

BaseOperand_t *ComplementNode::Evaluate() {
    relation_t *result = new relation_t(algebra::NONEDGE_OP, nullptr);
    if (this->cache_ == nullptr) {
        size_type cursor = this->SetCursor(0);
        for (auto tuple = this->Next(); tuple->size() != 0; tuple =
                this->Next()) {
            result->data_->push_back(tuple.get());
        }
        this->cache_ = result;
        this->SetCursor(cursor);
    }
    return this->cache_;
}

BaseNode *ComplementNode::ShallowCopy() {
    BaseNode *child = new ComplementChild(this);
    this->buffer_->Insert(child);
    return child;
}

tuple_t ComplementNode::NextAt(BaseNode *self, size_type cursor,
        ComplementNode *comp_node) {
    if (comp_node->buffer_->Has(self, cursor)) {
        return comp_node->buffer_->Get(self, cursor);
    }
    // try to compute Next result
    while (this->from_node_ < this->graph_size_) {
        while (this->to_node_ < this->graph_size_) {
            if (this->to_node_ == this->from_node_) {
                this->to_node_++;
                continue;
            }
            data_size_1D_t non_edge( { this->from_node_, this->to_node_ });
            if (this->FindEdge(this->left_node_, non_edge)
                    || this->FindEdge(this->right_node_, non_edge)) {
                this->to_node_++;
                continue;
            }
            tuple_t found = std::make_shared<data_size_1D_t>(non_edge);
            this->buffer_->Add(cursor, found);
            return found;
        }
        this->from_node_++;
        this->to_node_ = 0;
    }
    comp_node->buffer_->Erase(self);
    return std::make_shared<data_size_1D_t>();
}

bool ComplementNode::FindEdge(BaseNode *node, const data_size_1D_t &target) {
    int compare = -1;
    while (node->Front() != nullptr) {
        compare = algebra::rlt::CompareVector(*node->Front(), target);
        if (compare < 0) {
            node->Next();
        } else {
            break;
        }
    }
    // compare == 0: find the edge
    return compare == 0;
}

BaseNode *ScaleNode::ShallowCopy() {
    return new ChildNode(this);
}

BaseOperand_t *SumNode::Evaluate() {
    algebra::T_1D<matrix_t *> *result = new algebra::T_1D<matrix_t *>();
    for (auto &item : (*this->nodelist_)) {
        result->push_back((matrix_t *) item->Evaluate());
    }
    BaseOperand_t *output = matrix_t::Sum(result);
    return output;
}

BaseNode *SumNode::ShallowCopy() {
    return new ChildNode(this);
}

}
