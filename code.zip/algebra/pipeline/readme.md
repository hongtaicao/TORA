# pipeline implementation
this aims to reduce memory consumption by not materializing some results
this is achieve by computing the next result on demand

reduce memmory cost in general will increase the time cost
need to carefully pipeline it to minimize the time cost

operations need to pipeline
    adjacency       used by transpose(A), mask(A, ), minus(A, ?)
    axis
        reduce      used for motif adjacency
        transpose   transpose(A), tranpose(U), tranpose(?) for motif adjacency
    binary
        mask        mask(?, B), mask(?, N), mask(?, U), mask(?, UT)
        merge       merge(X, Y)
        minus       minus(A, B), minus(AT, BT)
    complement      N = complement(A, B)
    scale           scale(X, ?) for motif adjacency
    sum             sum(X, Y, Z, ?) for motif adjacency

some operations do not care if operands are sorted or not
    adjacency
    axis reduce/transpose
    scale
    sum

some operations can be efficient if operands are sorted
    mask
    minus
    complement
their results preserve the order

special case: merge
    if no materialize, time cost will be O(mn)
    if materialize left, time cost will be O(l log(l) + l+r + jlog(j))
        sort left: O( l log(l) )
        sort merge join: O( l+r )
        sort result: O( jlog(j) )
    if materialize right, time cost will be O( llog(r) )
        materialize right
        binary search right: O( llog(r) )

design requirement:
    1. determine whether to cache right
        always, because the possible right operand of the merge can be result of a transpose, mask, minus or complement
    2. determine work with buffer
        first check if itself is materialized, then disable the buffer
    3. complement N does not have to be materialize because binary search can be achieve by binary search on the complements of N
        N = 1 - A - UT
        bianary search tuple t is found in A or UT, then t is not in N
        if t is not found in A or UT, then t is in N

Next() method sharing mechanism
    1. the pointer to the buffer_ is tied to it. shared globally
    2. the cache_ internal states are are tied to it. this requires Next() should be called without any other interruption.
    3. Next() is guaranteed to be called without any other operations because retieval of other positions are processed by the buffer_
