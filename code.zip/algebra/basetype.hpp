/*
 * basetype.hpp
 *
 * T_xxx: template type xxx
 * xxx_T: template type xxx typename
 * xxx_t: xxx typename
 *
 *  Created on: 2020-1-4 18:05
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_BASETYPE_HPP_
#define ALGEBRA_BASETYPE_HPP_

#include <array>
#include <deque>
#include <iostream>
#include <string>

#define _ALGEBRA_VERSION_ std::string("v0.12")

// see algebra/material/basenode.hpp
#define LATE_DELETE
// NDEBUG disables assert and debug information
#define NDEBUG
// enable optional code
// #define OPTIONAL
// see algebra/storage/nestedmap/operation_maskaxismergeaxis.hpp
#define SKIP_REORDER

// forward declare of a namespace
namespace nestedmap {
}

namespace relation_pointer {
}

// option: nestedmap, relation_pointer
#define _STORAGE_ nestedmap

#define BOOL_STRING(b) ((b)?"true":"false")

namespace algebra {

// setting
// start of constant and type
enum ADJACENCY_ALGORITHM {
    // determine how to generate adjacency expression
    ADJ_ECLASS, // edge obit of branch
    ADJ_PERMUTATION, // permutation of branch
};
enum ADJACENCY_FORMAT {
    ADJ_FOREST,
    ADJ_TABLE,
};
enum BRANCH_ALGORITHM {
    // determine how to generate other branch
    BR_TRANSPOSE, // transpose existing branch
    BR_MATCH, // perform a subgraph match
};
enum LEAF_ALGORITHM {
    // determine how to compute building block
    LEAF_BUILDINGBLOCK, // read B, N, U, UT directly
    LEAF_ADJACENCY_STORAGE, // read A and build using Storage
    LEAF_ADJACENCY_BUILDER, // read A and build using StorageBuilder
    LEAF_ADJACENCY_EVALUATE, // read A and compute
};
enum LEAF_FORMAT {
    LEAF_BINARY_BLOCK, // single read operation
    LEAF_BINARY_NEIGHBORLIST, // multiple read operation
    LEAF_BINARY_PAIRLIST,
    LEAF_TEXT_NEIGHBORLIST,
    LEAF_TEXT_PAIRLIST,
    LEAF_TEXT_PAIRLIST_ADJACENCY,
};
enum OPERATOR_ALGORITHM {
    // determine what operator should be use
    OP_MASKMERGE, // use MaskMerge operator
    OP_BASIC, // use Mask, Merge operators
};
enum OPERATOR_NAME {
    ADJACENCY_OP,
    MASK_OP,
    MASKMERGE_OP,
    MASKAXISMERGE_OP,
    MASKAXISMERGEAXIS_OP,
    MASK_MERGE__BY_OP,
    MERGE_OP,
    MINUS_OP,
    NONEDGE_OP,
    PIPELINE_OP,
    REDUCE_OP,
    SCALE_OP,
    SUM_OP,
    TRANSPOSE_OP,
};
enum REDUCE_ALGORITHM {
    SCALE_REDUCE, // scale and reduce operator
    REDUCE_UNIQUE, // remove duplicates and reduce
};

// template typedef
template<typename size_T>
using T_1D = std::deque<size_T>;

template<typename size_T>
using T_2D = T_1D<T_1D<size_T> *>;

/*
 * https://stackoverflow.com/a/29284954/11193802
 * The key type for an unordered container needs either a specialization
 * of std::hash defined for it, or a custom hash function
 * provided to the container.
 *
 template<typename size_T>
 using T_size_set = std::unordered_set<size_T>;

 template<typename size_T>
 using T_size2set = std::unordered_map<size_T, T_size_set<size_T>>;
 */

// typedef: evaluated at compile time
/*
 * 2 bytes unsigned short: 2^16-1 = 65,535
 * 4 bytes unsigned int: 2^32-1 = 4,294,967,295
 */
typedef T_1D<int>::size_type size_type; // byte=8. long long unsigned int
typedef unsigned int data_size_t; // byte=4
typedef unsigned short query_size_t;
typedef double scalar_t;

typedef T_1D<data_size_t> data_size_1D_t;
typedef T_2D<data_size_t> data_size_2D_t;

// enum function
inline std::string ConfigName(ADJACENCY_ALGORITHM);
inline std::string ConfigName(ADJACENCY_FORMAT);
inline std::string ConfigName(BRANCH_ALGORITHM);
inline std::string ConfigName(LEAF_ALGORITHM);
inline std::string ConfigName(OPERATOR_NAME);
inline std::string ConfigName(OPERATOR_ALGORITHM);
inline std::string ConfigName(REDUCE_ALGORITHM);
inline ADJACENCY_ALGORITHM AdjacencyAlgorithm(const int);
inline ADJACENCY_FORMAT AdjacencyFormat(const int);
inline BRANCH_ALGORITHM BranchAlgorithm(const int);
inline LEAF_ALGORITHM LeafAlgorithm(const int);
inline LEAF_FORMAT LeafFormat(const int);
inline OPERATOR_ALGORITHM OperatorAlgorithm(const int);
inline REDUCE_ALGORITHM ReduceAlgorithm(const int);

// inline must be in the same compile unit
template<typename enum_T>
inline std::string ConfigNameError(const std::string &name, enum_T algorithm) {
    std::cout << "ConfigNameError(): Unknown " << name << "=" << algorithm
            << std::endl;
    throw;
}

inline void ConfigError(const std::string &name, int algorithm) {
    std::cout << "ConfigError(): Unknown " << name << "=" << algorithm
            << std::endl;
    throw;
}

inline std::string ConfigName(ADJACENCY_ALGORITHM algo) {
    if (algo == ADJ_ECLASS) {
        return "ADJ_ECLASS";
    } else if (algo == ADJ_PERMUTATION) {
        return "ADJ_PERMUTATION";
    }
    return ConfigNameError("ADJACENCY_ALGORITHM", algo);
}

inline std::string ConfigName(ADJACENCY_FORMAT format) {
    if (format == ADJ_FOREST) {
        return "ADJ_FOREST";
    } else if (format == ADJ_TABLE) {
        return "ADJ_TABLE";
    }
    return ConfigNameError("ADJACENCY_FORMAT", format);
}

inline std::string ConfigName(BRANCH_ALGORITHM algo) {
    if (algo == BR_TRANSPOSE) {
        return "BR_TRANSPOSE";
    } else if (algo == BR_MATCH) {
        return "BR_MATCH";
    }
    return ConfigNameError("BRANCH_ALGORITHM", algo);
}

inline std::string ConfigName(LEAF_ALGORITHM algo) {
    if (algo == LEAF_BUILDINGBLOCK) {
        return "LEAF_BUILDINGBLOCK";
    } else if (algo == LEAF_ADJACENCY_STORAGE) {
        return "LEAF_STORAGE";
    } else if (algo == LEAF_ADJACENCY_BUILDER) {
        return "LEAF_BUILDER";
    } else if (algo == LEAF_ADJACENCY_EVALUATE) {
        return "LEAF_ADJACENCY";
    }
    return ConfigNameError("LEAF_ALGORITHM", algo);
}

inline std::string ConfigName(LEAF_FORMAT algo) {
    if (algo == LEAF_BINARY_BLOCK) {
        return "LEAF_BINARY_BLOCK";
    } else if (algo == LEAF_BINARY_NEIGHBORLIST) {
        return "LEAF_BINARY_NEIGHBORLIST";
    } else if (algo == LEAF_BINARY_PAIRLIST) {
        return "LEAF_BINARY_PAIRLIST";
    } else if (algo == LEAF_TEXT_NEIGHBORLIST) {
        return "LEAF_TEXT_NEIGHBORLIST";
    } else if (algo == LEAF_TEXT_PAIRLIST) {
        return "LEAF_TEXT_PAIRLIST";
    } else if (algo == LEAF_TEXT_PAIRLIST_ADJACENCY) {
        return "LEAF_TEXT_PAIRLIST_ADJACENCY";
    }
    return ConfigNameError("LEAF_FORMAT", algo);
}

std::string ConfigName(OPERATOR_NAME op) {
    if (op == ADJACENCY_OP) {
        return "ADJACENCY_OP";
    } else if (op == MASK_OP) {
        return "MASK_OP";
    } else if (op == MASKMERGE_OP) {
        return "MASKMERGE_OP";
    } else if (op == MASKAXISMERGE_OP) {
        return "MASKAXISMERGE_OP";
    } else if (op == MASKAXISMERGEAXIS_OP) {
        return "MASKAXISMERGEAXIS_OP";
    } else if (op == MASK_MERGE__BY_OP) {
        return "MASK_MERGE__BY_OP";
    } else if (op == MERGE_OP) {
        return "MERGE_OP";
    } else if (op == MINUS_OP) {
        return "MINUS_OP";
    } else if (op == NONEDGE_OP) {
        return "NONEDGE_OP";
    } else if (op == PIPELINE_OP) {
        return "PIPELINE_OP";
    } else if (op == REDUCE_OP) {
        return "REDUCE_OP";
    } else if (op == SCALE_OP) {
        return "SCALE_OP";
    } else if (op == SUM_OP) {
        return "SUM_OP";
    } else if (op == TRANSPOSE_OP) {
        return "TRANSPOSE_OP";
    }
    return ConfigNameError("OPERATION", op);
}

inline std::string ConfigName(OPERATOR_ALGORITHM algo) {
    if (algo == OP_MASKMERGE) {
        return "OP_MASKMERGE";
    } else if (algo == OP_BASIC) {
        return "OP_BASIC";
    }
    return ConfigNameError("OPERATOR_ALGORITHM", algo);
}

inline std::string ConfigName(REDUCE_ALGORITHM algo) {
    if (algo == SCALE_REDUCE) {
        return "SCALE_REDUCE";
    } else if (algo == REDUCE_UNIQUE) {
        return "REDUCE_UNIQUE";
    }
    return ConfigNameError("REDUCE_ALGORITHM", algo);
}

inline ADJACENCY_ALGORITHM AdjacencyAlgorithm(const int algo) {
    if (algo == 0) {
        return ADJ_ECLASS;
    } else if (algo == 1) {
        return ADJ_PERMUTATION;
    }
    ConfigError("ADJACENCY_ALGORITHM", algo);
    throw;
}

inline ADJACENCY_FORMAT AdjacencyFormat(const int format) {
    if (format == 0) {
        return ADJ_FOREST;
    } else if (format == 1) {
        return ADJ_TABLE;
    }
    ConfigError("ADJACENCY_FORMAT", format);
    throw;
}

inline BRANCH_ALGORITHM BranchAlgorithm(const int algo) {
    if (algo == 0) {
        return BR_TRANSPOSE;
    } else if (algo == 1) {
        return BR_MATCH;
    }
    ConfigError("BRANCH_ALGORITHM", algo);
    throw;
}

inline LEAF_ALGORITHM LeafAlgorithm(const int algo) {
    if (algo == 0) {
        return LEAF_BUILDINGBLOCK;
    } else if (algo == 1) {
        return LEAF_ADJACENCY_STORAGE;
    } else if (algo == 2) {
        return LEAF_ADJACENCY_BUILDER;
    } else if (algo == 3) {
        return LEAF_ADJACENCY_EVALUATE;
    }
    ConfigError("LEAF_ALGORITHM", algo);
    throw;
}

inline LEAF_FORMAT LeafFormat(const int algo) {
    if (algo == 0) {
        return LEAF_BINARY_BLOCK;
    } else if (algo == 1) {
        return LEAF_BINARY_NEIGHBORLIST;
    } else if (algo == 2) {
        return LEAF_BINARY_PAIRLIST;
    } else if (algo == 3) {
        return LEAF_TEXT_NEIGHBORLIST;
    } else if (algo == 4) {
        return LEAF_TEXT_PAIRLIST;
    } else if (algo == 5) {
        return LEAF_TEXT_PAIRLIST_ADJACENCY;
    }
    ConfigError("LEAL_FORMAT", algo);
    throw;
}

inline OPERATOR_ALGORITHM OperatorAlgorithm(const int algo) {
    if (algo == 0) {
        return OP_MASKMERGE;
    } else if (algo == 1) {
        return OP_BASIC;
    }
    ConfigError("OPERATOR_ALGORITHM", algo);
    throw;
}

inline REDUCE_ALGORITHM ReduceAlgorithm(const int algo) {
    if (algo == 0) {
        return SCALE_REDUCE;
    } else if (algo == 1) {
        return REDUCE_UNIQUE;
    }
    ConfigError("REDUCE_ALGORITHM", algo);
    throw;
}

} // namespace algebra

namespace subalgebra {

// typedef: evaluated at compile time
typedef algebra::T_1D<algebra::data_size_t> data_size_1D_t;
typedef algebra::T_1D<algebra::query_size_t> query_size_1D_t;

} // namespace subalgebra

#endif /* ALGEBRA_BASETYPE_HPP_ */
