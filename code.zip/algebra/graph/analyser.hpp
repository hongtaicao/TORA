/*
 * analyser.hpp
 *
 *  Created on: 2020-1-4  16:20
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_GRAPH_ANALYSER_HPP_
#define ALGEBRA_GRAPH_ANALYSER_HPP_

#include <algorithm>
#include <cstdlib>
#include <iterator>
#include <sstream>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "algebra/algorithm/tritree.hpp"
#include "algebra/algorithm/unionfindset.hpp"
#include "algebra/basetype.hpp"
#include "algebra/graph/graph.hpp"
#include "algebra/graph/graphmatcher.hpp"

namespace algebra {

template<typename vertex_T>
class Analyser {
private:
    typedef GraphMatcher<vertex_T> matcher_t;
    typedef T_1D<vertex_T> edge_t;
    typedef T_1D<edge_t> edge_orbit_t;
    typedef std::unordered_map<std::string, std::string> string_map_t;
    typedef UnionFindSet<std::string> unionfindset_t;
    typedef typename unionfindset_t::label2item_t label2item_t;
    typedef typename unionfindset_t::item_t item_t;
    typedef typename unionfindset_t::item_1D_t ufs_item_1D_t;

public:
    typedef Graph<vertex_T> graph_t;
    typedef T_1D<vertex_T> vertex_1D_t;
    typedef T_1D<vertex_1D_t *> seq_1D_t;

    Analyser(const graph_t &);
    ~Analyser();

    Analyser(const Analyser<vertex_T> &) = delete;
    Analyser<vertex_T> &operator=(const Analyser<vertex_T> &) = delete;

    inline size_type MotifCount(size_type match_count) {
        return match_count / this->graph_->VertexSize()
                / (this->graph_->VertexSize() - 1);
    }
    inline std::string EdgeExpression(const vertex_T &, const vertex_T &);
    std::string MaskExpression(const vertex_T &, const vertex_T &,
            vertex_1D_t *);
    std::string MaskMergeExpression(const vertex_T &, const vertex_T &,
            vertex_1D_t *);
    std::string MergeExpression(const vertex_T &, const vertex_T &,
            vertex_1D_t *);

    void MatchEclassEdge(vertex_1D_t *&, vertex_1D_t *&, seq_1D_t *&);
    /*
     * orbit scalar compute the possible permutation when merge
     * vi, vj are fixed nodes
     */
    scalar_t OrbitScale(const vertex_T &, const vertex_T&, const vertex_1D_t &);
    inline const typename graph_t::vertex_1D_t &Vertex() const {
        return this->graph_.Vertex();
    }
    inline size_type VertexSize() const {
        return this->graph_.VertexSize();
    }

private:
    void BuildEdgeOrbit(edge_orbit_t &);
    bool ShouldReverse(const vertex_T &vi, const vertex_T &vj);

    inline edge_t EdgeFromUfsItem(const item_t &key) {
        std::string::size_type idx;
        return edge_t { (vertex_T) std::stoi(key, &idx), (vertex_T) std::stoi(
                key.substr(idx + 1)) };
    }
    inline item_t EdgeToUfsItem(const vertex_T &a, const vertex_T &b) {
        return std::to_string(a) + this->edge_sep_ + std::to_string(b);
    }
    inline const typename matcher_t::map_1D_t &GetAutoMapping() const {
        return this->graphmatcher_.GetMap1to2();
    }

    const graph_t &graph_;
    const matcher_t graphmatcher_;
    bool edge_obit_built_;
    vertex_1D_t head_list_;
    vertex_1D_t tail_list_;
    seq_1D_t sequence_list_;
    string_map_t sequence2mask_;
    string_map_t sequence2merge_;
    static const std::string edge_sep_;
    static const std::unordered_set<std::string> reverse_type_;

};

template<typename vertex_T>
inline void MergeTogether(const vertex_T &vi, const vertex_T &vj,
        typename Analyser<vertex_T>::vertex_1D_t *sequence,
        typename Analyser<vertex_T>::vertex_1D_t &merged) {
    merged.assign(sequence->begin(), sequence->end());
    merged.push_front(vi);
    merged.push_back(vj);
}

template<typename vertex_T>
inline void T_1D2String(typename Analyser<vertex_T>::vertex_1D_t *it,
        std::string &output) {
    if (it != nullptr) {
        std::ostringstream oss;
        std::copy(it->begin(), it->end() - 1,
                std::ostream_iterator<vertex_T>(oss, ","));
        oss << it->back();
        output += oss.str();
    }
}

namespace nls {
template<typename vertex_T>
inline void Merge2String(vertex_T vi, vertex_T vj,
        typename Analyser<vertex_T>::vertex_1D_t *sequence,
        std::string &output) {
    typename Analyser<vertex_T>::vertex_1D_t merged_usequence;
    MergeTogether(vi, vj, sequence, merged_usequence);
    T_1D2String<vertex_T>(&merged_usequence, output);
}
} // namespace nls

template<typename vertex_T>
void Analyser<vertex_T>::BuildEdgeOrbit(edge_orbit_t &edge_orbit) {
    unionfindset_t ufs;
    const std::vector<vertex_T> &nodelist = this->graph_.Vertex();
    for (size_type i = 0; i < this->graph_.VertexSize(); i++) {
        for (size_type j = i + 1; j < this->graph_.VertexSize(); j++) {
            ufs.Add(this->EdgeToUfsItem(nodelist[i], nodelist[j]));
        }
    }
    ufs_item_1D_t item_list;
    ufs.GetAllItem(item_list);
    for (const auto &map : this->GetAutoMapping()) {
        for (const auto &item : item_list) {
            auto edge = this->EdgeFromUfsItem(item);
            vertex_T a = (*map)[edge[0]];
            vertex_T b = (*map)[edge[1]];
            if (a < b) {
                ufs.Union(item, this->EdgeToUfsItem(a, b));
            } else {
                ufs.Union(item, this->EdgeToUfsItem(b, a));
            }
        }
    }
    label2item_t label2item;
    ufs.GetUnionItem(label2item);
    for (const auto &pair : label2item) {
        edge_orbit.push_back(this->EdgeFromUfsItem(pair.second));
    }
}

template<typename vertex_T>
void Analyser<vertex_T>::MatchEclassEdge(vertex_1D_t *&head_list,
        vertex_1D_t *&tail_list, seq_1D_t *&sequence_list) {
    if (!this->edge_obit_built_) {
        // build
        edge_orbit_t edge_orbit;
        this->BuildEdgeOrbit(edge_orbit);
        typename graph_t::set_t all_node(this->graph_.Vertex().begin(),
                this->graph_.Vertex().end());
        for (const auto &edge : edge_orbit) {
            vertex_T a = edge[0];
            this->head_list_.push_back(a);
            all_node.erase(a);
            vertex_T b = edge[1];
            this->tail_list_.push_back(b);
            all_node.erase(b);
            this->sequence_list_.push_back(
                    new vertex_1D_t(all_node.begin(), all_node.end()));
            if (this->ShouldReverse(a, b)) {
                this->head_list_.push_back(b);
                this->tail_list_.push_back(a);
                this->sequence_list_.push_back(
                        new vertex_1D_t(all_node.begin(), all_node.end()));
            }
            all_node.insert(a);
            all_node.insert(b);
        }
    }
    // each pair of (head, tail) is unique
    this->edge_obit_built_ = true;
    head_list = &this->head_list_;
    tail_list = &this->tail_list_;
    sequence_list = &this->sequence_list_;
}

template<typename vertex_T>
scalar_t Analyser<vertex_T>::OrbitScale(const vertex_T &vi, const vertex_T &vj,
        const vertex_1D_t &sequence) {
    // result depends on the content of sequence but not its order
    size_type multiplier = 0;
    TriTree<vertex_T> tri_tree;
    typename graph_t::set_t all_node(sequence.begin(), sequence.end());
    all_node.insert(vi);
    graph_t subgraph_i(this->graph_, all_node);
    matcher_t auto_matcher1(subgraph_i, subgraph_i);
    typename TriTree<vertex_T>::sequence_t mapping_sequence;
    // index mapping sequence
    for (auto &map : auto_matcher1.GetMap1to2()) {
        mapping_sequence.clear();
        for (const auto &item : sequence) {
            mapping_sequence.push_back(GetMap(map, item));
        }
        tri_tree.Index(mapping_sequence);
    }
    // find merge scalar
    all_node.erase(vi);
    all_node.insert(vj);
    graph_t subgraph_j(this->graph_, all_node);
    matcher_t auto_matcher2(subgraph_j, subgraph_j);
    for (auto &map : auto_matcher2.GetMap1to2()) {
        mapping_sequence.clear();
        for (const auto &item : sequence) {
            mapping_sequence.push_back(GetMap(map, item));
        }
        multiplier += tri_tree.Match(mapping_sequence);
    }
    return 1.0 / (double) multiplier;
}

template<typename vertex_T>
inline std::string Analyser<vertex_T>::EdgeExpression(const vertex_T &vi,
        const vertex_T &vj) {
    if (this->graph_.HasEdge(vi, vj)) {
        if (this->graph_.HasEdge(vj, vi)) {
            return "B";
        }
        return "U";
    } else if (this->graph_.HasEdge(vj, vi)) {
        return "UT";
    }
    return "N";
}

template<typename vertex_T>
std::string Analyser<vertex_T>::MaskExpression(const vertex_T &vi,
        const vertex_T &vj, vertex_1D_t *sequence) {
    // sequence can be nullptr
    if ((sequence == nullptr) or (sequence->size() == 0)) {
        return this->EdgeExpression(vi, vj);
    }
    std::string key;
    nls::Merge2String(vi, vj, sequence, key);
    if (this->sequence2mask_.count(key) == 0) {
        this->sequence2mask_[key] = "Mask("
                + this->MergeExpression(vi, vj, sequence) + ","
                + this->EdgeExpression(vi, vj) + ")";
    }
    return this->sequence2mask_[key];
}

template<typename vertex_T>
std::string Analyser<vertex_T>::MaskMergeExpression(const vertex_T &vi,
        const vertex_T &vj, vertex_1D_t *sequence) {
    std::string key;
    nls::Merge2String(vi, vj, sequence, key);
    if (this->sequence2mask_.count(key) == 0) {
        if (sequence->size() > 1) {
            // left
            vertex_T vk = sequence->back();
            sequence->pop_back();
            std::string left = this->MaskMergeExpression(vi, vk, sequence);
            sequence->push_back(vk);
            // right
            vk = sequence->front();
            sequence->pop_front();
            std::string right = this->MaskMergeExpression(vk, vj, sequence);
            sequence->push_front(vk);
            // mask
            this->sequence2mask_[key] = "MaskMerge(" + left + "," + right + ","
                    + this->EdgeExpression(vi, vj) + ")";
        } else {
            vertex_T vk = sequence->front();
            this->sequence2mask_[key] = "MaskMerge("
                    + this->EdgeExpression(vi, vk) + ","
                    + this->EdgeExpression(vk, vj) + ","
                    + this->EdgeExpression(vi, vj) + ")";
        }
    }
    return this->sequence2mask_[key];
}

template<typename vertex_T>
std::string Analyser<vertex_T>::MergeExpression(const vertex_T &vi,
        const vertex_T &vj, vertex_1D_t *sequence) {
    // sequence not nullptr
    std::string key;
    nls::Merge2String(vi, vj, sequence, key);
    if (this->sequence2merge_.count(key) == 0) {
        // left
        vertex_T vk = sequence->back();
        sequence->pop_back();
        std::string expression = this->MaskExpression(vi, vk, sequence);
        sequence->push_back(vk);
        // right
        vk = sequence->front();
        sequence->pop_front();
        expression += ("," + this->MaskExpression(vk, vj, sequence));
        sequence->push_front(vk);
        this->sequence2merge_[key] = "Merge(" + expression + ")";
    }
    return this->sequence2merge_[key];
}

template<typename vertex_T>
bool Analyser<vertex_T>::ShouldReverse(const vertex_T &vi, const vertex_T &vj) {
    if (this->reverse_type_.count(this->EdgeExpression(vi, vj)) > 0) {
        return true;
    }
    for (const auto it : this->GetAutoMapping()) {
        if ((it->count(vi) > 0) && (it->count(vj) > 0)) {
            if ((GetMap(it, vi) == vj) && (GetMap(it, vj) == vi)) {
                return false;
            }
        }
    }
    return true;
}

template<typename vertex_T>
Analyser<vertex_T>::~Analyser() {
    DeleteContent(this->sequence_list_);
}

template<typename vertex_T>
Analyser<vertex_T>::Analyser(const graph_t &graph)
        : graph_(graph), graphmatcher_(graph, graph), edge_obit_built_(false) {
}

template<typename vertex_T>
const std::string Analyser<vertex_T>::edge_sep_ = ":";

template<typename vertex_T>
const std::unordered_set<std::string> Analyser<vertex_T>::reverse_type_ = { "U",
        "UT" };

} // namespace algebra

#endif /* ALGEBRA_GRAPH_ANALYSER_HPP_ */
