/*
 * graphmatcher.hpp
 *
 *  Created on: 2020-1-11 23:30
 *      Author: Cao
 */

#ifndef ALGEBRA_GRAPH_GRAPHMATCHER_HPP_
#define ALGEBRA_GRAPH_GRAPHMATCHER_HPP_

#include <algorithm>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "algebra/basetype.hpp"
#include "algebra/graph/graph.hpp"
#include "algebra/utility/access.hpp"

namespace algebra {

template<typename vertex_T>
class GraphMatcher {
public:
    typedef std::unordered_map<vertex_T, vertex_T> iso_map_t;
    typedef std::vector<iso_map_t *> map_1D_t;
    typedef Graph<vertex_T> graph_t;

    GraphMatcher(const graph_t &, const graph_t &);
    ~GraphMatcher();

    GraphMatcher(const GraphMatcher<vertex_T> &) = delete;
    GraphMatcher<vertex_T> &operator=(const GraphMatcher<vertex_T> &) = delete;

    inline const map_1D_t &GetMap1to2() const {
        return this->map_1D_;
    }

private:
    void BuildIsomorphism(const graph_t &, const graph_t &);

    inline bool MatchDegree(const graph_t &g1, const vertex_T &a,
            const graph_t &g2, const vertex_T &b, bool forward) const {
        return g1.Degree(a, forward) == g2.Degree(b, forward);
    }
    inline bool MatchAllDegree(const graph_t &g1, const vertex_T &a,
            const graph_t &g2, const vertex_T &b) const {
        return (this->MatchDegree(g1, a, g2, b, true))
                && (this->MatchDegree(g1, a, g2, b, false));
    }

    map_1D_t map_1D_;
};

namespace graphmatcher {

template<typename vertex_T>
void PermuteRemaining(const std::vector<vertex_T> &value_list,
        std::vector<vertex_T> &candidate,
        std::unordered_set<size_type> &permuted,
        std::vector<std::vector<vertex_T>> &result) {
    if (candidate.size() == value_list.size()) {
        result.push_back(candidate);
    } else {
        for (size_type i = 0; i < value_list.size(); i++) {
            if (permuted.count(i) != 0) {
                continue;
            }
            candidate.push_back(value_list[i]);
            permuted.insert(i);
            PermuteRemaining(value_list, candidate, permuted, result);
            candidate.pop_back();
            permuted.erase(i);
        }
    }
}

template<typename vertex_T>
void GetPermutation(const std::vector<vertex_T> &value_list,
        std::vector<std::vector<vertex_T>> &result) {
    std::vector<vertex_T> candidate;
    std::unordered_set<size_type> permuted;
    for (size_type i = 0; i < value_list.size(); i++) {
        candidate.push_back(value_list[i]);
        permuted.insert(i);
        PermuteRemaining(value_list, candidate, permuted, result);
        candidate.pop_back();
        permuted.erase(i);
    }
}

} // namespace graphmatcher

template<typename vertex_T>
void GraphMatcher<vertex_T>::BuildIsomorphism(const graph_t &g1,
        const graph_t &g2) {
    const std::vector<vertex_T> &key_list = g1.Vertex();
    auto size = g1.VertexSize();
    iso_map_t *candidate_map;
    std::vector<vertex_T> candidate(g2.Vertex());
    std::sort(candidate.begin(), candidate.end());
    do {
        candidate_map = new iso_map_t();
        // create candidate map based on vertex degree
        for (size_type index = 0; index < size; index++) {
            const vertex_T &a = key_list[index];
            const vertex_T &b = candidate[index];
            if (this->MatchAllDegree(g1, a, g2, b)) {
                (*candidate_map)[a] = b;
            } else {
                break;
            }
        }
        if (candidate_map->size() != g1.VertexSize()) {
            delete candidate_map;
        } else {
            // verify edge mapping
            bool is_match = true;
            for (size_type i = 0; i < size; i++) {
                for (size_type j = i + 1; j < size; j++) {
                    const vertex_T &a1 = key_list[i];
                    const vertex_T &b1 = key_list[j];
                    const vertex_T &a2 = GetMap(candidate_map, a1);
                    const vertex_T &b2 = GetMap(candidate_map, b1);
                    if ((g1.HasEdge(a1, b1) != g2.HasEdge(a2, b2))
                            || (g1.HasEdge(b1, a1) != g2.HasEdge(b2, a2))) {
                        is_match = false;
                        break;
                    }
                }
            }
            if (is_match) {
                this->map_1D_.push_back(candidate_map);
            } else {
                delete candidate_map;
            }
        }
    } while (std::next_permutation(candidate.begin(), candidate.end()));
}

template<typename vertex_T>
GraphMatcher<vertex_T>::~GraphMatcher() {
    DeleteContent(this->map_1D_);
}

template<typename vertex_T>
GraphMatcher<vertex_T>::GraphMatcher(const graph_t &g1, const graph_t &g2) {
    if ((g1.EdgeSize() == g1.EdgeSize())
            && (g1.VertexSize() == g2.VertexSize())) {
        this->BuildIsomorphism(g1, g2);
    }
}

} // namespace algebra

#endif /* ALGEBRA_GRAPH_GRAPHMATCHER_HPP_ */
