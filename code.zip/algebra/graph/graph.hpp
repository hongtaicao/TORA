/*
 * graph.hpp
 *
 *  Created on: 2020-1-11 19:03
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_GRAPH_GRAPH_HPP_
#define ALGEBRA_GRAPH_GRAPH_HPP_

#include <algorithm>
#include <ostream>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "algebra/basetype.hpp"
#include "algebra/io/filereader.hpp"
#include "algebra/utility/access.hpp"
#include "algebra/utility/tostring.hpp"

namespace algebra {

template<typename vertex_T>
class Graph {
public:
    typedef std::vector<vertex_T> vertex_1D_t;
    typedef std::unordered_set<vertex_T> set_t;
    typedef std::unordered_map<vertex_T, set_t *> edgemap_t;
    typedef T_2D<vertex_T> edgelist_t;

    // construct a graph by reading adjacency
    Graph(const std::string &);
    // construct a vertex induced graph on the given vertex_set
    Graph(const Graph<vertex_T> &, const set_t &);
    virtual ~Graph();

    Graph(const Graph<vertex_T> &) = delete;
    Graph &operator=(const Graph<vertex_T> &) = delete;

    inline size_type Degree(const vertex_T &, bool) const;
    inline bool HasEdge(const vertex_T &vi, const vertex_T &vj) const {
        if (this->forward_edge_.count(vi) == 0) {
            return false;
        }
        return (this->forward_edge_.at(vi)->count(vj) > 0);
    }
    inline size_type EdgeSize() const {
        return this->edge_size_;
    }
    inline const vertex_1D_t &Vertex() const {
        // should not assume vertex is sorted
        // https://stackoverflow.com/a/8005559/11193802
        return this->vertex_;
    }
    inline size_type VertexSize() const {
        return this->vertex_.size();
    }
    void Write(std::ostream &) const;

protected:
    // copy constructor
    Graph(const Graph<vertex_T> *);

    inline void SetVertexAndEdgeSize() {
        this->BuildVertex();
        this->SetEdgeSize();
    }
    void BuildVertex();
    inline void InsertEdge(vertex_T, vertex_T);
    inline void SetEdgeSize();

    edgemap_t forward_edge_;
    edgemap_t backward_edge_;
    size_type edge_size_;
    vertex_1D_t vertex_;
};

namespace graph {

template<typename vertex_T>
inline void AddToEdgeMap(vertex_T vertex_a, vertex_T vertex_b,
        typename Graph<vertex_T>::edgemap_t &edge_map) {
    if (edge_map.count(vertex_a) == 0) {
        edge_map[vertex_a] = new typename Graph<vertex_T>::set_t();
    }
    edge_map[vertex_a]->insert(vertex_b);
}

template<typename vertex_T>
size_type CountEdge(typename Graph<vertex_T>::edgemap_t &map) {
    size_type count = 0;
    for (const auto &pair : map) {
        count += pair.second->size();
    }
    return count;
}

template<typename vertex_T>
void CopyEdgeMap(const typename Graph<vertex_T>::edgemap_t &source_map,
        typename Graph<vertex_T>::edgemap_t &target_map) {
    for (const auto &pair : source_map) {
        typename Graph<vertex_T>::set_t *neighbor =
                new typename Graph<vertex_T>::set_t;
        for (const auto &vertex : (*pair.second)) {
            neighbor->insert(vertex);
        }
        target_map[pair.first] = neighbor;
    }
}

template<typename vertex_T>
void VertexInducedEdgeMap(const typename Graph<vertex_T>::edgemap_t &source_map,
        const typename Graph<vertex_T>::set_t &vertexset,
        typename Graph<vertex_T>::edgemap_t &edge_map) {
    for (const auto &pair : source_map) {
        if (vertexset.count(pair.first) > 0) {
            if (edge_map.count(pair.first) == 0) {
                edge_map[pair.first] = new typename Graph<vertex_T>::set_t();
            }
            for (const auto &neighbor : (*pair.second)) {
                if (vertexset.count(neighbor) > 0) {
                    edge_map[pair.first]->insert(neighbor);
                }
            }
        }
    }
}

template<typename vertex_T>
void WriteEdgeMap(std::ostream &out,
        const typename Graph<vertex_T>::edgemap_t &edge_map,
        const char arrow[]) {
    std::vector<vertex_T> key1D;
    SortMapKey(edge_map, key1D);
    for (const auto &key : key1D) {
        out << key << arrow << SetToString(*edge_map.at(key)) << std::endl;
    }
}

} // namespace graph

template<typename vertex_T>
void Graph<vertex_T>::BuildVertex() {
    set_t vertex;
    for (auto const &pair : this->forward_edge_) {
        vertex.insert(pair.first);
    }
    for (auto const &pair : this->backward_edge_) {
        vertex.insert(pair.first);
    }
    for (const auto &item : vertex) {
        this->vertex_.push_back(item);
    }
    // required to guarantee UFS works properly
    std::sort(this->vertex_.begin(), this->vertex_.end());
}

template<typename vertex_T>
inline size_type Graph<vertex_T>::Degree(const vertex_T &vertex,
        bool in_degree) const {
    if (in_degree) {
        if (this->forward_edge_.count(vertex) != 0) {
            return this->forward_edge_.at(vertex)->size();
        }
    } else {
        if (this->backward_edge_.count(vertex) != 0) {
            return this->backward_edge_.at(vertex)->size();
        }
    }
    return 0;
}

template<typename vertex_T>
inline void Graph<vertex_T>::InsertEdge(vertex_T vertex_a, vertex_T vertex_b) {
    graph::AddToEdgeMap(vertex_a, vertex_b, this->forward_edge_);
    graph::AddToEdgeMap(vertex_b, vertex_a, this->backward_edge_);
}

template<typename vertex_T>
inline void Graph<vertex_T>::SetEdgeSize() {
    this->edge_size_ = graph::CountEdge<vertex_T>(this->forward_edge_);
}

template<typename vertex_T>
void Graph<vertex_T>::Write(std::ostream &out) const {
    out << "====== Graph.Write(): begin ======" << std::endl;
    out << "Vertex: " << OrderedToString(this->vertex_) << std::endl;
    out << "forward_edge" << std::endl;
    graph::WriteEdgeMap<vertex_T>(out, this->forward_edge_, "->");
    out << "backward_edge" << std::endl;
    graph::WriteEdgeMap<vertex_T>(out, this->backward_edge_, "<-");
    out << "====== Graph.Write(): end ======" << std::endl;
}

// constructor
template<typename vertex_T>
Graph<vertex_T>::Graph(const std::string &query_file)
        : edge_size_(0) {
    // for reading query graph, it is assumed that no detached vertex
    FileReader reader(query_file);
    vertex_T vertex_a, vertex_b;
    while (reader.Read(vertex_a, vertex_b)) {
        this->InsertEdge(vertex_a, vertex_b);
    }
    this->SetVertexAndEdgeSize();
}

template<typename vertex_T>
Graph<vertex_T>::Graph(const Graph<vertex_T> &other, const set_t &vertexset)
        : edge_size_(0) {
    // there can be detached vertex in subgraph
    graph::VertexInducedEdgeMap<vertex_T>(other.forward_edge_, vertexset,
            this->forward_edge_);
    graph::VertexInducedEdgeMap<vertex_T>(other.backward_edge_, vertexset,
            this->backward_edge_);
    this->SetVertexAndEdgeSize();
}

template<typename vertex_T>
Graph<vertex_T>::Graph(const Graph<vertex_T> *g)
        : edge_size_(0) {
    // copy edge connection
    if (g != nullptr) {
        graph::CopyEdgeMap<vertex_T>(g->forward_edge_, this->forward_edge_);
        graph::CopyEdgeMap<vertex_T>(g->backward_edge_, this->backward_edge_);
    }
}

template<typename vertex_T>
Graph<vertex_T>::~Graph() {
    DeleteMapValue(this->forward_edge_);
    DeleteMapValue(this->backward_edge_);
}

} // namespace graph

#endif /* ALGEBRA_GRAPH_GRAPH_HPP_ */
