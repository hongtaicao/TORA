/*
 * framework.cpp
 *
 *  Created on: 2020-3-22 2:32
 *      Author: Hongtai Cao
 */

#include <iostream>

#include "algebra/algorithm/motifadjacency.hpp"
#include "algebra/argparser.hpp"
#include "algebra/evaluation.hpp"
#include "algebra/framework.hpp"
#include "algebra/optimizer/branchbound/branchbound.hpp"
#include "algebra/utility/misc.hpp"

namespace algebra {

int CommandMode(int argc, char *argv[]) {
    ArgParser argparser(argc, argv);
    argparser.TurnOffSync();
    if (argparser.Success()) {
        const timepoint_t &start = GetTimepoint();
        // optimization: find expression or find MatchOrder for expression
        if (argparser.IsBranchBound()) {
            // optimization always reads both the data and query files
            // file read time is not included in optimization cost
            branchbound::main(argparser);
        }
        // evaluation
        if (argparser.IsEvaluate()) {
            // should evaluate expression
            // create necessary input files from adjacency files as needed
            // file read time is included into total time cost
            PrepareInitialization(argparser);
            // execution: evaluate performance
            Evaluation execute(argparser);
            if (argparser.IsAdjacencyMatrix()) {
                // a[s][e][t]
                execute.EvaluateAdjacency();
            } else if (argparser.IsSubgraphMatching()) {
                // s[e][t]
                execute.EvaluateSubgraphMatching();
            } else if (argparser.IsExpression()) {
                // e[t]
                execute.EvaluateExpression();
            }
        }
        std::cout << GetCurrentTime() << " Exit. " << GetTimeCost(start)
                << " (s) total elapsed time" << std::endl;
        return 0;
    } else {
        std::cout << GetCurrentTime() << " Exit with failure. ";
        std::cout << argparser.Message() << std::endl;
        return -1;
    }
}

} // namespace algebra
