/*
 * argparser.hpp
 *
 *  Created on: 2020-7-19 10:21
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_ARGPARSER_HPP_
#define ALGEBRA_ARGPARSER_HPP_

#include <iostream>
#include <string>
#include <vector>

#include "algebra/basetype.hpp"
#include "algebra/utility/payload.hpp"

namespace algebra {

class ArgParser {
public:
    ArgParser(int argc, char *argv[])
            : argc_(argc) {
        for (int i = 0; i < argc; i++) {
            this->argv_.push_back(std::string(argv[i]));
        }
        // default value
        this->config_string_["message"] = "";
        // command
        this->config_bool_["adjacency"] = false;
        this->config_bool_["branchbound"] = false;
        this->config_bool_["expression"] = false;
        this->config_bool_["subgraph"] = false;
        this->config_bool_["transform"] = false;
        // configuration
        this->config_bool_["ablation_complement"] = false;
        this->config_bool_["ablation_order"] = false;
        this->config_bool_["ablation_share"] = false;
        this->config_bool_["leaf_filter"] = false;
        this->config_bool_["share"] = true;
        this->config_int_["adjacency_setting"] = 0;
        this->config_int_["leaf_algorithm"] = 0;
        this->config_int_["leaf_format"] = 0;
        this->config_int_["operator_algorithm"] = 0;
        this->config_int_["target"] = 0;
        // data and query
        this->config_string_["data"] = "";
        this->config_string_["query"] = "";
    }
    // bool attribute
    inline bool IsAdjacencyMatrix() const {
        return this->config_bool_.at("adjacency");
    }
    inline bool IsBranchBound() const {
        return this->config_bool_.at("branchbound");
    }
    inline bool IsEvaluate() const {
        return this->IsAdjacencyMatrix() or this->IsExpression()
                or this->IsSubgraphMatching();
    }
    inline bool IsExpression() const {
        return this->config_bool_.at("expression");
    }
    inline bool IsSubgraphMatching() const {
        return this->config_bool_.at("subgraph");
    }
    inline bool IsTransform() const {
        return this->config_bool_.at("transform");
    }
    bool Success();

    // configuration
    inline ADJACENCY_ALGORITHM Adj() const {
        return this->Adj(this->config_int_.at("adjacency_setting"));
    }
    inline ADJACENCY_ALGORITHM Adj(size_type setting) const {
        if (setting < this->adjacency_parameter_.size()) {
            return AdjacencyAlgorithm(this->adjacency_parameter_[setting][0]);
        }
        // default
        return AdjacencyAlgorithm(0);
    }
    inline ADJACENCY_FORMAT AdjFormat() const {
        return this->AdjFormat(this->config_int_.at("adjacency_setting"));
    }
    inline ADJACENCY_FORMAT AdjFormat(size_type setting) const {
        if (setting < this->adjacency_parameter_.size()) {
            return AdjacencyFormat(this->adjacency_parameter_[setting][1]);
        }
        // default
        return AdjacencyFormat(0);
    }
    inline BRANCH_ALGORITHM Br() const {
        return this->Br(this->config_int_.at("adjacency_setting"));
    }
    inline BRANCH_ALGORITHM Br(size_type setting) const {
        if (setting < this->adjacency_parameter_.size()) {
            return BranchAlgorithm(this->adjacency_parameter_[setting][2]);
        }
        // default
        return BranchAlgorithm(0);
    }
    inline LEAF_ALGORITHM Leaf() const {
        return algebra::LeafAlgorithm(this->config_int_.at("leaf_algorithm"));
    }
    inline LEAF_FORMAT LeafFormat() const {
        return algebra::LeafFormat(this->config_int_.at("leaf_format"));
    }
    inline OPERATOR_ALGORITHM Op() const {
        return OperatorAlgorithm(this->config_int_.at("operator_algorithm"));
    }
    inline REDUCE_ALGORITHM Re() const {
        return this->Re(this->config_int_.at("adjacency_setting"));
    }
    inline REDUCE_ALGORITHM Re(size_type setting) const {
        if (setting < this->adjacency_parameter_.size()) {
            return algebra::ReduceAlgorithm(
                    this->adjacency_parameter_[setting][3]);
        }
        // default
        return ReduceAlgorithm(0);
    }
    inline bool AblationComplement() const {
        return this->config_bool_.at("ablation_complement");
    }
    inline bool AblationOrder() const {
        return this->config_bool_.at("ablation_order");
    }
    inline bool AblationShare() const {
        return this->config_bool_.at("ablation_share");
    }
    inline bool LeafFilter() const {
        return this->config_bool_.at("leaf_filter");
    }
    inline bool Share() const {
        return this->config_bool_.at("share");
    }
    // query
    inline const std::string &DataFile() const {
        return this->config_string_.at("data");
    }
    inline const std::string DataFile(const std::string &name) const {
        // can't return reference
        // warning: returning reference to temporary [-Wreturn-local-addr]
        // pair list format does not have the following as the first line
        // total_vertex_count pair_list_size
        if (this->LeafFormat() == LEAF_BINARY_BLOCK) {
            /*
             * data[0] = vertex_count
             * data[1] = from_vertex
             * data[2] = from_vertex_next_index
             * data[3...from_vertex_next_index-1] = to_vertex
             * data[from_vertex_next_index] = from_vertex
             */
            return this->DataFile() + "." + name + ".block.bin";
        } else if (this->LeafFormat() == LEAF_BINARY_NEIGHBORLIST) {
            /*
             * vertex_count neighbor_count
             * from_vertex to_count to_vertex to_vertex ...
             * from_vertex to_count to_vertex to_vertex ...
             */
            return this->DataFile() + "." + name + ".neighbor.bin";
        } else if (this->LeafFormat() == LEAF_BINARY_PAIRLIST) {
            /*
             * vertex_count pair_count from_vertex to_vertex ...
             */
            return this->DataFile() + "." + name + ".pair.bin";
        } else if (this->LeafFormat() == LEAF_TEXT_NEIGHBORLIST) {
            /*
             * vertex_count neighbor_count
             * from_vertex to_count to_vertex to_vertex ...
             * from_vertex to_count to_vertex to_vertex ...
             */
            return this->DataFile() + "." + name + ".neighbor.txt";
        } else if (this->LeafFormat() == LEAF_TEXT_PAIRLIST) {
            /*
             * vertex_count pair_count
             * from_vertex to_vertex from_vertex to_vertex ...
             */
            return this->DataFile() + "." + name + ".pair.txt";
        } else {
            /*
             * from_vertex to_vertex
             * from_vertex to_vertex
             * from_vertex to_vertex
             */
            if (name == "A") {
                return this->DataFile();
            }
            return this->DataFile() + "." + name + ".txt";
        }
        std::cout << "ArgParser::Data(): error unknown LeafFormat() ["
                << this->LeafFormat() << "]" << std::endl;
        throw;
    }
    inline const std::string &Query() const {
        return this->config_string_.at("query");;
    }
    inline int Target() const {
        return this->config_int_.at("target");
    }
    // method
    inline int AdjacencySetting() const {
        return this->config_int_.at("adjacency_setting");
    }
    // these methods loop through adjacency setting
    inline int AdjacencySettingBegin() {
        // setting starts from index=0
        this->config_int_["adjacency_setting"] = 0;
        return 0;
    }
    inline bool AdjacencySettingEnd() const {
        // check whether there is more setting
        return this->AdjacencySetting()
                == (int) this->adjacency_parameter_.size();
    }
    inline size_type AdjacencySettingNext() {
        this->config_int_["adjacency_setting"] += 1;
        return this->config_int_["adjacency_setting"];
    }
    inline const std::string &Command() const {
        return this->argv_[1];
    }
    inline const std::string &Message() const {
        return this->config_string_.at("message");
    }
    // setting
    inline ArgParser *TurnOffSync() {
        // https://stackoverflow.com/a/12762166/11193802
        // turn off sync to improve std::cin performance
        // no actual performance improvement
        std::ios::sync_with_stdio(false);
        return this;
    }

    Payload payload;

private:
    bool CheckFilePath(const std::string &);
    bool Parse();
    bool ParseAdjacencyParameter(const std::string &);
    bool ParseCommand();
    ArgParser *Usage();

    // state
    int argc_;
    std::vector<std::string> argv_;

    // parse result
    std::unordered_map<std::string, bool> config_bool_;
    std::unordered_map<std::string, int> config_int_;
    std::unordered_map<std::string, std::string> config_string_;
    std::vector<std::vector<int>> adjacency_parameter_;
};

namespace argparser {

inline void UsageAdjacencyMatrix();
inline void UsageBranchBound();
inline void UsageExpression();
inline void UsageKeywordArgumentOptional();

} // namespace argparser

} // namespace algebra

#endif /* ALGEBRA_ARGPARSER_HPP_ */
