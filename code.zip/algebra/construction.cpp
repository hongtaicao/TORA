/*
 * construction.cpp
 *
 *  Created on: 2020-1-8 16:40
 *      Author: Hongtai Cao
 */

#include <algorithm>
#include <assert.h>
#include <iostream>
#include <unordered_map>
#include <unordered_set>

#include "algebra/application.hpp"
#include "algebra/argparser.hpp"
#include "algebra/basetype.hpp"
#include "algebra/construction.hpp"
#include "algebra/expression/basenode.hpp"
#include "algebra/expression/leaf.hpp"
#include "algebra/expression/motifnode/motifnode.hpp"
#include "algebra/io/writer.hpp"
#include "algebra/utility/access.hpp"
#include "algebra/utility/tostring.hpp"

namespace algebra {

// public method
Construction *Construction::BuildAdjacency(const graph_t &graph) {
    // [b]ae[t]  -e "adjacency_expression", evaluate as is
    if ((not this->argparser_.payload.Expression().empty()
            and this->argparser_.IsExpression())
            and (not this->argparser_.IsSubgraphMatching())) {
        // adjacency expression is given
        this->BuildExpression(this->argparser_.payload.Expression());
    } else {
        // [b]as -e "subgraph_expression", need to find MatchOrder
        this->analyser_ = new analyser_t(graph);
        for (this->argparser_.AdjacencySettingBegin();
                not this->argparser_.AdjacencySettingEnd();
                this->argparser_.AdjacencySettingNext()) {
            // this can build multiple applications
            if (this->argparser_.Adj() == ADJ_ECLASS) {
                if (not this->argparser_.payload.Expression().empty()) {
                    // subgraph expression is given
                    PRINTLINE("== GenerateAdjacencyByTranspose() begin ==");
                    const auto &order = this->argparser_.payload.MatchOrder();
                    query_size_t vi = order.front();
                    query_size_t vj = order.back();
                    axis_t remaining(order.begin() + 1, order.end() - 1);
                    scalar_t scalar = this->analyser_->OrbitScale(vi, vj,
                            remaining);
                    this->BuildExpression(
                            this->argparser_.payload.Expression());
                    Application *app = this->app_1D_.back();
                    this->GenerateAdjacency(
                            this->GenerateAdjacencyByTransposeForBranch(
                                    app->Subgraph(), scalar,
                                    axis_t(order.begin(), order.end())));
                    PRINTLINE("== GenerateAdjacencyByTranspose() end ==");
                } else {
                    axis_t *vi_list = nullptr;
                    axis_t *vj_list = nullptr;
                    seq_1D_t *sequence_list = nullptr;
                    this->analyser_->MatchEclassEdge(vi_list, vj_list,
                            sequence_list);
                    if (this->argparser_.Br() == BR_TRANSPOSE) {
                        this->GenerateAdjacencyByTranspose(vi_list, vj_list,
                                sequence_list);
                    } else if (this->argparser_.Br() == BR_MATCH) {
                        this->GenerateAdjacencyByEdgeOrbit(vi_list, vj_list,
                                sequence_list);
                    }
                }
            } else if (this->argparser_.Adj() == ADJ_PERMUTATION) {
                this->GenerateAdjacencyByPermutation();
            }
        }
    }
    return this;
}

Construction *Construction::BuildSubgraph(const graph_t &graph) {
    if (not this->argparser_.payload.Expression().empty()) {
        // expression is available
        // can be from either optimization or input
        return this->BuildExpression(this->argparser_.payload.Expression());
    }
    this->analyser_ = new analyser_t(graph);
    const auto &vertexlist = this->analyser_->Vertex();
    std::unordered_set<std::string> known_branch;
    for (size_type i = 0; i < vertexlist.size(); i++) {
        query_size_t vi = vertexlist[i];
        for (size_type j = 0; j < vertexlist.size(); j++) {
            if (j == i) {
                continue;
            }
            query_size_t vj = vertexlist[j];
            // choose one sequence to compute subgraph matching
            axis_t remaining;
            for (const auto &vertex : vertexlist) {
                if ((vertex != vi) and (vertex != vj)) {
                    remaining.push_back(vertex);
                }
            }
            std::sort(remaining.begin(), remaining.end());
            do {
                std::string branch = this->SubgraphExpression(vi, vj,
                        &remaining);
                if (known_branch.count(branch) == 0) {
                    // evaluate the same equation only once
                    known_branch.insert(branch);
                    Application *application = this->InitializeApplication();
                    this->GenerateSubgraph(application, vi, vj, &remaining);
                }
            } while (next_permutation(remaining.begin(), remaining.end()));
        }
    }
    return this;
}

Construction *Construction::BuildExpression(const std::string &query_expr) {
    Application *application = this->InitializeApplication();
    application->Subgraph(this->Parse(query_expr));
    application->match_order = OrderedToString(
            this->argparser_.payload.MatchOrder());
    return this;
}

void Construction::PrintExpression() const {
    for (size_type key = 0; key < this->app_1D_.size(); key++) {
        std::cout << "=== Construction::PrintExpression() index: " << key
                << " begin ===" << std::endl;
        for (auto &pair : this->GetIndex(key)) {
            std::cout << pair.second << "->" << pair.first << std::endl;
        }
        std::cout << "=== Construction::PrintExpression() index: " << key
                << " end ===" << std::endl;
    }
}

// private method
BaseNode *Construction::CreateLeafAdjacency(const std::string &expression) {
    assert(this->IsLeaf(expression));
    if (this->HasCache(expression)) {
        return this->GetCache(expression);
    }
    BaseNode *node = nullptr;
    if (expression == "A") {
        node = new AdjacencyNode(expression);
    } else if (expression == "B") {
        axis_t *axis = new axis_t( { 1, 0 });
        node = new BinaryNode(expression, MASK_OP, this->CreateLeaf("A"),
                this->CreateTranspose(this->CreateLeaf("A"), axis));
    } else if (expression == "U") {
        if (this->HasCache("UT")) {
            axis_t *axis = new axis_t( { 1, 0 });
            node = this->CreateTranspose(this->GetCache("UT"), axis);
            this->EraseCache(node->Expression());
            node->Expression(expression);
        } else {
            node = new BinaryNode(expression, MINUS_OP, this->CreateLeaf("A"),
                    this->CreateLeaf("B"));
        }
    } else if (expression == "UT") {
        if (this->HasCache("U")) {
            axis_t *axis = new axis_t( { 1, 0 });
            node = this->CreateTranspose(this->GetCache("U"), axis);
        } else {
            node = new BinaryNode("U", MINUS_OP, this->CreateLeaf("A"),
                    this->CreateLeaf("B"));
            this->AddCache("U", node);
            axis_t *axis = new axis_t( { 1, 0 });
            node = this->CreateTranspose(node, axis);
        }
        this->EraseCache(node->Expression());
        node->Expression(expression);
    } else if (expression == "N") {
        if (this->argparser_.AblationComplement()) {
            std::cout << "NotImplemented" << std::endl;
            throw;
        } else {
            node = new ComplementNode(expression, this->CreateLeaf("A"),
                    this->CreateLeaf("UT"));
        }
    } else {
        std::cout << "Construction::CreateLeafAdjacency(): unknown leaf="
                << expression << std::endl;
        throw;
    }
    return node;
}

BaseNode *Construction::CreateLeaf(const std::string &expression) {
    if (this->HasCache(expression)) {
        return this->GetCache(expression);
    }
    BaseNode *node = nullptr;
    if (this->argparser_.Leaf() == LEAF_ADJACENCY_EVALUATE) {
        node = this->CreateLeafAdjacency(expression);
    } else {
        node = new AdjacencyNode(expression);
    }
    this->AddCache(expression, node);
    this->app_1D_.back()->leaf.Add(expression, node);
    return node;
}

BaseNode *Construction::CreateLeafFilter(const std::string &expression,
        const std::string &op, const std::string &arg_1,
        const std::string &arg_2) {
    // a leaf with argument, argument processing is in Expression
    // leaf node expr is used in MaskAxis. same name allows sharing
    // other case does not impact performance
    BaseNode *node = nullptr;
    if (this->argparser_.LeafFilter()) {
        // leaf degree filter on
        if (this->HasCache(expression)) {
            node = this->GetCache(expression);
        } else {
            // create leaf
            if (this->argparser_.Leaf() == LEAF_ADJACENCY_EVALUATE) {
                node = this->CreateLeafAdjacency(op);
            } else {
                node = new AdjacencyNode(expression);
            }
            this->AddCache(expression, node);
            this->app_1D_.back()->leaf.Add(op, node, arg_1, arg_2);
        }
    } else {
        // leaf degree filter off
        // use building block name for sharing purpose
        node = this->CreateLeaf(op);
    }
    return node;
}

BaseNode *Construction::CreateMask(query_size_t vi, query_size_t vj,
        axis_t *sequence) {
    std::string expression = this->analyser_->MaskExpression(vi, vj, sequence);
    if (this->HasCache(expression)) {
        return this->GetCache(expression);
    }
    BaseNode *node = nullptr;
    if ((sequence != nullptr) && (sequence->size() > 0)) {
        // internal node: mask
        BaseNode *merge_node = this->CreateMerge(vi, vj, sequence);
        BaseNode *mask_node = this->CreateMask(vi, vj, nullptr);
        node = new BinaryNode(expression, MASK_OP, merge_node, mask_node);
        this->AddCache(expression, node);
    } else {
        // leaf node
        node = this->CreateLeaf(expression);
    }
    return node;
}

BaseNode *Construction::CreateMaskMerge(query_size_t vi, query_size_t vj,
        axis_t *sequence) {
    // sequence can't be nullptr
    std::string expression = this->analyser_->MaskMergeExpression(vi, vj,
            sequence);
    if (this->HasCache(expression)) {
        return this->GetCache(expression);
    }
    BaseNode *node = nullptr;
    if (sequence->size() > 1) {
        // internal node: mask
        query_size_t vk = sequence->back();
        sequence->pop_back();
        BaseNode *left_node = this->CreateMaskMerge(vi, vk, sequence);
        sequence->push_back(vk);
        vk = sequence->front();
        sequence->pop_front();
        BaseNode *right_node = this->CreateMaskMerge(vk, vj, sequence);
        sequence->push_front(vk);
        BaseNode *mask_node = this->CreateMask(vi, vj, nullptr);
        node = new MaskMergeNode(expression, left_node, right_node, mask_node);
    } else {
        // sequence->size() == 1
        query_size_t vk = sequence->front();
        std::string left = this->analyser_->MaskExpression(vi, vk, nullptr);
        std::string right = this->analyser_->MaskExpression(vk, vj, nullptr);
        std::string mask = this->analyser_->MaskExpression(vi, vj, nullptr);
        node = new MaskMergeNode(expression, this->CreateLeaf(left),
                this->CreateLeaf(right), this->CreateLeaf(mask));
    }
    this->AddCache(expression, node);
    return node;
}

BaseNode *Construction::CreateMerge(query_size_t vi, query_size_t vj,
        axis_t *sequence) {
    std::string expression = this->analyser_->MergeExpression(vi, vj, sequence);
    if (this->HasCache(expression)) {
        return this->GetCache(expression);
    }
    // left
    query_size_t vk = sequence->back();
    sequence->pop_back();
    BaseNode *node1 = this->CreateMask(vi, vk, sequence);
    sequence->push_back(vk);
    // right
    vk = sequence->front();
    sequence->pop_front();
    BaseNode *node2 = this->CreateMask(vk, vj, sequence);
    sequence->push_front(vk);
    // merge
    BaseNode *merge_node = new BinaryNode(expression, MERGE_OP, node1, node2);
    this->AddCache(expression, merge_node);
    return merge_node;
}

BaseNode *Construction::CreateReduce(BaseNode *node, axis_t *axis) {
    std::string expression = "Reduce(" + node->Expression() + ",[";
    T_1D2String<query_size_t>(axis, expression);
    expression += "])";
    if (this->HasCache(expression)) {
        return this->GetCache(expression);
    }
    BaseNode *reduce_node = new AxisNode(expression, REDUCE_OP, node, axis);
    this->AddCache(expression, reduce_node);
    return reduce_node;
}

BaseNode *Construction::CreateScale(BaseNode *node, scalar_t scale) {
    if (scale == 1) {
        return node;
    }
    std::string expression = "Scale(" + node->Expression() + ","
            + std::to_string(scale) + ")";
    if (this->HasCache(expression)) {
        return this->GetCache(expression);
    }
    BaseNode *scale_node = new ScaleNode(expression, node, scale);
    this->AddCache(expression, scale_node);
    return scale_node;
}

BaseNode *Construction::CreateSum(node_1D_t *node_1D) {
    // concatenate expression
    assert(node_1D->size() > 1);
    std::vector<std::string> expression_1D;
    for (const auto &it : (*node_1D)) {
        expression_1D.push_back(it->Expression());
    }
#ifdef OPTIONAL
    // TODO optional
    std::sort(expression_1D.begin(), expression_1D.end());
#endif
    std::string expression = "Sum(";
    auto it = expression_1D.begin();
    for (; it != expression_1D.end() - 1; it++) {
        expression += ((*it) + ",");
    }
    expression += ((*it) + ")");
    if (this->HasCache(expression)) {
        return this->GetCache(expression);
    }
    BaseNode *sum_node = new SumNode(expression, node_1D);
    this->AddCache(expression, sum_node);
    return sum_node;
}

BaseNode *Construction::CreateTranspose(BaseNode *node, axis_t *axis) {
    std::string expression = "Transpose(" + node->Expression() + ",[";
    T_1D2String<query_size_t>(axis, expression);
    expression += "])";
    if (this->HasCache(expression)) {
        return this->GetCache(expression);
    }
    BaseNode *transpose_node = new AxisNode(expression, TRANSPOSE_OP, node,
            axis);
    this->AddCache(expression, transpose_node);
    return transpose_node;
}

InputNode *Construction::CreateInput() {
    BaseNode *node = this->app_1D_.back()->Subgraph();
    std::string expression = this->InputExpression();
    if (this->HasCache(expression)) {
        return (InputNode *) this->GetCache(expression);
    }
    InputNode *input_node = new InputNode(expression, node,
            this->argparser_.AdjFormat());
    this->AddCache(input_node->Expression(), input_node);
    return input_node;
}

void Construction::GenerateAdjacency(BaseNode *adjacency) {
    Application *app = this->app_1D_.back();
    app->adjacency_setting = this->argparser_.AdjacencySetting();
    assert(app->Subgraph() != nullptr);
    std::string expression = this->AdjacencyExpression(adjacency->Expression());
    // check if in the cache
    if (this->HasCache(expression)) {
        app->adjacency = (MotifBaseNode *) this->GetCache(expression);
        return;
    }
    // create adjacency
    if (this->argparser_.Re() == REDUCE_UNIQUE) {
        if (this->argparser_.AdjFormat() == ADJ_TABLE) {
            app->adjacency = new BaselineNode(expression, this->CreateInput());
        } else {
            // default AdjacencyFormat
            app->adjacency = new ReduceUniqueNode(expression,
                    this->CreateInput());
        }
    } else {
        // default ReduceAlgorithm
        if (this->argparser_.AdjFormat() == ADJ_TABLE) {
            app->adjacency = new ScaleReduceNode(expression,
                    this->CreateInput());
        } else {
            // default AdjacencyFormat
            app->adjacency = new MotifNode(expression, this->CreateInput(),
                    adjacency);
        }
    }
    // add cache
    this->AddCache(app->adjacency->Expression(), app->adjacency);
}

/*
 * choose one edge orbit for match, p edge orbits total
 * for each edge orbit i of p choose one way to Generate(), n_i expressions
 * total expressions: n_1 * n_2 * n_3 * n_4 ... * n_p
 * however, at this point, this method Generate() only 1 expression
 */
void Construction::GenerateAdjacencyByEdgeOrbit(axis_t *vi_list,
        axis_t *vj_list, seq_1D_t *sequence_list) {
    Application *expression = this->InitializeApplication();
    BaseNode *branch_node = nullptr;
    node_1D_t *node_1D = new node_1D_t;
    for (size_type i = 0; i < sequence_list->size(); i++) {
        // choose vi ... vj as branch node
        query_size_t vi = vi_list->at(i), vj = vj_list->at(i);
        axis_t *remaining = sequence_list->at(i);
        if (i > 0) {
            // update match_order_ and separate them
            expression->match_order.append("/");
        }
        branch_node = this->GenerateSubgraph(expression, vi, vj, remaining);
        axis_t *branch_axis = new axis_t;
        branch_axis->push_back(0);
        branch_axis->push_back(remaining->size() + 1);
        BaseNode *reduce = this->CreateReduce(branch_node, branch_axis);
        scalar_t scalar = this->analyser_->OrbitScale(vi, vj, *remaining);
        node_1D->push_back(this->CreateScale(reduce, scalar));
    }
    // force update subgraph to the last branch
    expression->Subgraph(branch_node);
    this->GenerateAdjacency(this->CreateSum(node_1D));
}

void Construction::GenerateAdjacencyByPermutation() {
    std::cout << "Construction::GenerateByPermutation(): not implemented"
            << std::endl;
    throw;
}

/*
 * choose one branch_node for compute subgraph, p branches in total
 * for each branch i of p choose one way to Generate(), n_i expressions
 * total expressions: n_1 + n_2 + n_3 + .. n_p
 */
void Construction::GenerateAdjacencyByTranspose(axis_t *vi_list,
        axis_t *vj_list, seq_1D_t *sequence_list) {
    std::unordered_set<std::string> known_branch;
    for (size_type i = 0; i < sequence_list->size(); i++) {
        // choose vi ... vj as branch node
        query_size_t vi = vi_list->at(i), vj = vj_list->at(i);
        axis_t remaining(*sequence_list->at(i));
        std::sort(remaining.begin(), remaining.end());
        // choose one sequence to compute subgraph matching
        do {
            std::string branch = this->SubgraphExpression(vi, vj, &remaining);
            if (known_branch.count(branch) == 0) {
                // evaluate the same equation only once
                known_branch.insert(branch);
                PRINT("== GenerateAdjacencyByTranspose() ");
                PRINT(std::to_string(this->app_1D_.size()));
                PRINTLINE(" begin ==");
                Application *expression = this->InitializeApplication();
                BaseNode *branch_node = this->GenerateSubgraph(expression, vi,
                        vj, &remaining);
                scalar_t scalar = this->analyser_->OrbitScale(vi, vj,
                        remaining);
                axis_t merged_sequence(this->analyser_->VertexSize());
                MergeTogether(vi, vj, &remaining, merged_sequence);
                this->GenerateAdjacency(
                        this->GenerateAdjacencyByTransposeForBranch(branch_node,
                                scalar, merged_sequence));
                PRINT("== GenerateAdjacencyByTranspose():");
                PRINT(std::to_string(this->app_1D_.size()));
                PRINTLINE(" end ==");
            }
        } while (next_permutation(remaining.begin(), remaining.end()));
    }
}

BaseNode *Construction::GenerateAdjacencyByTransposeForBranch(
        BaseNode *branch_node, const scalar_t scalar,
        const axis_t &branch_sequence) {
    axis_t *vi_list = nullptr;
    axis_t *vj_list = nullptr;
    typename analyser_t::seq_1D_t *sequence_list = nullptr;
    this->analyser_->MatchEclassEdge(vi_list, vj_list, sequence_list);
    // avoid SumNode if there is only one branch
    axis_t *branch_axis = new axis_t;
    branch_axis->push_back(0);
    branch_axis->push_back(sequence_list->at(0)->size() + 1);
    BaseNode *reduce_node = this->CreateReduce(branch_node, branch_axis);
    BaseNode * const single_branch = this->CreateScale(reduce_node, scalar);
    if (vi_list->size() == 1) {
        return single_branch;
    }
    // prepare for the transpose axis
    scalar_t reduce_scale;
    node_1D_t *node_1D = new node_1D_t;
    size_type query_size = this->analyser_->VertexSize();
    std::unordered_map<query_size_t, query_size_t> vertex2axis;
    for (size_type i = 0; i < query_size; i++) {
        vertex2axis[branch_sequence[i]] = i;
    }
    // compute node_1D
    for (unsigned int i = 0; i < vi_list->size(); i++) {
        query_size_t ui = vi_list->at(i), uj = vj_list->at(i);
        axis_t *u_sequence = sequence_list->at(i);
        if ((ui == branch_sequence.front())
                and (uj == branch_sequence.back())) {
            node_1D->push_back(single_branch);
        } else {
            axis_t *u_axis = new axis_t;
            u_axis->push_back(vertex2axis.at(ui));
            u_axis->push_back(vertex2axis.at(uj));
            BaseNode *new_branch = branch_node;
            if ((this->argparser_.AdjFormat() == ADJ_FOREST)
                    and (this->argparser_.Re() == SCALE_REDUCE)) {
                // only SCALE_REDUCE on ADJ_FOREST share branch
                new_branch = branch_node->ShallowCopy();
            }
            reduce_node = this->CreateReduce(new_branch, u_axis);
            reduce_scale = this->analyser_->OrbitScale(ui, uj, *u_sequence);
            node_1D->push_back(this->CreateScale(reduce_node, reduce_scale));
        }
    }
    return this->CreateSum(node_1D);
}

Construction::~Construction() {
    delete this->analyser_;
    DeleteContent(this->app_1D_);
}

Construction::Construction(ArgParser &argparser)
        : argparser_(argparser), analyser_(nullptr) {
    // no data read. here only set the algorithm
}

} // namespace algebra
