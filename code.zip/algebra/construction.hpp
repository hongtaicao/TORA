/*
 * construction.hpp
 *
 *  Created on: 2020-1-4 16:17
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_CONSTRUCTION_HPP_
#define ALGEBRA_CONSTRUCTION_HPP_

#include <assert.h>
#include <string>
#include <vector>

#include "algebra/application.hpp"
#include "algebra/argparser.hpp"
#include "algebra/basetype.hpp"
#include "algebra/expression/basenode.hpp"
#include "algebra/expression/creator.hpp"
#include "algebra/expression/leaf.hpp"
#include "algebra/expression/motifnode/motifnode.hpp"
#include "algebra/graph/analyser.hpp"

namespace algebra {

class Construction: public Creator {
private:
    typedef typename Application::node_index_t node_index_t;

    typedef Analyser<query_size_t> analyser_t;
    typedef analyser_t::seq_1D_t seq_1D_t;

    typedef Creator::axis_1D_t axis_1D_t;
    typedef Creator::node_1D_t node_1D_t;

public:
    typedef analyser_t::graph_t graph_t;
    typedef Creator::axis_t axis_t;

    /*
     * each instance works on all query plans for given algorithms and graphs
     */
    Construction(ArgParser &argparser);
    ~Construction() override;

    Construction(const Construction &) = delete;
    Construction &operator=(const Construction &) = delete;

    // create expression from path-to-query-graph
    Construction *BuildAdjacency(const graph_t &);
    Construction *BuildSubgraph(const graph_t &);
    // create expression from string
    Construction *BuildExpression(const std::string &);

    inline size_type ApplicationCount() const {
        return this->app_1D_.size();
    }
    inline Application *GetApplication(const size_type key) const {
        return this->app_1D_[key];
    }
    inline void LoadApplication(const Construction *construction) {
        this->app_1D_ = construction->app_1D_;
    }
    void PrintExpression() const;
    inline Construction *SortApplication() {
        std::sort(this->app_1D_.begin(), this->app_1D_.end(),
                Application::Compare);
        return this;
    }

private:
    // build node from expression
    BaseNode *CreateLeaf(const std::string &) override;
    BaseNode *CreateLeafAdjacency(const std::string &);
    BaseNode *CreateLeafFilter(const std::string &, const std::string &,
            const std::string &, const std::string &) override;

    // build node for the computation graph
    BaseNode *CreateMask(query_size_t, query_size_t, axis_t *);
    BaseNode *CreateMaskMerge(query_size_t, query_size_t, axis_t *);
    BaseNode *CreateMerge(query_size_t, query_size_t, axis_t *);
    BaseNode *CreateReduce(BaseNode *, axis_t *);
    BaseNode *CreateScale(BaseNode *, scalar_t);
    BaseNode *CreateSum(node_1D_t *);
    BaseNode *CreateTranspose(BaseNode *, axis_t *);
    InputNode *CreateInput();
    // create subgraph matching expression
    inline BaseNode *GenerateSubgraph(Application *expression, query_size_t vi,
            query_size_t vj, axis_t *sequence) {
        if (this->argparser_.Op() == OP_MASKMERGE) {
            expression->Subgraph(this->CreateMaskMerge(vi, vj, sequence));
        } else if (this->argparser_.Op() == OP_BASIC) {
            expression->Subgraph(this->CreateMask(vi, vj, sequence));
        }
        // append match_order_
        axis_t merged_sequence(this->analyser_->VertexSize());
        MergeTogether(vi, vj, sequence, merged_sequence);
        T_1D2String<query_size_t>(&merged_sequence, expression->match_order);
        return expression->Subgraph();
    }
    // create motif adjacency expression
    void GenerateAdjacency(BaseNode *);
    void GenerateAdjacencyByEdgeOrbit(axis_t *vi_list, axis_t *vj_list,
            seq_1D_t *);
    void GenerateAdjacencyByPermutation();
    void GenerateAdjacencyByTranspose(axis_t *vi_list, axis_t *vj_list,
            seq_1D_t *);
    BaseNode *GenerateAdjacencyByTransposeForBranch(BaseNode *, const scalar_t,
            const axis_t &);

    inline node_index_t &GetIndex(size_type key) const {
        return this->GetApplication(key)->node_index;
    }
    inline std::string AdjacencyExpression(
            const std::string &expression) const {
        if (this->argparser_.Re() == SCALE_REDUCE) {
            // SCALE_REDUCE(AdjFormat(adjacency_expression))
            // required for ADJ_TABLE because it parses scalar and reduce
            return ConfigName(this->argparser_.Re()) + "("
                    + ConfigName(this->argparser_.AdjFormat()) + "("
                    + expression + "))";
        } else {
            // Re(AdjFormat(subgraph_expression))
            return ConfigName(this->argparser_.Re()) + "("
                    + this->InputExpression() + ")";
        }
    }
    inline std::string InputExpression() const {
        return ConfigName(this->argparser_.AdjFormat()) + "("
                + this->app_1D_.back()->Subgraph()->Expression() + ")";
    }
    inline std::string SubgraphExpression(query_size_t vi, query_size_t vj,
            axis_t *sequence) {
        if (this->argparser_.Op() == OP_MASKMERGE) {
            return this->analyser_->MaskMergeExpression(vi, vj, sequence);
        } else if (this->argparser_.Op() == OP_BASIC) {
            return this->analyser_->MaskExpression(vi, vj, sequence);
        }
        return "";
    }

    // handle expression node index
    inline void AddCache(const std::string &expression, BaseNode *node)
            override {
        if (this->IsLeaf(expression) or this->argparser_.Share()) {
            // always share if leaf
            // always share if share enabled (DEFAULT)
            this->Cache()[expression] = node;
        } else {
            this->Cache()[expression + std::to_string(this->Cache().size())] =
                    node;
        }
    }
    inline node_index_t &Cache() const {
        return this->app_1D_.back()->node_index;
    }
    inline void EraseCache(const std::string &expression) const {
        this->Cache().erase(expression);
    }
    inline BaseNode *GetCache(const std::string &expression) override {
        return this->Cache()[expression]->ShallowCopy();
    }
    inline bool HasCache(const std::string &expression) override {
        return this->Cache().count(expression) != 0;
    }
    inline bool IsLeaf(const std::string &expression) {
        return (expression == "A") or (Leaf::LEAF_SET.count(expression) > 0);
    }
    // set Application that stores shared computation node
    inline Application *InitializeApplication() {
        this->app_1D_.push_back(new Application);
        return this->app_1D_.back();
    }

    // member
    ArgParser &argparser_;
    analyser_t *analyser_;
    std::vector<Application *> app_1D_;
};

} // namespace algebra

#endif /* ALGEBRA_CONSTRUCTION_HPP_ */
