/*
 * motifadjacency.cpp
 *
 *  Created on: 2020-7-28 19:17
 *      Author: Hongtai Cao
 */

#include <iostream>
#include <string>

#include "algebra/algorithm/motifadjacency.hpp"
#include "algebra/argparser.hpp"
#include "algebra/basetype.hpp"
#include "algebra/construction.hpp"
#include "algebra/io/logger.hpp"
#include "algebra/utility/misc.hpp"

namespace baseline {

void ReportAdjacency(algebra::Logger &logger, const double cost_sort,
        const double cost_build, algebra::size_type element_sum,
        const bool is_match) {
    logger.AddResult("baseline_cost_sort", std::to_string(cost_sort));
    logger.AddResult("baseline_cost_build", std::to_string(cost_build));
    logger.AddResult("baseline_cost_adjacency_total",
            std::to_string(cost_sort + cost_build));
    logger.AddResult("baseline_MatrixElementSum", std::to_string(element_sum));
    logger.AddResult("compare_AdjacencyMatch", BOOL_STRING(is_match));
    std::cout << algebra::GetCurrentTime() << " Match " << std::boolalpha
            << is_match << " baseline_cost_adjacency_total "
            << cost_sort + cost_build << " (s) baseline_cost_sort " << cost_sort
            << " (s) baseline_cost_build " << cost_build << " (s) ElementSum "
            << element_sum << std::endl;
}

} // namespace baseline

namespace motifadjacency {

typedef algebra::data_size_t data_size_t;

void AdjacencyCompare(algebra::ArgParser &argparser) {
    Logger logger("adjacency_compare");
    logger.Start();
    convert::Table2D<data_size_t> subgraph_2D;
    Construction builder(argparser);
    // compute subgraph using the algebra for both adjacency comparison
    motifadjacency::ComputeSubgraph(subgraph_2D, argparser, builder, logger);
    // time adjacency using the algebra and convert result for comparison
    baseline::matrix_T<data_size_t> algebra_adjacency;
    BaseNode *adjacency_node = motifadjacency::ComputeAdjacency(
            algebra_adjacency, argparser, builder, logger);
    // time adjacency using straight forward method
    baseline::matrix_T<data_size_t> baseline_adjacency;
    // sort
    double cost_sort = baseline::SortSubgraph(subgraph_2D);
    // build
    double cost_build = baseline::ComputeAdjacency(baseline_adjacency,
            subgraph_2D);
    // report
    baseline::ReportAdjacency(logger, cost_sort, cost_build,
            baseline_adjacency.Sum(),
            algebra_adjacency.Equal(baseline_adjacency));
    // clean up
    adjacency_node->EvaluateDone();
    logger.WriteFile();
}

} // namespace motifadjacency
