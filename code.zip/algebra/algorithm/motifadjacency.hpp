/*
 * motifadjacency.hpp
 *
 *  Created on: 2020-7-20 19:35
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_ALGORITHM_MOTIFADJACENCY_HPP_
#define ALGEBRA_ALGORITHM_MOTIFADJACENCY_HPP_

#include <string>

#include "algebra/argparser.hpp"
#include "algebra/basetype.hpp"
#include "algebra/construction.hpp"
#include "algebra/evaluation.hpp"
#include "algebra/io/logger.hpp"
#include "algebra/storage/convert/coordinate2d.hpp"
#include "algebra/storage/convert/table2d.hpp"
#include "algebra/storage/storage.hpp"
#include "algebra/utility/access.hpp"
#include "algebra/utility/compare.hpp"
#include "algebra/utility/misc.hpp"

namespace baseline {

template<typename item_T>
using matrix_T = convert::Coordinate2D<item_T>;

template<typename item_T>
using table_T = convert::Table2D<item_T>;

template<typename item_T>
void AddMotif(matrix_T<item_T> &adjacency,
        typename table_T<item_T>::item_1D_t *subgraph) {
    for (algebra::size_type row = 0; row < subgraph->size(); row++) {
        for (algebra::size_type col = 0; col < subgraph->size(); col++) {
            if (row != col) {
                adjacency.Add(algebra::Get(subgraph, row),
                        algebra::Get(subgraph, col));
            }
        }
    }
}

void ReportAdjacency(algebra::Logger &logger, const double, const double,
        algebra::size_type, const bool);

template<typename item_T>
double SortSubgraph(table_T<item_T> &table2D) {
    const algebra::timepoint_t &start = algebra::GetTimepoint();
    table2D.Sort();
    return algebra::GetTimeCost(start);
}

template<typename item_T>
double ComputeAdjacency(matrix_T<item_T> &baseline_adjacency,
        const table_T<item_T> &subgraph_2D) {
    // build
    const algebra::timepoint_t &start = algebra::GetTimepoint();
    if (subgraph_2D.RowSize() > 0) {
        AddMotif(baseline_adjacency, subgraph_2D.Get(0));
    }
    for (algebra::size_type i = 1; i < subgraph_2D.RowSize(); i++) {
        if (algebra::Equal1D(subgraph_2D.Get(i), subgraph_2D.Get(i - 1))) {
            continue;
        }
        AddMotif(baseline_adjacency, subgraph_2D.Get(i));
    }
    // build cost
    return algebra::GetTimeCost(start);
}

} // namespace baseline

namespace motifadjacency {

typedef algebra::ArgParser ArgParser;
typedef algebra::BaseNode BaseNode;
typedef algebra::Construction Construction;
typedef algebra::Logger Logger;
typedef algebra::size_type size_type;
typedef algebra::timepoint_t timepoint_t;

template<typename item_T>
BaseNode *ComputeAdjacency(baseline::matrix_T<item_T> &algebra_adjacency,
        ArgParser &argparser, Construction &builder, Logger &logger) {
    BaseNode *adjacency_node =
            builder.GetApplication(argparser.Target())->adjacency;
    const timepoint_t &start_adjacency = algebra::GetTimepoint();
    algebra::Storage<item_T> *algebra_result = adjacency_node->Evaluate();
    double cost_adjacency = algebra::GetTimeCost(start_adjacency);
    // convert format: storage -> table2D -> coordiante2D
    const timepoint_t &start = algebra::GetTimepoint();
    baseline::table_T<item_T> algebra_2D;
    algebra_result->To_2D(algebra_2D);
    algebra_2D.ToCoordinate2D(algebra_adjacency);
    algebra::GetTimeCost(start);
    // report
    algebra::execution::ReportAdjacency(logger, cost_adjacency, cost_adjacency,
            algebra_adjacency.Sum(),
            algebra::ConfigName(algebra::AdjacencyAlgorithm(argparser.Adj())),
            algebra::ConfigName(algebra::BranchAlgorithm(argparser.Br())),
            builder.GetApplication(argparser.Target())->adjacency->Expression());
    return adjacency_node;
}

template<typename item_T>
double ComputeSubgraph(convert::Table2D<item_T> &target_subgraph_2D,
        algebra::ArgParser &argparser, algebra::Construction &builder,
        Logger &logger) {
    // compute subgraph result
    const timepoint_t &start_construct = algebra::GetTimepoint();
    builder.BuildAdjacency(argparser.Query())->SortApplication();
    double expression_cost = algebra::GetTimeCost(start_construct);
    builder.GetApplication(argparser.Target())->EvaluateLeaf(argparser);
    double cost_construct = algebra::GetTimeCost(start_construct);
    const timepoint_t &start_subgraph = algebra::GetTimepoint();
    BaseNode *node = builder.GetApplication(argparser.Target())->Subgraph();
    algebra::Storage<item_T> *algebra_subgraph = node->Evaluate();
    double cost_subgraph = algebra::GetTimeCost(start_subgraph);
    algebra::execution::ReportConstruction(logger, argparser, expression_cost,
            argparser.Target(), builder.ApplicationCount(), node->Expression());
    algebra::execution::ReportSubgraph(logger, argparser, cost_subgraph,
            cost_construct + cost_subgraph, algebra_subgraph->MatchCount(),
            builder.GetApplication(argparser.Target())->match_order,
            node->Expression());
    // prepare subgraph result
    /*
     * bug: pure virtual method called
     * algebra_subgraph is an internal node of the expression node
     * it is complete when it is first computed during Subgraph.Evaluate()
     * it is then deleted when it is used during Adjacency.Evaluate()
     * therefore it is incomplete after Adjacency.Evaluate()
     */
    algebra_subgraph->To_2D(target_subgraph_2D);
    return cost_subgraph;
}

void AdjacencyCompare(ArgParser &);

} // namespace motifadjacency

#endif /* ALGEBRA_ALGORITHM_MOTIFADJACENCY_HPP_ */
