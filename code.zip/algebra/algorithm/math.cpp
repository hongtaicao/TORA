/*
 * math.cpp
 *
 *  Created on: 2020-8-27 21:43
 *      Author: Hongtai Cao
 */

#include "algebra/algorithm/math.hpp"
#include "algebra/basetype.hpp"

namespace algebra {

size_type factorial(const size_type n) {
    size_type result = 1;
    for (size_type i = 1; i <= n; i++) {
        result *= i;
    }
    return result;
}

} // namespace algebra
