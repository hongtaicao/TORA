/*
 * math.hpp
 *
 *  Created on: 2020-8-27 21:41
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_ALGORITHM_MATH_HPP_
#define ALGEBRA_ALGORITHM_MATH_HPP_

#include "algebra/basetype.hpp"

namespace algebra {

size_type factorial(const size_type n);

} // namespace

#endif /* ALGEBRA_ALGORITHM_MATH_HPP_ */
