/*
 * unionfindset.hpp
 *
 *  Created on: 2020-1-9 16:57
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_ALGORITHM_UNIONFINDSET_HPP_
#define ALGEBRA_ALGORITHM_UNIONFINDSET_HPP_

#include <assert.h>
#include <string>
#include <unordered_map>
#include <unordered_set>

#include "algebra/basetype.hpp"
#include "algebra/utility/access.hpp"

namespace algebra {

template<typename item_T>
class UnionFindSet {
    // default: private
    // forward declaration
    class LabelSize;

public:
    typedef item_T item_t;
    typedef size_type label_t;
    typedef T_1D<item_T> item_1D_t;
    typedef std::unordered_map<label_t, item_T> label2item_t;

    UnionFindSet() {
    }
    ~UnionFindSet();
    UnionFindSet(const UnionFindSet &) = delete;
    UnionFindSet &operator=(const UnionFindSet &) = delete;

    inline void Add(const item_T &item) {
        // each item is is treated as a unique item
        label_t new_label = this->item2label_.size();
        this->item2label_[item] = new_label;
        this->label2info_[new_label] = new LabelSize(new_label);
    }
    void GetAllItem(item_1D_t &);
    void GetUnionItem(label2item_t &);
    label_t Find(const item_T &);
    size_type Size();
    void Union(const item_T &, const item_T &);

private:
    inline label_t GetLabel(label_t label) {
        return this->label2info_[label]->GetLabel();
    }
    inline size_type GetSize(label_t label) {
        return this->label2info_[label]->GetSize();
    }
    inline void SetLabel(label_t label, label_t new_label) {
        this->label2info_[label]->SetLabel(new_label);
    }
    inline void SetSize(label_t label, size_type new_size) {
        this->label2info_[label]->SetSize(new_size);
    }

    typedef std::unordered_map<item_T, label_t> item2label_t;
    typedef std::unordered_map<label_t, LabelSize *> label2info_t;
    item2label_t item2label_;
    label2info_t label2info_;

    // Created on: 2020-2-5 21:10
    class LabelSize {
    public:
        LabelSize(label_t label)
                : label_(label), size_(1) {
        }
        LabelSize(const LabelSize &) = delete;
        LabelSize &operator=(const LabelSize &) = delete;
        inline label_t GetLabel() {
            return this->label_;
        }
        inline size_type GetSize() {
            return this->size_;
        }
        inline void SetLabel(label_t label) {
            this->label_ = label;
        }
        inline void SetSize(size_type size) {
            this->size_ = size;
        }

    private:
        size_type label_;
        size_type size_;
    };
};

template<typename item_T>
typename UnionFindSet<item_T>::label_t UnionFindSet<item_T>::Find(
        const item_T &item) {
    assert(this->item2label_.count(item) > 0);
    label_t label = this->item2label_[item];
    while (label != this->label2info_[label]->GetLabel()) {
        label_t temp = this->label2info_[label]->GetLabel();
        label_t next_label = this->label2info_[temp]->GetLabel();
        this->label2info_[label]->SetLabel(next_label);
        label = next_label;
    }
    this->item2label_[item] = label;
    return label;
}

/*
 * https://stackoverflow.com/a/15176127/11193802
 * auto x: work with copies.
 * auto &x: work with original items and may modify them.
 * auto const &x: work with original items and will not modify them
 * auto const / const auto are equivalent
 */
template<typename item_T>
void UnionFindSet<item_T>::GetAllItem(item_1D_t &item_1D) {
    for (const auto &pair : this->item2label_) {
        item_1D.push_back(pair.first);
    }
}

template<typename item_T>
void UnionFindSet<item_T>::GetUnionItem(label2item_t &label2item) {
    for (const auto &pair : this->item2label_) {
        label_t label = this->Find(pair.first);
        if (label2item.count(label) == 0) {
            label2item[label] = pair.first;
        }
    }
}

template<typename item_T>
size_type UnionFindSet<item_T>::Size() {
    std::unordered_set<label_t> label_set;
    for (const auto &pair : this->item2label_) {
        label_set.insert(this->Find(pair.first));
    }
    return label_set.size();
}

template<typename item_T>
void UnionFindSet<item_T>::Union(const item_T &a, const item_T &b) {
    label_t label_a = this->Find(a);
    label_t label_b = this->Find(b);
    if (label_a != label_b) {
        size_type merge_size = this->GetSize(label_a) + this->GetSize(label_b);
        if (this->GetSize(label_a) < this->GetSize(label_b)) {
            this->SetLabel(label_a, label_b);
            this->SetSize(label_b, merge_size);
        } else {
            this->SetLabel(label_b, label_a);
            this->SetSize(label_a, merge_size);
        }
    }
}

template<typename item_T>
UnionFindSet<item_T>::~UnionFindSet() {
    DeleteMapValue(this->label2info_);
}

} // namespace algebra

#endif /* ALGEBRA_ALGORITHM_UNIONFINDSET_HPP_ */
