/*
 * argparser.cpp
 *
 *  Created on: 2020-7-19 10:43
 *      Author: Hongtai Cao
 */

#include <iostream>
#include <string>

#include "algebra/argparser.hpp"
#include "algebra/io/writer.hpp"
#include "algebra/utility/misc.hpp"

namespace algebra {

bool ArgParser::CheckFilePath(const std::string &path) {
    if (not IsFile(path)) {
        this->config_string_["message"] = "File Not Found: " + path;
        return false;
    }
    return true;
}

bool ArgParser::Parse() {
    // argv_[0]: program name
    // argv_[1]: first argument
    if (this->argc_ > 1) {
        if (not this->ParseCommand()) {
            this->config_string_["message"] = "Unknown Command: "
                    + this->Command();
            return false;
        }
    } else {
        this->config_string_["message"] = "Too Few Arguments";
        return false;
    }
    for (int i = 2; i < this->argc_; i += 1) {
        const std::string &op = this->argv_[i];
        // parse bool argument
        if (op == "-ablation-complement") {
            this->config_bool_["ablation_complement"] = true;
            continue;
        } else if (op == "-ablation-order") {
            this->config_bool_["ablation_order"] = true;
            continue;
        } else if (op == "-ablation-share") {
            this->config_bool_["ablation_share"] = true;
            continue;
        } else if (op == "-filter-on") {
            this->config_bool_["leaf_filter"] = true;
            continue;
        } else if (op == "-share-off") {
            this->config_bool_["share"] = false;
            continue;
        }
        // parse key value argument
        i++;
        if (i >= this->argc_) {
            this->config_string_["message"] = "Missing Value for Option: " + op;
            return false;
        }
        if (op == "-c") {
            if (not this->ParseAdjacencyParameter(this->argv_[i])) {
                return false;
            }
        } else if ((op == "-d") or (op == "--data-file")) {
            this->config_string_["data"] = this->argv_[i];
        } else if ((op == "-e") or (op == "--expression")) {
            // b_expression_ set automatically
            this->config_bool_["expression"] = true;
            this->payload.Expression(this->argv_[i]);
        } else if (op == "-format") {
            this->config_int_["leaf_format"] = std::stoi(this->argv_[i]);
        } else if (op == "-leaf") {
            this->config_int_["leaf_algorithm"] = std::stoi(this->argv_[i]);
        } else if (op == "-op") {
            this->config_int_["operator_algorithm"] = std::stoi(this->argv_[i]);
        } else if ((op == "-q") or (op == "--query-file")) {
            this->config_string_["query"] = this->argv_[i];
        } else if ((op == "-t") or (op == "--target")) {
            this->config_int_["target"] = std::stoi(this->argv_[i]);
        } else {
            this->config_string_["message"] =
                    "Unknown Keyword Argument Option: " + op;
            return false;
        }
    }
    // add default adjacency parameter
    if (this->IsAdjacencyMatrix() and this->adjacency_parameter_.empty()) {
        // add default parameter 0,0,0,0
        this->adjacency_parameter_.push_back(std::vector<int>(4, 0));
    }
#ifndef NDEBUG
    if (this->IsAdjacencyMatrix()) {
        std::cout << "adjacency parameter:" << std::endl;
        for (const auto &parameter : this->adjacency_parameter_) {
            PrintAxis(4, parameter);
            std::cout << std::endl;
        }
    }
#endif
    return true;
}

bool ArgParser::ParseAdjacencyParameter(const std::string &value) {
    // : separated tuples, each of size 4
    std::string argument(value);
    while (not argument.empty()) {
        std::size_t semicolon = argument.find(";");
        std::string tuple = argument.substr(0, semicolon);
        std::vector<int> parameter;
        while (not tuple.empty()) {
            std::size_t comma = tuple.find(",");
            parameter.push_back(std::stoi(tuple.substr(0, comma)));
            if (comma != std::string::npos) {
                tuple = tuple.substr(comma + 1);
            } else {
                tuple = "";
            }
        }
        if (parameter.size() == 4) {
            this->adjacency_parameter_.push_back(parameter);
        } else {
            this->config_string_["message"] = "Invalid Parameter for -c: "
                    + value;
            return false;
        }
        if (semicolon != std::string::npos) {
            argument = argument.substr(semicolon + 1);
        } else {
            argument = "";
        }
    }
    return true;
}

bool ArgParser::ParseCommand() {
    /*
     * b: optimize (cost based)
     * aest: execute
     * e: execute given expression
     * ea: create adjacency expression using input expression as subgraph
     * t: execute incrementally
     */
    for (const auto &ch : this->Command()) {
        if (ch == 'a') {
            this->config_bool_["adjacency"] = true;
        } else if (ch == 'b') {
            this->config_bool_["branchbound"] = true;
        } else if (ch == 'e') {
            this->config_bool_["expression"] = true;
        } else if (ch == 's') {
            this->config_bool_["subgraph"] = true;
        } else if (ch == 't') {
            this->config_bool_["transform"] = true;
        } else {
            return false;
        }
    }
    return true;
}

bool ArgParser::Success() {
    // verify data, expression and query argument when required
    std::cout << GetCurrentTime() << " Start: ";
    for (auto i = 0; i < this->argc_; i++) {
        std::cout << this->argv_[i] << " ";
    }
    std::cout << std::endl;
    // data is always required
    bool success = this->Parse() and this->CheckFilePath(this->DataFile());
    if (success) {
        if (this->payload.Expression().empty()) {
            // when expression not given, query is required
            success = this->CheckFilePath(this->Query());
            // check e only case
            if (success and this->IsExpression()
                    and (not (this->IsBranchBound() or this->IsAdjacencyMatrix()
                            or this->IsSubgraphMatching()))) {
                // expression is required
                this->config_bool_["message"] =
                        "Missing Keyword Argument: -e, --expression";
                success = false;
            }
        } else {
            // check a* case
            if (success and this->IsAdjacencyMatrix()
                    and this->IsSubgraphMatching()) {
                // query is still required for IsAdjacencyMatrix
                // when expression is a subgraph matching expression
                success = this->CheckFilePath(this->Query());
            }
        }
    }
    if (not success) {
        this->Usage();
    }
    PrintMap(this->config_bool_);
    PrintMap(this->config_int_);
    PrintMap(this->config_string_);
    return success;
}

ArgParser *ArgParser::Usage() {
    std::cout << _ALGEBRA_VERSION_<< " Usage:\n";
    std::cout << "<program> <1> ...\n";
    std::cout << "  positional argument: <1>\n";
    std::cout << "    a    compute motif adjacency matrix\n";
    std::cout << "    b    compute expression using branch bound\n";
    std::cout << "    e    compute given expression\n";
    std::cout << "    s    compute induced subgraph matching\n";
    std::cout << "    t    compute induced subgraph matching transformation\n";
    std::cout << std::endl;
    std::cout << "  keyword argument:\n";
    std::cout << "    format: adjacency list in ascending order\n";
    std::cout << "    -d, --data-file     path to data graph\n";
    std::cout << "    -q, --query-file    path to query graph\n";
    std::cout << std::endl;
    std::cout << "  keyword argument optional:\n";
    std::cout << "    -ablation-complement" << std::endl;
    std::cout << "                        disable complement implementation\n";
    std::cout << "    -ablation-order     disable order optimization\n";
    std::cout << "    -ablation-share     disable sharing optimization\n";
    std::cout << "                        disable complement implementation\n";
    std::cout << "    -filter-on          enable leaf degree filter\n";
    std::cout << "    -format             leaf format. DEFAULT 0\n";
    std::cout << "                          0=BINARY_BLOCK\n";
    std::cout << "                          1=BINARY_NEIGHBORLIST\n";
    std::cout << "                          2=BINARY_PAIRLIST\n";
    std::cout << "                          3=TEXT_NEIGHBORLIST\n";
    std::cout << "                          4=TEXT_PAIRLIST\n";
    std::cout << "                          5=TEXT_PAIRLIST_ADJACENCY\n";
    std::cout << "    -leaf               leaf algorithm. DEFAULT 0\n";
    std::cout << "                          0=BUILDINGBLOCK\n";
    std::cout << "                          1=ADJACENCY_STORAGE\n";
    std::cout << "                          2=ADJACENCY_BUILDER\n";
    std::cout << "                          3=ADJACENCY_EVALUATE\n";
    std::cout << "    -share-off          ";
    std::cout << "disable sharing intermediate result" << std::endl;
    if (this->IsAdjacencyMatrix()) {
        argparser::UsageAdjacencyMatrix();
    }
    if (this->IsBranchBound()) {
        argparser::UsageBranchBound();
    }
    if (this->IsExpression()) {
        argparser::UsageExpression();
    }
    if ((not this->IsBranchBound())
            and (this->IsAdjacencyMatrix() or this->IsSubgraphMatching())) {
        argparser::UsageKeywordArgumentOptional();
    }
    return this;
}

namespace argparser {

inline void UsageAdjacencyMatrix() {
    /*
     * adjacency matrix is built on top of subgraph matching
     * if there are multiple settings, they are grouped together to save time
     */
    std::cout << "    -c                  ";
    std::cout << "adjacency settings \"<0,1,2,3>\" as tuples\n";
    std::cout << "                        ";
    std::cout << "separated by \";\". DEFAULT 0,0,0,0\n";
    std::cout << "                        ";
    std::cout << "<0>    adjacency algorithm. DEFAULT 0\n";
    std::cout << "                          0=ADJ_EDGE_OBIT\n";
    std::cout << "                          1=ADJ_PERMUTATION\n";
    std::cout << "                        ";
    std::cout << "<1>    adjacency format. DEFAULT 0\n";
    std::cout << "                          0=ADJ_FOREST\n";
    std::cout << "                          1=ADJ_TABLE\n";
    std::cout << "                        ";
    std::cout << "<2>    branch algorithm. DEFAULT 0\n";
    std::cout << "                          0=BR_TRANSPOSE\n";
    std::cout << "                          1=BR_MATCH\n";
    std::cout << "                        ";
    std::cout << "<3>    reduce algorithm. DEFAULT 0\n";
    std::cout << "                          0=REDUCE_SCALE\n";
    std::cout << "                          1=REDUCE_UNIQUE\n";
}

inline void UsageBranchBound() {
    // 43 - 19 = 24 characters
    std::cout << "    -e, --expression    ";
    // 73 - 19 = 54 characters
    std::cout << "expression to estimate cost. If both '-q' and '-e' are\n";
    // 43 - 19 + 67 - 19 = 72
    std::cout << "                        ";
    std::cout << "provided, then estimate expression cost and find\n";
    // 43 - 19 + 41 - 19
    std::cout << "                        ";
    std::cout << "matching vertex order.\n";
}

inline void UsageExpression() {
    std::cout << "    -e, --expression    expression to execute\n";
}

inline void UsageKeywordArgumentOptional() {
    std::cout << std::endl;
    std::cout << "  valid when branchbound (b) not set\n";
    std::cout << "    -op                 operator algorithm. DEFAULT 0\n";
    std::cout << "                          0=OP_MASKMERGE\n";
    std::cout << "                          1=OP_BASIC\n";
    std::cout << "    -t, --target        execute target. DEFAULT 0\n";
    std::cout << "                          < -2: all\n";
    std::cout << "                          = -2: non-LeftMerge-N\n";
    std::cout << "                          = -1: non-Merge-N\n";
    std::cout << "                          >= 0: this target\n";
}

} // namespace argparser

} // namespace algebra
