/*
 * partialgraph.hpp
 *
 *  Created on: 2020-8-21 11:17
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_OPTIMIZER_BRANCHBOUND_PARTIALGRAPH_HPP_
#define ALGEBRA_OPTIMIZER_BRANCHBOUND_PARTIALGRAPH_HPP_

#include <string>
#include <ostream>
#include <vector>

#include "algebra/optimizer/branchbound/type.hpp"
#include "algebra/utility/access.hpp"

namespace branchbound {

// forward declaration
class PartialGraph;

namespace partialgraph {

bool DetachedVertex(const vertex_t, const vertex_t, const edgemap_t &,
        const PartialGraph *);

inline void EraseEdgeFromMap(const vertex_t a, const vertex_t b,
        edgemap_t &map) {
    if (map.count(a) > 0) {
        map[a]->erase(b);
    }
}

void EraseVertexFromMap(const vertex_t, edgemap_t &);

inline void InsertVertex(const vertex_t a, edgemap_t &edgemap) {
    if (edgemap.count(a) == 0) {
        edgemap[a] = new set_t;
    }
}

}

class PartialGraph: public graph_t {
    typedef typename Vertex2D::vector_2D_t edge_1D_t;
public:
    PartialGraph(const std::string &query);
    // construct by removing known edge between vertex pair
    PartialGraph(const PartialGraph *, const vertex_t &, const vertex_t &);
    // construct by inducing on given vertex set
    PartialGraph(const set_t &, const PartialGraph *);
    // construct by adding known edge between vertex pair on given graph
    PartialGraph(const vertex_t &, const vertex_t &, const PartialGraph *,
            const PartialGraph *);
    virtual ~PartialGraph() override {
        algebra::DeleteMapValue(this->unknown_edge_);
    }

    PartialGraph(const PartialGraph &) = delete;
    PartialGraph &operator=(const PartialGraph &) = delete;

    std::string BuildingBlock(const vertex_t, const vertex_t) const;
    inline bool HasUnknown(vertex_t a, vertex_t b) const {
        if (this->unknown_edge_.count(a) == 0) {
            return false;
        }
        return (this->unknown_edge_.at(a)->count(b) > 0);
    }
    inline size_type ID() const {
        return this->id_;
    }
    inline PartialGraph *ID(const size_type id) {
        this->id_ = id;
        return this;
    }
    bool Identical(const PartialGraph *, const Vertex2D *) const;
    inline bool IsCandidate() const {
        return this->IsBuildingBlock() or this->IsConnected();
    }
    inline bool IsBuildingBlock() const {
        return this->SizeV() == 2;
    }
    bool Isomorphic(const PartialGraph *, Vertex2D *) const;
    bool Isomorphic(const PartialGraph *, const vertex_1D_t &) const;
    inline size_type SizeB() const {
        return this->size_b_;
    }
    inline size_type SizeKn() const {
        return this->size_kn_;
    }
    inline size_type SizeU() const {
        return this->size_u_;
    }
    inline size_type SizeUnK() const {
        return this->size_unk_;
    }
    inline size_type SizeV() const {
        return this->VertexSize();
    }
    void SplitUnknown(set_t &, set_t &) const;
    inline vertex_t VertexAt(size_type index) const {
        // hide base class method of the same name though different signature
        // https://stackoverflow.com/a/411116/11193802
        return this->vertex_[index];
    }
    void Write(std::ostream &) const;
    void WriteDetail(std::ostream &) const;

protected:
    PartialGraph();

    inline bool DetachedVertex(const vertex_t a, const vertex_t skip_b) const {
        if (partialgraph::DetachedVertex(a, skip_b, this->forward_edge_,
                this)) {
            if (partialgraph::DetachedVertex(a, skip_b, this->backward_edge_,
                    this)) {
                return true;
            }
        }
        return false;
    }
    inline void EraseEdge(vertex_t a, vertex_t b) {
        // erase edge a->b
        partialgraph::EraseEdgeFromMap(a, b, this->forward_edge_);
        partialgraph::EraseEdgeFromMap(b, a, this->backward_edge_);
    }
    inline void EraseVertex(vertex_t a) {
        // should be called before BuildVertex()
        // should erase from edgemap
        partialgraph::EraseVertexFromMap(a, this->forward_edge_);
        partialgraph::EraseVertexFromMap(a, this->backward_edge_);
        partialgraph::EraseVertexFromMap(a, this->unknown_edge_);
    }
    inline void InsertUnknown(vertex_t a, vertex_t b) {
        if (this->unknown_edge_.count(a) == 0) {
            this->unknown_edge_[a] = new set_t;
        }
        this->unknown_edge_[a]->insert(b);
    }
    inline void InsertVertex(vertex_t a) {
        partialgraph::InsertVertex(a, this->forward_edge_);
        partialgraph::InsertVertex(a, this->backward_edge_);
    }
    bool IsConnected() const;
    void SetBKnUSize(); // should be called after size_unk_ set

    edgemap_t unknown_edge_;
    size_type id_, size_b_, size_kn_, size_u_, size_unk_;
};

// https://stackoverflow.com/a/32739215/11193802
// Inlines must be defined in the same translation unit where they are used
inline std::string PartialGraph::BuildingBlock(const vertex_t a,
        const vertex_t b) const {
    if (this->HasEdge(a, b)) {
        if (this->HasEdge(b, a)) {
            return "B";
        }
        return "U";
    } else if (this->HasEdge(b, a)) {
        return "UT";
    }
    return "N";
}

} // namespace branchbound

#endif /* ALGEBRA_OPTIMIZER_BRANCHBOUND_PARTIALGRAPH_HPP_ */
