/*
 * operand.hpp
 *
 * Operand instance = graph instances + graph vertex order
 *
 *  Created on: 2020-8-19 2:09
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_OPTIMIZER_BRANCHBOUND_OPERAND_HPP_
#define ALGEBRA_OPTIMIZER_BRANCHBOUND_OPERAND_HPP_

#include <assert.h>
#include <ostream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

#include "algebra/algorithm/tritree.hpp"
#include "algebra/optimizer/branchbound/isomorphismentry.hpp"
#include "algebra/optimizer/branchbound/partialgraph.hpp"
#include "algebra/optimizer/branchbound/type.hpp"
#include "algebra/utility/access.hpp"

namespace branchbound {

// take care of attribute order
class Operand {
public:
    Operand(const vertex_1D_t *order, const IsomorphismEntry *entry)
            : match_order_(order), entry_(entry) {
        assert(this->Size() == this->entry_->Graph()->SizeV());
        this->cost_ = this->EstimateCost();
    }

    inline std::string BuildingBlock() const {
        return this->Graph()->BuildingBlock(algebra::Get(this->match_order_, 0),
                algebra::Get(this->match_order_, 1));
    }
    inline size_type BaseID() const {
        return this->entry_->BaseID();
    }
    inline double Cost() const {
        return this->cost_;
    }
    inline double Cost(const Operand *source) const {
        /*
         * this is attribute renaming
         * no matter full order or not, it should always check against iso
         */
        return this->CostIsomorphic(source);
    }
    inline bool IsBuildingBlock() const {
        return this->entry_->Graph()->IsBuildingBlock();
    }
    inline const PartialGraph *Graph() const {
        return this->entry_->Graph();
    }
    inline bool Isomorphic(const Operand *other) const {
        return this->BaseID() == other->BaseID();
    }

    static double JoinCost(const Operand *, const Operand *, const Operand *);
    struct Smaller {
        // sort by SizeKn and isomorphism
        inline bool operator()(const Operand *a, const Operand *b) const {
            if (a->Graph()->SizeKn() == b->Graph()->SizeKn()) {
                // operand with larger base_id is larger -> top of queue
                return a->BaseID() < b->BaseID();
            }
            // operand with more known edge pair is larger -> top of queue
            return a->Graph()->SizeKn() < b->Graph()->SizeKn();
        }
    };

    const vertex_1D_t &MatchOrder() const {
        return *this->match_order_;
    }
    inline size_type Size() const {
        // number of attribute
        return this->match_order_->size();
    }

    template<typename container_T>
    static void Transpose(container_T &, const Operand *, const Operand *);
    // find the Transpose axis between two Operand

    std::string ToString() const {
        // https://stackoverflow.com/a/17797823/11193802
        std::stringstream ss;
        this->Write(ss);
        return ss.str();
    }

    inline static bool SupportedOrder(const Operand *result,
            const Operand *left, const Operand *right) {
        if (FULL_ORDER) {
            return Operand::PrefixOrderFullOrder(*result->match_order_,
                    left->match_order_, right->match_order_);
        } else {
            return Operand::PrefixOrderIsomorphic(*result, *left, *right);
        }
    }

    void Write(std::ostream &) const;

    // these only declare static variables. need define them in source file
    // https://stackoverflow.com/a/14331502/11193802
    static double B;
    static double N;
    static double U;
    static double UT;
    static double V;

private:
    inline vertex_t AttributeAt(const size_type index) const {
        return this->match_order_->at(index);
    }
    inline double AttributeSize(const vertex_t attribute) const {
        return this->table_.at(attribute);
    }
    double CostIsomorphic(const Operand *) const;
    double EstimateCost();
    size_type FindAttribute(const vertex_t) const;
    static double JoinCostFullOrder(const vertex_1D_t &, const Operand &,
            const Operand &);
    static double JoinCostIsomorphic(const Operand &, const Operand &);
    static bool PrefixOrderFullOrder(const vertex_1D_t &, const vertex_1D_t *,
            const vertex_1D_t *);
    static bool PrefixOrderIsomorphic(const Operand &, const Operand &,
            const Operand &);
    double ScanCost(double &, size_type) const;
    inline double TransposeCost() const {
        double size = 1;
        return this->ScanCost(size, 0);
    }

    // the cost of current operand
    double cost_;
    std::unordered_map<vertex_t, double> table_;
    // does not own any of below
    const vertex_1D_t *match_order_;
    const IsomorphismEntry *entry_;
};

typedef std::vector<Operand *> operand_1D_t;

void SetDataParameter(const std::string &);

template<typename container_T>
void Operand::Transpose(container_T &axis_order, const Operand *source,
        const Operand *target) {
    // find the Transpose axis between two Operand
    if (target->Cost(source) == 0) {
        return;
    }
    std::vector<size_type> source_order, target_order;
    source->entry_->ISO()->BaseOrder(source_order, *source->match_order_, 0);
    target->entry_->ISO()->BaseOrder(target_order, *target->match_order_, 0);
    std::unordered_map<size_type, size_type> base2index;
    for (size_type i = 0; i < source_order.size(); i++) {
        base2index[source_order[i]] = i;
    }
    for (auto &item : target_order) {
        axis_order.push_back(base2index[item]);
    }
}

namespace operand {

inline double ExpectMatchSize(double a, double b) {
    return a / Operand::V * b;
}

double ExpectMatchSize2(double, double); // low efficiency and not used

template<typename constainer_T>
bool IsPrefix(const constainer_T &, const vertex_1D_t &);

template<typename container_T>
bool IsSameOrder(const container_T &, const vertex_1D_t &);

double Multiplicity(const vertex_t, const vertex_t, const PartialGraph *);

template<typename constainer_T>
bool ParallelJoinOrder(constainer_T &, const vertex_1D_t &,
        const vertex_1D_t &);

template<typename storage_T>
inline void SetParameter(double &target, storage_T &storage) {
    if (storage.LoopSize() > 0) {
        target = 1.0 * storage.RowSize() / storage.LoopSize();
    } else {
        target = 0;
    }
}

void WriteParameter(std::ostream &, const double, const double, const double,
        const double, const size_type);

// implementation
template<typename constainer_T>
bool IsPrefix(const constainer_T &join_order, const vertex_1D_t &order) {
    for (size_type i = 0; i < join_order.size(); i++) {
        if (join_order[i] != order[i]) {
            return false;
        }
    }
    return true;
}

template<typename container_T>
bool IsSameOrder(const container_T &join_order, const vertex_1D_t &other) {
    size_type i = 0;
    for (size_type j = 0; j < other.size(); j++) {
        if (join_order.size() == i) {
            return true;
        }
        if (join_order[i] == other[j]) {
            i++;
        }
    }
    return i == join_order.size();
}

template<typename constainer_T>
bool ParallelJoinOrder(constainer_T &join_order,
        const vertex_1D_t &standard_order, const vertex_1D_t &other) {
    // return an order same as standard order
    set_t attribute;
    for (auto &item : other) {
        attribute.insert(item);
    }
    for (auto &item : standard_order) {
        if (attribute.count(item) > 0) {
            // join attribute
            join_order.push_back(item);
        }
    }
    // check if other has the same join order
    return operand::IsSameOrder(join_order, other);
}

} // namespace operand

} // namespace branchbound

#endif /* ALGEBRA_OPTIMIZER_BRANCHBOUND_OPERAND_HPP_ */
