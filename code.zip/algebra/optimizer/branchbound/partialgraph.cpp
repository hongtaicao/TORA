/*
 * partialgraph.cpp
 *
 *  Created on: 2020-8-21 13:46
 *      Author: Hongtai Cao
 */

#include <algorithm>
#include <assert.h>
#include <ostream>
#include <string>
#include <unordered_set>

#include "algebra/algorithm/unionfindset.hpp"
#include "algebra/basetype.hpp"
#include "algebra/optimizer/branchbound/isomorphismtable.hpp"
#include "algebra/optimizer/branchbound/partialgraph.hpp"
#include "algebra/optimizer/branchbound/type.hpp"
#include "algebra/utility/access.hpp"
#include "algebra/utility/tostring.hpp"

namespace branchbound {

bool PartialGraph::Identical(const PartialGraph *other,
        const Vertex2D *iso) const {
    // whether two input isomorphic graphs are identical or not
    for (auto &mapping : iso->Data()) {
        bool identical = true;
        for (size_type i = 0; i < mapping->size(); i++) {
            if (algebra::Get(mapping, i) != other->vertex_[i]) {
                identical = false;
                break;
            }
        }
        if (identical) {
            // find an identical mapping
            return true;
        }
    }
    return false;
}

void PartialGraph::SetBKnUSize() {
    for (const auto &pair : this->forward_edge_) {
        for (const auto &neighbor : (*pair.second)) {
            if (this->HasEdge(neighbor, pair.first)) {
                this->size_b_++;
            } else {
                this->size_u_++;
            }
        }
    }
    this->size_b_ /= 2;
    this->size_kn_ = this->SizeV() * (this->SizeV() - 1) / 2 - this->SizeUnK();
}

bool PartialGraph::IsConnected() const {
    // if there is a single set, then the graph is connected by these edges
    algebra::UnionFindSet<vertex_t> component;
    // initialize
    for (const auto &v : this->vertex_) {
        component.Add(v);
    }
    for (const auto &pair : this->forward_edge_) {
        for (const auto &neighbor : (*pair.second)) {
            component.Union(pair.first, neighbor);
        }
    }
    return (component.Size() == 1);
}

bool PartialGraph::Isomorphic(const PartialGraph *base,
        Vertex2D *iso_1D) const {
    // given a base vertex order, get all different isomorphism
    vertex_1D_t candidate(this->Vertex());
    std::sort(candidate.begin(), candidate.end());
    do {
        if (base->Isomorphic(this, candidate)) {
            iso_1D->PushBack(new vertex_1D_t(candidate));
        }
    } while (std::next_permutation(candidate.begin(), candidate.end()));
    return iso_1D->Size() > 0;
}

bool PartialGraph::Isomorphic(const PartialGraph *other,
        const vertex_1D_t &o_1D) const {
    // check if this->vertex_ maps to o_1D
    for (size_type i = 0; i < this->VertexSize(); i++) {
        vertex_t ai = this->vertex_[i], bi = o_1D[i];
        for (size_type j = i + 1; j < this->VertexSize(); j++) {
            vertex_t aj = this->vertex_[j], bj = o_1D[j];
            if (this->HasEdge(ai, aj) != other->HasEdge(bi, bj)) {
                return false;
            }
            if (this->HasEdge(aj, ai) != other->HasEdge(bj, bi)) {
                return false;
            }
            if (this->HasUnknown(ai, aj) != other->HasUnknown(bi, bj)) {
                return false;
            }
        }
    }
    return true;
}

void PartialGraph::SplitUnknown(set_t &a, set_t &b) const {
    for (const auto &pair : this->unknown_edge_) {
        a.insert(pair.first);
        for (const auto &inner : (*pair.second)) {
            b.insert(inner);
        }
        return;
    }
}

void PartialGraph::Write(std::ostream &out) const {
    // graph_vertex[\unknown_pair]
    std::unordered_set<std::string> pair_1D;
    for (auto &pair : this->unknown_edge_) {
        for (auto &neighbor : (*pair.second)) {
            if (pair.first < neighbor) {
                pair_1D.insert(
                        std::to_string(pair.first) + "?"
                                + std::to_string(neighbor));
            }
        }
    }
    out << algebra::OrderedToString(this->Vertex());
    if (pair_1D.size() > 0) {
        out << "\\" << algebra::SetStringJoin(pair_1D);
    }
}

void PartialGraph::WriteDetail(std::ostream &out) const {
    // detail representation
    out << "====== PartialGraph.WriteDetail(): begin ======" << std::endl;
    graph_t::Write(out);
    out << "unknown_pair" << std::endl;
    algebra::graph::WriteEdgeMap<vertex_t>(out, this->unknown_edge_, "??");
    out << "SizeB=" << this->SizeB() << " SizeU=" << this->SizeU()
            << " unknown_pair=" << this->SizeUnK() << " SizeV=" << this->SizeV()
            << std::endl;
    out << "====== PartialGraph.WriteDetail(): end ======" << std::endl;
}

// construct from file
PartialGraph::PartialGraph(const std::string &query)
        : graph_t(query), id_(0), size_b_(0), size_kn_(0), size_u_(0) {
    this->size_unk_ = 0;
    this->SetBKnUSize();
#ifndef NDEBUG
    this->WriteDetail(std::cout);
#endif
}

// construct by adding more unknown pair
PartialGraph::PartialGraph(const PartialGraph *graph, const vertex_t &a,
        const vertex_t &b)
        : graph_t(graph), id_(0), size_b_(0), size_kn_(0), size_u_(0) {
    // a, b should be graph vertex
    algebra::graph::CopyEdgeMap<vertex_t>(graph->unknown_edge_,
            this->unknown_edge_);
    // update graph vertex and edge
    this->EraseEdge(a, b);
    this->EraseEdge(b, a);
    if (this->DetachedVertex(a, b)) {
        this->EraseVertex(a);
    }
    if (this->DetachedVertex(b, a)) {
        this->EraseVertex(b);
    }
    // build vertex_
    this->SetVertexAndEdgeSize();
    if (this->VertexSize() == graph->VertexSize()) {
        // insert additional unknown if both a, b are present
        this->InsertUnknown(a, b);
        this->InsertUnknown(b, a);
        this->size_unk_ = graph->SizeUnK() + 1;
    } else {
        // update size_unk_ only
        this->size_unk_ = algebra::graph::CountEdge<vertex_t>(
                this->unknown_edge_) / 2;
    }
    this->SetBKnUSize();
#ifndef NDEBUG
    this->WriteDetail(std::cout);
#endif
}

// vertex induced using graph
PartialGraph::PartialGraph(const set_t &v_set, const PartialGraph *graph)
        : graph_t(*((graph_t *) graph), v_set), id_(0), size_b_(0) {
    this->size_kn_ = 0;
    this->size_u_ = 0;
    // add vertex
    for (auto &item : v_set) {
        this->InsertVertex(item);
    }
    // rebuild vertex
    this->vertex_.clear();
    this->SetVertexAndEdgeSize();
    this->size_unk_ = 0;
    this->SetBKnUSize();
#ifndef NDEBUG
    this->WriteDetail(std::cout);
#endif
}

// extend small by adding known pair (a, b) using original graph
PartialGraph::PartialGraph(const vertex_t &a, const vertex_t &b,
        const PartialGraph *small, const PartialGraph *original)
        : graph_t(small), id_(0), size_b_(0), size_kn_(0), size_u_(0) {
    // update graph vertex and edge
    // add known edge
    if (original->HasEdge(a, b)) {
        this->InsertEdge(a, b);
    }
    if (original->HasEdge(b, a)) {
        this->InsertEdge(b, a);
    }
    // add vertex
    this->InsertVertex(a);
    this->InsertVertex(b);
    // build vertex_
    this->SetVertexAndEdgeSize();
    // copy unknown
    algebra::graph::CopyEdgeMap<vertex_t>(small->unknown_edge_,
            this->unknown_edge_);
    // remove unknown
    if (this->HasUnknown(a, b)) {
        this->unknown_edge_[a]->erase(b);
        this->unknown_edge_[b]->erase(a);
    }
    // update unknown pair: size_k_
    if (this->SizeV() == small->SizeV()) {
        // does not introduce new vertex
        assert(small->SizeUnK() >= 1);
        this->size_unk_ = small->SizeUnK() - 1;
    } else if (this->SizeV() == small->SizeV() + 1) {
        // add one known pair introduce a new vertex
        assert(small->SizeUnK() + small->SizeV() >= 1);
        this->size_unk_ = small->SizeUnK() + small->SizeV() - 1;
    } else {
        // add one known pair introduce two new vertices
        this->size_unk_ = small->SizeUnK() + 2 * small->SizeV();
    }
    this->SetBKnUSize();
#ifndef NDEBUG
    this->WriteDetail(std::cout);
#endif
}

// used by sub-class
PartialGraph::PartialGraph()
        : graph_t(nullptr), id_(0), size_b_(0), size_kn_(0), size_u_(0) {
    this->size_unk_ = 0;
}

namespace partialgraph {

bool DetachedVertex(const vertex_t a, const vertex_t skip_b,
        const edgemap_t &edge_map, const PartialGraph *graph) {
    bool all_detached = true;
    for (auto &pair : edge_map) {
        if ((pair.first == a) or (pair.first == skip_b)) {
            continue;
        }
        if (not graph->HasUnknown(a, pair.first)) {
            all_detached = false;
            break;
        }
    }
    return all_detached;
}

void EraseVertexFromMap(const vertex_t a, edgemap_t &map) {
    if (map.count(a) > 0) {
        delete map[a];
        map.erase(a);
    }
    for (auto &pair : map) {
        pair.second->erase(a);
    }
}

} // namespace partialgraph

} // namespace branchbound
