/*
 * branchbound.cpp
 *
 *  Created on: 2020-10-13 12:55
 *      Author: Hongtai Cao
 */

#include <iostream>
#include <string>

#include "algebra/argparser.hpp"
#include "algebra/io/logger.hpp"
#include "algebra/optimizer/branchbound/branchbound.hpp"
#include "algebra/optimizer/branchbound/decomposegraph.hpp"
#include "algebra/optimizer/branchbound/estimator/expressionparser.hpp"
#include "algebra/optimizer/branchbound/operand.hpp"
#include "algebra/optimizer/branchbound/type.hpp"
#include "algebra/utility/misc.hpp"
#include "algebra/utility/tostring.hpp"

namespace branchbound {

double main(algebra::ArgParser &argparser) {
    // setup
    const algebra::timepoint_t &data_start = algebra::GetTimepoint();
    // read time in not timed here
    SetDataParameter(argparser.DataFile());
    double data_cost = algebra::GetTimeCost(data_start);
    if (argparser.payload.Expression().empty()) {
        // run optimizer and set expression
        return OptimizeExpression(argparser, data_cost);
    } else if (not (argparser.IsAdjacencyMatrix()
            and (not argparser.IsSubgraphMatching()))) {
        // the given expression is not AdjacencyMatrix
        return EstimateExpression(argparser);
    }
    return 0;
}

double EstimateExpression(algebra::ArgParser &argparser) {
    algebra::Logger logger("EstimateExpression");
    logger.Start();
    logger.AddResult("time", algebra::GetCurrentTime());
    const algebra::timepoint_t &start = algebra::GetTimepoint();
    ExpressionParser dec(argparser.payload.Expression());
    Expression *expression = dec.BuildExpression();
    double estimate_time = algebra::GetTimeCost(start);
    double cost = expression->Cost();
    Vertex2D order1D;
    PartialGraph graph(argparser.Query());
    size_type iso_count = dec.MatchOrder(order1D, graph);
    std::cout << argparser.Query() << std::endl;
    std::cout << argparser.payload.Expression() << std::endl;
    std::cout << algebra::GetCurrentTime() << " EstimateExpression."
            << " expression cost " << cost << " estimate time " << estimate_time
            << " (s)" << std::endl;
    std::string match_order = "";
    for (size_type index = 0; index < order1D.Size(); index++) {
        std::string match = "[" + algebra::OrderedToString(*order1D[index])
                + "]";
        match_order = match_order + match + ", ";
        std::cout << "index " << index << "/" << iso_count << " match_order "
                << match << std::endl;
    }
    if (!match_order.empty()) {
        // erase trailing ", "
        match_order.erase(match_order.size() - 2);
    }
    logger.AddResult("data", argparser.DataFile());
    logger.AddResult("expression", argparser.payload.Expression());
    logger.AddResult("query", argparser.Query());
    logger.AddResult("expression_cost", std::to_string(cost));
    logger.AddResult("estimate_time(s)", std::to_string(estimate_time));
    logger.AddResult("match_order", "[" + match_order + "]");
    logger.WriteFile();
    return 0;
}

double OptimizeExpression(algebra::ArgParser &argparser, double data_cost) {
    algebra::Logger logger("branchbound");
    logger.Start();
    logger.AddResult("data", argparser.DataFile());
    logger.AddResult("query", argparser.Query());
    logger.AddResult("time", algebra::GetCurrentTime());
    logger.AddResult("SetDataParameter(0)", std::to_string(data_cost));
    std::cout << algebra::GetCurrentTime() << " SetDataParameter. " << data_cost
            << " (s)" << std::endl;
    // start
    DecomposeGraph dec(argparser);
    dec.Initialize();

    logger.AddResult("query_time(s)",
            std::to_string(dec.Profile().query_time_));
    logger.AddResult("initialize_time(s)",
            std::to_string(dec.Profile().initialize_time_));
    logger.AddResult("initial_pool_size",
            std::to_string(dec.Profile().initial_pool_size_));
    std::cout << algebra::GetCurrentTime() << " Initialize. query "
            << dec.Profile().query_time_ << " (s) pool time "
            << dec.Profile().initialize_time_ << " (s) pool size "
            << dec.Profile().initial_pool_size_ << std::endl;
    // build
    dec.BuildExpression();

    logger.AddResult("decompose_time(s)",
            std::to_string(dec.Profile().decompose_time_));
    logger.AddResult("decompose_build_time(s)",
            std::to_string(dec.Profile().decompose_build_time_));
    logger.AddResult("remain_pool_size",
            std::to_string(dec.Profile().remain_pool_size_));
    logger.AddResult("fail_branch", std::to_string(dec.Profile().fail_branch_));
    logger.AddResult("total_branch",
            std::to_string(dec.Profile().total_branch_));
    logger.AddResult("best_cost", std::to_string(dec.Profile().best_cost_));
    logger.AddResult("margin_cost", std::to_string(dec.Profile().margin_));
    std::cout << algebra::GetCurrentTime() << " OptimizeExpression. decompose "
            << dec.Profile().decompose_time_ << " (s) decompose+build "
            << dec.Profile().decompose_build_time_ << " (s) remain_pool_size "
            << dec.Profile().remain_pool_size_ << " fail_branch "
            << dec.Profile().fail_branch_ << " total_branch "
            << dec.Profile().total_branch_ << " best_cout "
            << dec.Profile().best_count_ << " best_cost "
            << dec.Profile().best_cost_ << " margin_cost "
            << dec.Profile().margin_ << std::endl;
    // result
    size_type counter = 0;
    for (auto &complete : dec.Completed()) {
        complete->Write(std::cout);
        std::string expression;
        complete->ToSingleLine(expression);
        std::cout << counter << ": " << expression << std::endl;
        std::cout << "# order: ["
                << algebra::OrderedToString(complete->MatchOrder()) << "]"
                << std::endl;
        argparser.payload.Expression(expression);
        argparser.payload.MatchOrder(complete->MatchOrder());
        // ~ optional columns of the output table start with ~
        logger.AddResult("~expression_" + std::to_string(counter), expression);
        counter++;
    }
    logger.WriteFile();
    // return total time cost
    // data graph read time excluded
    // query graph read time
    // optimization time (decompose+build)
    double optimization_cost = dec.Profile().query_time_
            + dec.Profile().decompose_build_time_;
    argparser.payload.Cost("branchbound", optimization_cost);
    return optimization_cost;
}

}
