/*
 * decompositiontable.cpp
 *
 *  Created on: 2020-8-19 3:58
 *      Author: Hongtai Cao
 */

#include <algorithm>
#include <assert.h>
#include <iostream>

#include "algebra/basetype.hpp"
#include "algebra/io/writer.hpp"
#include "algebra/optimizer/branchbound/decompositiontable.hpp"
#include "algebra/optimizer/branchbound/type.hpp"
#include "algebra/utility/access.hpp"

namespace branchbound {

void DecompositionTable::CheckCandidate(decomposition_t &decompose,
        PartialGraph *left_graph, PartialGraph *right_graph, tritree_t &tritree,
        size_type depth) {
    // check if given left_graph and right_graph can be valid decomposition
    if (right_graph->IsCandidate()) {
        // a valid decomposition
#ifndef NDEBUG
        std::cout << "DecompositionTable::CheckCandidate()" << std::endl;
        std::cout << "    left=";
        left_graph->Write(std::cout);
        std::cout << " right=";
        right_graph->Write(std::cout);
        std::cout << std::endl;
#endif
        auto left = this->InsertFindEntryDelete(left_graph);
        auto right = this->InsertFindEntryDelete(right_graph);
        // graph is nullptr after this call
        // find identical decomposition using base_id
        typename tritree_t::sequence_t seq;
        seq.push_back(left->BaseID());
        seq.push_back(right->BaseID());
        if (tritree.Index(seq) == 1) {
            // a unique decomposition at this level
            if ((depth == 0) or this->IsCandidatePair(depth - 1, left, right)) {
                // recursion into next decomposition
                // record using graph_id, but not base id
                decompose.PartialPushBack(left->ID());
                decompose.PartialPushBack(right->ID());
                decompose.CopyClearPartial();
                PRINT("DecompositionTable::CheckCandidate(): left id=");
                PRINT(left->ID() << " base=" << left->BaseID() << " size=");
                PRINT(left->Graph()->SizeV() << " right id=" << right->ID());
                PRINT(" base=" << right->BaseID() << " size=");
                PRINTLINE(right->Graph()->SizeV());
            }
        }
        // index identical decomposition
        std::reverse(seq.begin(), seq.end());
        tritree.Index(seq);
    } else {
        // left, right are not in iso_table: no owner
        delete left_graph;
        delete right_graph;
    }
}

const typename DecompositionTable::decomposition_t *DecompositionTable::DecomposeDFS(
        size_type graph_id, size_type depth) {
    // decompose the given graph
    /*
     * each decomposition is paired with a vertex order to form operands
     * it is then tried multiple times to find next level decomposition
     * 1. decompose one more level can prune invalid decomposition partially
     * 2. decompose all the way to the end can prune completely invalid ones
     * however, this has larger decomposition space
     * 3. decompose given graph and additional given depth
     */
    assert(graph_id > 0);
    if (this->table_.count(graph_id) == 0) {
        // build decomposition for the given PartialGraph_id
        decomposition_t *decompose = new decomposition_t;
        // choose one of the following decomposition method
        if (this->algorithm_ == DEC_BALANCE) {
            this->DecomposeByBalance(*decompose,
                    this->iso_table_.FindEntry(graph_id)->Graph(), depth);
        } else if (this->algorithm_ == DEC_MOVE) {
            this->DecomposeByMove(*decompose,
                    this->iso_table_.FindEntry(graph_id)->Graph(), depth);
        } else {
            std::cout << "DecompositionTable::DecomposeDFS() unknown algorithm"
                    << std::endl;
            throw;
        }
        this->table_[graph_id] = decompose;
        PRINTLINE("DecompositionTable::DecomposeDFS() build");
    }
#ifndef NDEBUG
    else {
        std::cout << "DecompositionTable::DecomposeDFS() cache" << std::endl;
    }
    std::cout << "    result size=" << this->table_[graph_id]->Size() << " id="
            << graph_id << " graph=";
    this->iso_table_.FindEntry(graph_id)->Graph()->Write(std::cout);
    std::cout << std::endl;
#endif
    return this->table_[graph_id];
}

void DecompositionTable::DecomposeByBalance(decomposition_t &decomp2D,
        const PartialGraph * const graph, size_type depth) {
    if (graph->SizeUnK() == 0) {
        // decompose into (operand, building block)
        const vertex_1D_t &vertex = graph->Vertex();
        set_t buildingblock_set;
        for (size_type i = 0; i < vertex.size(); i++) {
            buildingblock_set.insert(vertex[i]);
            for (size_type j = i + 1; j < vertex.size(); j++) {
                buildingblock_set.insert(vertex[j]);
                PartialGraph *left_graph = new PartialGraph(graph, vertex[i],
                        vertex[j]);
                if (left_graph->IsCandidate()) {
                    tritree_t tritree;
                    PartialGraph *right_graph = new PartialGraph(
                            buildingblock_set, graph);
                    this->CheckCandidate(decomp2D, left_graph, right_graph,
                            tritree, depth);
                }
                buildingblock_set.erase(vertex[j]);
            }
            buildingblock_set.erase(vertex[i]);
        }
    } else {
        // decompose into operands of balanced size induced subgraph
        assert(graph->SizeUnK() == 1);
        set_t left_set, right_set;
        graph->SplitUnknown(left_set, right_set);
        for (auto &item : graph->Vertex()) {
            if ((left_set.count(item) == 0) and (right_set.count(item) == 0)) {
                // shared vertex
                left_set.insert(item);
                right_set.insert(item);
            }
        }
        PartialGraph *left_graph = new PartialGraph(left_set, graph);
        if (left_graph->IsCandidate()) {
            tritree_t tritree;
            PartialGraph *right_graph = new PartialGraph(right_set, graph);
            this->CheckCandidate(decomp2D, left_graph, right_graph, tritree,
                    depth);
        }
    }
}

void DecompositionTable::DecomposeRecursion(decomposition_t &decompose,
        size_type start, const PartialGraph * const graph, size_type depth) {
    // graph_id: decomposition of current graph
    // base_id: identify equivalent decompositions
    tritree_t tritree;
    while (start < decompose.Size()) {
        size_type stop = decompose.Size();
        for (size_type d_ptr = start; d_ptr < stop; d_ptr++) {
            size_type p_left_id = decompose[d_ptr]->at(0);
            size_type p_right_id = decompose[d_ptr]->at(1);
            const PartialGraph *p_left_graph = this->iso_table_.FindEntry(
                    p_left_id)->Graph();
            for (size_type i = 0; i < p_left_graph->SizeV(); i++) {
                for (size_type j = i + 1; j < p_left_graph->SizeV(); j++) {
                    vertex_t a = p_left_graph->VertexAt(i), b =
                            p_left_graph->VertexAt(j);
                    if (p_left_graph->HasUnknown(a, b)) {
                        continue;
                    }
                    PartialGraph *left_graph = new PartialGraph(p_left_graph, a,
                            b);
                    if (left_graph->IsCandidate()) {
                        PartialGraph *right_graph = new PartialGraph(a, b,
                                this->iso_table_.FindEntry(p_right_id)->Graph(),
                                graph);
                        if ((left_graph->SizeV() == right_graph->SizeV())
                                and (left_graph->SizeUnK()
                                        < right_graph->SizeUnK())) {
                            // left is smaller than the right
                            // the end of decomposition
                            delete left_graph;
                            delete right_graph;
                            return;
                        }
                        this->CheckCandidate(decompose, left_graph, right_graph,
                                tritree, depth);
                    } else {
                        // left is not in iso_table: no owner
                        delete left_graph;
                    }
                }
            }
        }
        start = stop;
    }
}

void DecompositionTable::DecomposeStart(decomposition_t &decompose,
        const PartialGraph * const graph, size_type depth) {
    // graph_id: decomposition of current graph
    // base_id: identify equivalent decompositions
    tritree_t tritree;
    for (size_type i = 0; i < graph->SizeV(); i++) {
        for (size_type j = i + 1; j < graph->SizeV(); j++) {
            vertex_t a = graph->VertexAt(i), b = graph->VertexAt(j);
            if (graph->HasUnknown(a, b)) {
                continue;
            }
            PartialGraph *left_graph = new PartialGraph(graph, a, b);
            if (left_graph->IsCandidate()) {
                set_t v_set;
                v_set.insert(a);
                v_set.insert(b);
                PartialGraph *right_graph = new PartialGraph(v_set, graph);
                assert(right_graph->SizeV() == 2);
                this->CheckCandidate(decompose, left_graph, right_graph,
                        tritree, depth);
            } else {
                // left is not in iso_table: no owner
                delete left_graph;
            }
        }
    }
}

const IsomorphismEntry *DecompositionTable::InsertFindEntryDelete(
        PartialGraph *&graph) {
    // input graph can be a nullptr after this call
    bool inserted = this->iso_table_.InsertSetID(graph);
    const IsomorphismEntry *entry = this->iso_table_.FindEntry(graph);
    if (not inserted) {
        // graph is not inserted. no ownership
        // safe to delete because it is constructed outside iso_table
        delete graph;
    }
    graph = nullptr;
    return entry;
}

} // namespace branchbound
