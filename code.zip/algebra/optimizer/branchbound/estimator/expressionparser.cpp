/*
 * expressionparser.cpp
 *
 *  Created on: 2020-10-13 0:44
 *      Author: Hongtai Cao
 */

#include <iostream>
#include <stdlib.h>
#include <string>
#include <unordered_set>

#include "algebra/basetype.hpp"
#include "algebra/io/writer.hpp"
#include "algebra/optimizer/branchbound/decomposegraph.hpp"
#include "algebra/optimizer/branchbound/estimator/expressionparser.hpp"
#include "algebra/optimizer/branchbound/estimator/graphnode.hpp"
#include "algebra/optimizer/branchbound/expression.hpp"
#include "algebra/optimizer/branchbound/isomorphismtable.hpp"
#include "algebra/optimizer/branchbound/operand.hpp"
#include "algebra/optimizer/branchbound/partialgraph.hpp"
#include "algebra/optimizer/branchbound/type.hpp"
#include "algebra/utility/access.hpp"
#include "algebra/utility/misc.hpp"
#include "algebra/utility/parse.hpp"

namespace branchbound {

ExpressionParser::ExpressionParser(const std::string &expr)
        : iso_table_(SingleIsoTable::Instance()) {
    this->expression_ = nullptr;
    convert_t convert;
    node_T parsed = this->Parse(expr);
    for (auto vertex : (*parsed->Order())) {
        convert[vertex] = vertex;
    }
    node_1D_t node_1D;
    this->root_ = new GraphNode(parsed, convert, node_1D);
    // clear table to replace base graph
    // Operand always get base graph
    this->iso_table_.Clear();
    for (auto &node : node_1D) {
        this->SetID(node);
    }
    expressionparser::DebugGraphNode(this->root_);
}

ExpressionParser::~ExpressionParser() {
    algebra::DeleteContent(this->iso_graph_);
    if (this->expression_ != nullptr) {
        std::unordered_set<Expression *> expression_set; // hold all Expression
        std::unordered_set<Operand *> operand_set; // hold all Operand
        this->expression_->CollectResource(expression_set, operand_set);
        algebra::DeleteContent(expression_set);
        algebra::DeleteContent(operand_set);
    }
}

Expression *ExpressionParser::BuildExpression() {
    // build expression for root
    Operand *operand = this->BuildOperand(this->root_);
    Expression *expression = new Expression(operand);
    while (not expression->IsComplete()) {
        operand_1D_t operand_1D, remaining;
        expression->PopTopIsomorphic(operand_1D);
        expression->PopAll(remaining);
        Operand *output_op = operand_1D[0];
        if (operand_1D.size() > 1) {
            // build shared
            expression = this->BuildShared(expression, operand_1D);
        } else {
            expression = this->BuildSingle(expression, output_op);
        }
        expression->PushAll(remaining);
    }
    this->expression_ = expression; // record final expression for cleaning
    return expression;
}

inline Operand *ExpressionParser::BuildOperand(const GraphNode *node) {
    return new Operand(node->Order(), this->iso_table_.FindEntry(node));
}

Expression *ExpressionParser::BuildShared(Expression *expression,
        const operand_1D_t &operand_1D) {
    decomposegraph::ufs_group_t group;
    expression = decomposegraph::BuildShared(expression, operand_1D, group);
    // head operand (group.value) is not chained yet
    // handle compute or transpose head
    if (group.size() == 1) {
        // transpose not used. transpose cost is 0
        PRINTLINE("ExpressionParser::BuildExpressionShared(): group size = 1");
        return this->BuildSingle(expression, group.begin()->second);
    }
    // find how each head is computed
    operand_1D_t compute_op_1D, transpose_op_1D;
    for (auto &pair : group) {
        const GraphNode *g = (GraphNode *) pair.second->Graph();
        if (g->SubgraphCount() == 1) {
            // additional transpose
            transpose_op_1D.push_back(pair.second);
        } else {
            compute_op_1D.push_back(pair.second);
        }
    }
    if (compute_op_1D.size() == group.size()) {
        // no transpose, build expression for all operand
        for (auto &op : compute_op_1D) {
            expression = this->BuildSingle(expression, op);
        }
        PRINT("ExpressionParser::BuildExpressionShared(): compute_op and");
        PRINTLINE(" group size match = " << group.size());
        return expression;
    }
    // process transpose_op only, compute_op -> pending
    for (auto &op : transpose_op_1D) {
        expression = this->BuildSingle(expression, op);
    }
    expression->PushAll(compute_op_1D);
    PRINT("ExpressionParser::BuildExpressionShared(): compute_op=");
    PRINT(compute_op_1D.size() << " transpose_op=");
    PRINTLINE(transpose_op_1D.size());
    return expression;
}

Expression *ExpressionParser::BuildSingle(Expression *expression,
        Operand *output_op) {
    // build expression for output_op
    const GraphNode *graph = (GraphNode *) (output_op->Graph());
    if (graph->SubgraphCount() == 1) {
        Operand *input_op = this->BuildOperand(graph->Subgraph(0));
        expression = new Expression(expression, output_op, input_op);
    } else if (graph->SubgraphCount() == 2) {
        Operand *left_op = this->BuildOperand(graph->Subgraph(0));
        Operand *right_op = this->BuildOperand(graph->Subgraph(1));
        expression = new Expression(expression, output_op, left_op, right_op);
    } else {
        // sum node
        Operand *input_op = this->BuildOperand(graph->Subgraph(0));
        expression = new Expression(expression, output_op, input_op);
        // treat other sum node as transpose of Subgraph(0)
        for (size_type index = 1; index < graph->SubgraphCount(); index++) {
            Operand *sum_op = this->BuildOperand(graph->Subgraph(index));
            expression = new Expression(expression, sum_op, input_op);
        }
    }
    return expression;
}

size_type ExpressionParser::MatchOrder(Vertex2D &order1D,
        const PartialGraph &graph) {
    Vertex2D iso_1D;
    if (this->root_->Isomorphic(&graph, &iso_1D)) {
        for (auto iso : iso_1D.Data()) {
            convert_t convert;
            for (size_type ptr = 0; ptr < iso->size(); ptr++) {
                convert[iso->at(ptr)] = graph.VertexAt(ptr);
            }
            vertex_1D_t *order = new vertex_1D_t;
            this->root_->MatchOrder(convert, *order);
            order1D.PushBack(order);
        }
    }
    return iso_1D.Size();
}

inline typename ExpressionParser::node_T ExpressionParser::CreateAxisNode(
        const std::string &expression, const algebra::OPERATOR_NAME operation,
        node_T node, axis_t *axis) {
    return this->SetID(new GraphNode(expression, operation, node, axis));
}

inline typename ExpressionParser::node_T ExpressionParser::CreateBinaryNode(
        const std::string &expression, const algebra::OPERATOR_NAME operation,
        node_T left, node_T right) {
    return this->CreateBinaryNode(expression, operation, left, right, nullptr);
}

inline typename ExpressionParser::node_T ExpressionParser::CreateBinaryNode(
        const std::string &expression, const algebra::OPERATOR_NAME operation,
        node_T left, node_T right, axis_t *axis) {
    return this->SetID(new GraphNode(expression, operation, left, right, axis));
}

inline typename ExpressionParser::node_T ExpressionParser::CreateLeaf(
        const std::string &expression) {
    return this->SetID(new GraphNode(expression));
}

inline typename ExpressionParser::node_T ExpressionParser::CreateLeafFilter(
        const std::string &, const std::string &op, const std::string &,
        const std::string &) {
    return this->SetID(new GraphNode(op));
}

inline typename ExpressionParser::node_T ExpressionParser::CreateMaskMergeNode(
        const std::string &expression, node_T left, node_T right, node_T mask) {
    node_T merge_result = this->CreateBinaryNode(expression, algebra::MERGE_OP,
            left, right, nullptr);
    return this->CreateBinaryNode(expression, algebra::MASK_OP, merge_result,
            mask, nullptr);
}

inline typename ExpressionParser::node_T ExpressionParser::CreateMaskAxisMergeNode(
        const std::string &expression, node_T left, node_T right,
        axis_1D_t *axis_1D, node_1D_t *node_1D) {
    return this->CreateMaskAxisMergeAxisNode(expression, left, nullptr, right,
            axis_1D, node_1D);
}

typename ExpressionParser::node_T ExpressionParser::CreateMaskAxisMergeAxisNode(
        const std::string &expression, node_T left, axis_t *merge_axis,
        node_T right, axis_1D_t *axis_1D, node_1D_t *node_1D) {
    node_T result = this->CreateBinaryNode(expression, algebra::MERGE_OP, left,
            right, merge_axis);
    for (size_type index = 0; index < axis_1D->size(); index++) {
        node_T mask_result = this->CreateBinaryNode(expression, algebra::MASK_OP,
                result, node_1D->at(index), axis_1D->at(index));
        result = mask_result;
    }
    return result;
}

inline typename ExpressionParser::node_T ExpressionParser::CreatecMaskAxisMergeAxisNode(
        const std::string &expression, node_T left, axis_t *merge_axis,
        node_T right, axis_1D_t *axis_1D, node_1D_t *node_1D) {
    return this->CreateMaskAxisMergeAxisNode(expression, left, merge_axis, right,
            axis_1D, node_1D);
}

typename ExpressionParser::node_T ExpressionParser::CreateMask_Merge__by(
        const std::string &expression, node_T left, node_T right,
        node_1D_t *node_1D, const std::string &key) {
    size_type mask_end = key.find("Merge");
    // parse mask axis
    std::string mask_axis_str = algebra::GetSubstr(key, 0, mask_end);
    axis_1D_t *axis_1D = new axis_1D_t;
    for (size_type start = 0, end = 0; start != std::string::npos;
            start = end + 2) {
        end = mask_axis_str.find("__", start);
        std::string axis_str = algebra::GetSubstr(mask_axis_str, start, end);
        size_type separator = axis_str.find("_");
        axis_t *axis = new axis_t;
        axis->push_back(
                std::atoi(
                        algebra::GetSubstr(axis_str, start, separator).c_str()));
        axis->push_back(std::atoi(axis_str.substr(separator + 1).c_str()));
        axis_1D->push_back(axis);
    }
    // parse merge axis
    size_type merge_end = key.find("__", mask_end);
    std::string merge_axis_str = algebra::GetSubstr(key, mask_end, merge_end);
    axis_t *merge_axis = new axis_t;
    for (size_type start = 0, end = 0; start != std::string::npos;
            start = end + 1) {
        end = merge_axis_str.find("_", start);
        std::string axis_str = algebra::GetSubstr(merge_axis_str, start, end);
        merge_axis->push_back(std::atoi(axis_str.c_str()));
    }
    return this->CreateMaskAxisMergeAxisNode(expression, left, merge_axis, right,
            axis_1D, node_1D);
}

typename ExpressionParser::node_T ExpressionParser::CreatePipelineNode(
        const std::string &expression, node_T left, axis_1D_t *merge_axis_1D,
        node_1D_t *merge_node_1D, axis_2D_t *mask_axis_2D,
        node_2D_t *mask_node_2D) {
    node_T result = left;
    for (size_type level = 0; level < merge_axis_1D->size(); level++) {
        node_T mask_result = this->CreateMaskAxisMergeAxisNode(
                expression + std::to_string(level), result,
                merge_axis_1D->at(level), merge_node_1D->at(level),
                mask_axis_2D->at(level), mask_node_2D->at(level));
        result = mask_result;
    }
    return result;
}

inline typename ExpressionParser::node_T ExpressionParser::CreateScaleNode(
        const std::string &expression, node_T node, algebra::scalar_t) {
    return this->CreateAxisNode(expression, algebra::SCALE_OP, node, nullptr);
}

inline typename ExpressionParser::node_T ExpressionParser::CreateSumNode(
        const std::string &expression, node_1D_t *node_1D) {
    return this->SetID(new GraphNode(expression, node_1D));
}

inline typename ExpressionParser::node_T ExpressionParser::SetID(node_T graph) {
    if (not this->iso_table_.InsertSetID(graph)) {
        // graph is not inserted, no owner
        this->iso_graph_.push_back(graph); // take ownership of graph
    }
    return graph;
}

namespace expressionparser {

void DebugGraphNode(const GraphNode *node) {
    algebra::Ignore(node);
#ifndef NDEBUG
    PRINT(node->ID() << "->" << node << "(");
    node->Write(std::cout);
    PRINT(":" << algebra::OrderedToString(*node->Order()) << ")");
    if (node->SubgraphCount() > 0) {
        PRINT(" =");
        for (size_type index = 0; index < node->SubgraphCount(); index++) {
            const GraphNode *sub_node = node->Subgraph(index);
            PRINT(" " << sub_node->ID() << "->" << sub_node << "(");
            sub_node->Write(std::cout);
            PRINT(":" << algebra::OrderedToString(*sub_node->Order()) << ")");
        }
    }
    PRINTLINE("");
    for (size_type index = 0; index < node->SubgraphCount(); index++) {
        DebugGraphNode(node->Subgraph(index));
    }
#endif
}

} // namespace expressionparser

} // namespace branchbound
