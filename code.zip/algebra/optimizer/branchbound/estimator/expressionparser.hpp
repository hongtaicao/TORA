/*
 * expressionparser.hpp
 *
 * parse a given expression from string to a tree of Expression instances
 * GraphNode instances remember the decomposed graphs
 * GraphNode instances are used to construct Operand instances
 * Operand instances are used to construct Expression instances
 *
 *  Created on: 2020-10-12 16:06
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_OPTIMIZER_BRANCHBOUND_ESTIMATOR_EXPRESSIONPARSER_HPP_
#define ALGEBRA_OPTIMIZER_BRANCHBOUND_ESTIMATOR_EXPRESSIONPARSER_HPP_

#include <unordered_map>
#include <vector>

#include "algebra/basetype.hpp"
#include "algebra/expression/parser.hpp"
#include "algebra/optimizer/branchbound/isomorphismtable.hpp"
#include "algebra/optimizer/branchbound/partialgraph.hpp"
#include "algebra/optimizer/branchbound/type.hpp"
#include "algebra/utility/access.hpp"

namespace branchbound {

// forward declaration
class GraphNode;

class Expression;

class Operand;

// private inheritance for class by default
class ExpressionParser: algebra::Parser<GraphNode *> {
    typedef GraphNode * node_T;
public:
    typedef typename algebra::Parser<node_T>::axis_t axis_t;
    typedef typename algebra::Parser<node_T>::axis_1D_t axis_1D_t;
    typedef typename algebra::Parser<node_T>::axis_2D_t axis_2D_t;
    typedef typename algebra::Parser<node_T>::node_1D_t node_1D_t;
    typedef typename algebra::Parser<node_T>::node_2D_t node_2D_t;
    typedef typename std::unordered_map<vertex_t, vertex_t> convert_t;

    ExpressionParser(const std::string &);
    ~ExpressionParser();

    Expression *BuildExpression();
    /*
     * return the number of matching orders
     * return all matching orders in the first argument
     */
    size_type MatchOrder(Vertex2D &, const PartialGraph &);

protected:
    inline void AddCache(const std::string &, node_T) override {
    }
    inline bool HasCache(const std::string &) override {
        return false;
    }
    inline node_T GetCache(const std::string &) override {
        return nullptr;
    }
    node_T CreateAxisNode(const std::string &, const algebra::OPERATOR_NAME,
            node_T, axis_t *) override;
    node_T CreateBinaryNode(const std::string &, const algebra::OPERATOR_NAME,
            node_T, node_T) override;
    node_T CreateLeaf(const std::string &) override;
    node_T CreateLeafFilter(const std::string &, const std::string &,
            const std::string &, const std::string &) override;
    node_T CreateMaskMergeNode(const std::string &, node_T, node_T, node_T)
            override;
    node_T CreateMaskAxisMergeNode(const std::string &, node_T, node_T,
            axis_1D_t *, node_1D_t *) override;
    node_T CreateMaskAxisMergeAxisNode(const std::string &, node_T, axis_t *,
            node_T, axis_1D_t *, node_1D_t *) override;
    node_T CreatecMaskAxisMergeAxisNode(const std::string &, node_T, axis_t *,
            node_T, axis_1D_t *, node_1D_t *) override;
    node_T CreateMask_Merge__by(const std::string &, node_T, node_T,
            node_1D_t *, const std::string &key) override;
    node_T CreatePipelineNode(const std::string &, node_T, axis_1D_t *,
            node_1D_t *, axis_2D_t *, node_2D_t *) override;
    node_T CreateScaleNode(const std::string &, node_T, algebra::scalar_t)
            override;
    node_T CreateSumNode(const std::string &, node_1D_t *) override;

private:
    Operand *BuildOperand(const GraphNode *);
    Expression *BuildShared(Expression *expression,
            const std::vector<Operand *> &);
    Expression *BuildSingle(Expression *, Operand *);
    node_T CreateBinaryNode(const std::string &, const algebra::OPERATOR_NAME,
            node_T, node_T, axis_t *);
    node_T SetID(node_T);

    IsomorphismTable &iso_table_;
    Expression *expression_; // head of expression (leaf)
    node_T root_; // not own it
    // content owner of the following
    std::vector<node_T> iso_graph_; // hold PartialGraph not in IsoTable
};

namespace expressionparser {

void DebugGraphNode(const GraphNode *);

} // namespace expressionparser

} // namespace branchbound

#endif /* ALGEBRA_OPTIMIZER_BRANCHBOUND_ESTIMATOR_EXPRESSIONPARSER_HPP_ */
