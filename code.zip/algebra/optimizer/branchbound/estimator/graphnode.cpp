/*
 * graphnode.cpp
 *
 *  Created on: 2020-10-12 23:31
 *      Author: Hongtai Cao
 */

#include <iostream>

#include "algebra/basetype.hpp"
#include "algebra/graph/graph.hpp"
#include "algebra/io/writer.hpp"
#include "algebra/optimizer/branchbound/estimator/graphnode.hpp"
#include "algebra/optimizer/branchbound/partialgraph.hpp"
#include "algebra/utility/access.hpp"
#include "algebra/utility/misc.hpp"

namespace branchbound {

GraphNode::GraphNode(const std::string &expression)
        : axis_(nullptr), op_(algebra::ADJACENCY_OP), expression_(expression) {
    // leaf adjacency
    PRINTLINE("GraphNode::GraphNode() " << this << " leaf node");
    if (this->expression_ == "B") {
        this->InsertEdge(0, 1);
        this->InsertEdge(1, 0);
    } else if (this->expression_ == "N") {
        this->InsertVertex(0);
        this->InsertVertex(1);
    } else if (this->expression_ == "U") {
        this->InsertEdge(0, 1);
    } else if (this->expression_ == "UT") {
        this->InsertEdge(1, 0);
    }
    this->Initialize();
    this->order_.push_back(0);
    this->order_.push_back(1);
}

GraphNode::GraphNode(const std::string &expression,
        const algebra::OPERATOR_NAME operation, GraphNode *node, axis_t *axis)
        : axis_(axis), op_(operation), expression_(expression) {
    // AxisNode
    PRINTLINE("GraphNode::GraphNode() " << this << " axis node");
    this->CopyEdgeMapAll(node);
    if ((op_ == algebra::TRANSPOSE_OP) and (axis != nullptr)) {
        for (auto &index : (*axis)) {
            this->order_.push_back(node->order_[index]);
        }
    } else {
        this->order_.assign(node->order_.begin(), node->order_.end());
    }
    this->subgraph_1D_.push_back(node);
    this->Initialize();
}

GraphNode::GraphNode(const std::string &expression,
        const algebra::OPERATOR_NAME operation, GraphNode *left,
        GraphNode *right, axis_t *axis)
        : axis_(axis), op_(operation), expression_(expression) {
    PRINTLINE("GraphNode::GraphNode() " << this << " binary node");
    // BinaryNode with axis
    if (op_ == algebra::MASK_OP) {
        assert(right->IsBuildingBlock());
        assert((axis == nullptr) or (axis->size() == 2));
        this->order_.assign(left->order_.begin(), left->order_.end());
        this->CopyEdgeMapAll(left);
        vertex_t from_node = left->order_.front();
        vertex_t to_node = left->order_.back();
        if (axis != nullptr) {
            from_node = left->order_[axis->front()];
            to_node = left->order_[axis->back()];
        }
        assert(this->HasUnknown(from_node, to_node));
        partialgraph::EraseEdgeFromMap(from_node, to_node, this->unknown_edge_);
        partialgraph::EraseEdgeFromMap(to_node, from_node, this->unknown_edge_);
        if (right->BuildingBlock() == "B") {
            this->InsertEdge(from_node, to_node);
            this->InsertEdge(to_node, from_node);
        } else if (right->BuildingBlock() == "U") {
            this->InsertEdge(from_node, to_node);
        } else if (right->BuildingBlock() == "UT") {
            this->InsertEdge(to_node, from_node);
        }
    } else if (op_ == algebra::MERGE_OP) {
        this->order_.assign(left->order_.begin(), left->order_.end());
        this->CopyEdgeMap(left);
        size_type join_size = std::min(left->SizeV(), right->SizeV()) - 1;
        size_type result_size = left->SizeV() + right->SizeV() - join_size;
        while (this->order_.size() < result_size) {
            this->order_.push_back(this->order_.size());
        }
        // begin: vertex mapping right -> left
        convert_t convert;
        if (axis == nullptr) {
            vertex_t shift = result_size - right->order_.size();
            for (size_type index = 0; index < right->order_.size(); index++) {
                convert[right->order_[index]] = this->order_[index + shift];
            }
            for (size_type from_index = 0; from_index < shift; from_index++) {
                this->AddUnknownEdge(from_index, left->order_.size());
            }
        } else {
            for (size_type index = 0; index < axis->size(); index++) {
                convert[right->order_[index]] = this->order_[axis->at(index)];
            }
            vertex_t target_index = left->order_.size();
            for (size_type index = axis->size(); index < right->order_.size();
                    index++) {
                convert[right->order_[index]] = this->order_[target_index];
                target_index++;
            }
            set_t axis_set(axis->begin(), axis->end());
            for (size_type from_index = 0; from_index < left->order_.size();
                    from_index++) {
                if (axis_set.count(from_index) > 0) {
                    continue;
                }
                this->AddUnknownEdge(from_index, left->order_.size());
            }
        }
        // end: vertex mapping
        this->CopyEdgeMap(right, convert);
        graphnode::CopyUnknownEdgeMap(left->unknown_edge_, right->unknown_edge_,
                convert, this->unknown_edge_);
    } else {
        this->order_.assign(left->order_.begin(), left->order_.end());
        this->CopyEdgeMapAll(left);
    }
    this->subgraph_1D_.push_back(left);
    this->subgraph_1D_.push_back(right);
    this->Initialize();
}

GraphNode::GraphNode(const std::string &expression, graph_1D_t *graph_1D)
        : axis_(nullptr), op_(algebra::SUM_OP), expression_(expression) {
    PRINTLINE("GraphNode::GraphNode() " << this << " sum node");
    this->subgraph_1D_.assign(graph_1D->begin(), graph_1D->end());
    delete graph_1D;
}

GraphNode::GraphNode(const GraphNode *src, const convert_t &convert,
        graph_1D_t &graph_1D)
        : axis_(nullptr), op_(src->op_), expression_(src->expression_) {
    PRINTLINE("GraphNode::GraphNode() " << this << " convert node");
    if (src->axis_ != nullptr) {
        this->axis_ = new axis_t(*src->axis_);
    }
    // collect each instance
    graph_1D.push_back(this);
    // set this->order_
    assert(src->SizeV() == convert.size());
    for (vertex_t vertex : src->order_) {
        this->order_.push_back(convert.at(vertex));
    }
    // set graph
    this->CopyEdgeMap(src, convert);
    graphnode::CopyEdgeMap(src->unknown_edge_, convert, this->unknown_edge_);
    this->Initialize();
    this->DebugGraphNode(src, convert);
    // set this->subgraph_1D_
    convert_t vmap;
    if (this->op_ == algebra::MASK_OP) {
        this->CreateNode0(src, graph_1D);
        const GraphNode *input = src->Subgraph(1);
        size_type ax0 = 0, ax1 = this->SizeV() - 1;
        if (this->axis_ != nullptr) {
            ax0 = algebra::Get(this->axis_, 0);
            ax1 = algebra::Get(this->axis_, 1);
        }
        vmap[input->order_[0]] = this->order_[ax0];
        vmap[input->order_[1]] = this->order_[ax1];
        this->DebugConvert(src, input, vmap, "MASK_OP");
        this->subgraph_1D_.push_back(new GraphNode(input, vmap, graph_1D));
    } else if (this->op_ == algebra::MERGE_OP) {
        this->CreateNode0(src, graph_1D);
        const GraphNode *left_g = src->Subgraph(0);
        const GraphNode *right_g = src->Subgraph(1);
        if (this->axis_ == nullptr) {
            size_type offset = left_g->SizeV()
                    - std::min(left_g->SizeV(), right_g->SizeV()) + 1;
            for (size_type index = offset; index < this->SizeV(); index++) {
                vmap[right_g->order_[index - offset]] = this->order_[index];
            }
        } else {
            for (size_type i = 0; i < this->axis_->size(); i++) {
                vmap[right_g->order_[i]] = this->order_[(*this->axis_)[i]];
            }
            size_type offset = left_g->SizeV() - this->axis_->size();
            for (size_type i = this->axis_->size(); i < right_g->SizeV(); i++) {
                vmap[right_g->order_[i]] = this->order_[offset + i];
            }
        }
        this->DebugConvert(src, right_g, vmap, "MERGE_OP");
        this->subgraph_1D_.push_back(new GraphNode(right_g, vmap, graph_1D));
    } else if (this->op_ == algebra::TRANSPOSE_OP) {
        const GraphNode *input = src->Subgraph(0);
        for (size_type index = 0; index < this->axis_->size(); index++) {
            vmap[input->order_[(*this->axis_)[index]]] = this->order_[index];
        }
        this->DebugConvert(src, input, vmap, "TRANSPOSE_OP");
        this->subgraph_1D_.push_back(new GraphNode(input, vmap, graph_1D));
    }
}

GraphNode::~GraphNode() {
    PRINTLINE("GraphNode::~GraphNode(): " << this << " axis " << this->axis_);
    delete this->axis_;
}

void GraphNode::AddUnknownEdge(size_type from_index, size_type to_index) {
    vertex_t from_node = this->order_[from_index];
    for (; to_index < this->order_.size(); to_index++) {
        vertex_t to_node = this->order_[to_index];
        if (this->unknown_edge_.count(from_node) == 0) {
            this->unknown_edge_[from_node] = new set_t;
        }
        this->unknown_edge_[from_node]->insert(to_node);
        if (this->unknown_edge_.count(to_node) == 0) {
            this->unknown_edge_[to_node] = new set_t;
        }
        this->unknown_edge_[to_node]->insert(from_node);
    }
}

inline void GraphNode::CopyEdgeMap(const GraphNode *source,
        const convert_t &convert) {
    // copy with shift conversion
    graphnode::CopyEdgeMap(source->forward_edge_, convert, this->forward_edge_);
    graphnode::CopyEdgeMap(source->backward_edge_, convert,
            this->backward_edge_);
}

void GraphNode::CreateNode0(const GraphNode *source, graph_1D_t &graph_1D) {
    convert_t convert;
    const GraphNode *input = source->Subgraph(0);
    for (size_type index = 0; index < input->SizeV(); index++) {
        convert[input->order_[index]] = this->order_[index];
    }
    this->DebugConvert(source, input, convert, "INPUT");
    this->subgraph_1D_.push_back(new GraphNode(input, convert, graph_1D));
}

void GraphNode::DebugConvert(const GraphNode *source, const GraphNode *input,
        const convert_t &convert, const std::string message) {
    // check whether convert is correct
    algebra::Ignore(source);
    algebra::Ignore(convert);
    algebra::Ignore(input);
    algebra::Ignore(message);
#ifndef NDEBUG
    if (source->axis_ != nullptr) {
        for (size_type index = 0; index < source->axis_->size(); index++) {
            assert((*this->axis_)[index] == (*source->axis_)[index]);
        }
    }
    assert(source->op_ == this->op_);
    assert(source->expression_ == this->expression_);
    PRINT("GraphNode::DebugConvert() " << this << " [");
    PRINT(algebra::OrderedToString(this->order_) << "] = [");
    PRINT(algebra::OrderedToString(source->Subgraph(0)->order_) << "] ");
    PRINT(algebra::ConfigName(this->op_));
    for (size_type index = 1; index < source->SubgraphCount(); index++) {
        PRINT(" [");
        PRINT(algebra::OrderedToString(source->Subgraph(index)->order_));
        PRINT("]");
    }
    PRINT(" axis [");
    if (this->axis_ != nullptr) {
        PRINT(algebra::OrderedToString(*this->axis_));
    }
    PRINTLINE("]");
    PRINT("    " << message << " ");
    graphnode::DebugGraphNode(input->order_, this->order_, convert);
#endif
}

void GraphNode::DebugGraphNode(const GraphNode *source,
        const convert_t &convert) {
    // check whether GraphNode is correct
    algebra::Ignore(source);
    algebra::Ignore(convert);
#ifndef NDEBUG
    PRINTLINE("GraphNode::DebugGraphNode() " << this << " update vertex");
    PRINT("    ");
    graphnode::DebugGraphNode(source->order_, this->order_, convert);
    PRINT("GraphNode::DebugGraphNode() " << this << " source graph ");
    source->Write(std::cout);
    std::cout << std::endl;
    source->WriteDetail(std::cout);
    PRINT("GraphNode::DebugGraphNode() " << this << " target graph ");
    this->Write(std::cout);
    std::cout << std::endl;
    this->WriteDetail(std::cout);
#endif
}

namespace graphnode {

void CopyEdgeMap(const edgemap_t &source, const convert_t &convert,
        edgemap_t &target) {
    // copy with map conversion
    for (auto &pair : source) {
        vertex_t head = convert.at(pair.first);
        partialgraph::InsertVertex(head, target);
        set_t *neighbor_set = target[head];
        for (auto neighbor : (*pair.second)) {
            neighbor_set->insert(convert.at(neighbor));
        }
    }
}

void CopyUnknownEdgeMap(const edgemap_t &left, const edgemap_t &right,
        const convert_t &convert, edgemap_t &target) {
    // copy into target if exist in both "left" and "right with convert"
    for (auto &pair : right) {
        vertex_t head = convert.at(pair.first);
        if (left.count(head) == 0) {
            continue;
        }
        set_t *neighbor_set = left.at(head);
        for (auto &neighbor : (*pair.second)) {
            vertex_t tail = convert.at(neighbor);
            if (neighbor_set->count(tail) == 0) {
                continue;
            }
            if (target.count(head) == 0) {
                target[head] = new set_t;
            }
            target[head]->insert(tail);
        }
    }
}

void DebugGraphNode(const vertex_1D_t &source_order,
        const vertex_1D_t &target_order, const convert_t &convert) {
    algebra::Ignore(source_order);
    algebra::Ignore(target_order);
    algebra::Ignore(convert);
    PRINT("source order [" << algebra::OrderedToString(source_order) << "] ");
    PRINT("target order [" << algebra::OrderedToString(target_order) << "]");
    PRINTLINE("");
#ifndef NDEBUG
    algebra::PrintMap(convert);
#endif
}

} // namespace graphnode

} // namespace branchbound
