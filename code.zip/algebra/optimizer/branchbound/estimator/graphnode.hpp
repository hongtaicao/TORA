/*
 * graphnode.hpp
 *
 * used by "algebra/optimizer/branchbound/estimator/expressionparser.hpp"
 * the above parser uses GraphNode instances to create Operand instances
 *
 *  Created on: 2020-10-12 16:46
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_OPTIMIZER_BRANCHBOUND_ESTIMATOR_GRAPHNODE_HPP_
#define ALGEBRA_OPTIMIZER_BRANCHBOUND_ESTIMATOR_GRAPHNODE_HPP_

#include <string>

#include "algebra/basetype.hpp"
#include "algebra/graph/graph.hpp"
#include "algebra/optimizer/branchbound/estimator/expressionparser.hpp"
#include "algebra/optimizer/branchbound/partialgraph.hpp"
#include "algebra/optimizer/branchbound/type.hpp"

namespace branchbound {

class GraphNode: public PartialGraph {
    typedef typename ExpressionParser::axis_t axis_t;
    typedef typename ExpressionParser::node_1D_t graph_1D_t;

public:
    typedef typename ExpressionParser::convert_t convert_t;

    /*
     * GraphNode represents graph_O = operator(graph_A, graph_B)
     * compute order_ by combining input.order_ and axis
     * order_ is equivalent to Operand::order_
     */
    GraphNode(const std::string &); // leaf adjacency
    GraphNode(const std::string &, const algebra::OPERATOR_NAME, GraphNode *,
            axis_t *); // AxisNode
    GraphNode(const std::string &, const algebra::OPERATOR_NAME, GraphNode *,
            GraphNode *, axis_t *); // BinaryNode with axis
    GraphNode(const std::string &, graph_1D_t *); // SumNode
    GraphNode(const GraphNode *, const convert_t &, graph_1D_t &); // convert
    ~GraphNode() override;

    inline std::string BuildingBlock() const {
        // find class that has this name and then consider overload
        return PartialGraph::BuildingBlock(this->order_[0], this->order_[1]);
    }
    template<typename container_T>
    void MatchOrder(const convert_t &, container_T &);
    inline const vertex_1D_t *Order() const {
        // this initializes Operand::order_
        return &this->order_;
    }
    inline GraphNode *Subgraph(size_type index) const {
        return this->subgraph_1D_[index];
    }
    inline size_type SubgraphCount() const {
        return this->subgraph_1D_.size();
    }

private:
    void AddUnknownEdge(size_type, size_type);
    inline void CopyEdgeMap(const GraphNode *source) {
        algebra::graph::CopyEdgeMap<vertex_t>(source->forward_edge_,
                this->forward_edge_);
        algebra::graph::CopyEdgeMap<vertex_t>(source->backward_edge_,
                this->backward_edge_);
    }
    inline void CopyEdgeMapAll(const GraphNode *source) {
        this->CopyEdgeMap(source);
        algebra::graph::CopyEdgeMap<vertex_t>(source->unknown_edge_,
                this->unknown_edge_);
    }
    inline void CopyEdgeMap(const GraphNode *, const convert_t &);
    void CreateNode0(const GraphNode *, graph_1D_t &);
    void DebugConvert(const GraphNode *, const GraphNode *, const convert_t &,
            const std::string);
    void DebugGraphNode(const GraphNode *, const convert_t &);
    inline void Initialize() {
        this->SetVertexAndEdgeSize();
        this->size_unk_ = algebra::graph::CountEdge<vertex_t>(
                this->unknown_edge_) / 2;
        this->SetBKnUSize(); // need size_unk_ value
    }

    axis_t *axis_; // hold constructor argument and own it
    const algebra::OPERATOR_NAME op_;
    const std::string expression_;
    // contain all child node, but not own them
    // owned by IsoTable or ExpressionParser::iso_graph_
    graph_1D_t subgraph_1D_;
    vertex_1D_t order_; // vertex order. equivalent to Operand::order_
};

template<typename container_T>
void GraphNode::MatchOrder(const convert_t &convert, container_T &container) {
    for (auto &item : this->order_) {
        container.push_back(convert.at(item));
    }
}

namespace graphnode {

typedef typename GraphNode::convert_t convert_t;

void CopyEdgeMap(const edgemap_t &, const convert_t &, edgemap_t &);
void CopyUnknownEdgeMap(const edgemap_t &, const edgemap_t &, const convert_t &,
        edgemap_t &);
void DebugGraphNode(const vertex_1D_t &, const vertex_1D_t &,
        const convert_t &);

} // namespace graphnode

} // namespace branchbound

#endif /* ALGEBRA_OPTIMIZER_BRANCHBOUND_ESTIMATOR_GRAPHNODE_HPP_ */
