/*
 * expression.hpp
 *
 *  Created on: 2020-8-18 8:39
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_OPTIMIZER_BRANCHBOUND_EXPRESSION_HPP_
#define ALGEBRA_OPTIMIZER_BRANCHBOUND_EXPRESSION_HPP_

#include <queue>
#include <string>

#include "algebra/basetype.hpp"
#include "algebra/io/writer.hpp"
#include "algebra/optimizer/branchbound/operand.hpp"
#include "algebra/optimizer/branchbound/type.hpp"

namespace branchbound {

class Expression {
// take care of cost of a single operation
// child -> parent -> parent of parent
// top expression represent operation over building block
public:
    Expression(Operand *); // used by final result
    Expression(Expression *, Operand *, Operand *); // used by a transpose
    Expression(Expression *, Operand *, Operand *, Operand *); // binary op

    void CollectResource(std::unordered_set<Expression *> &,
            std::unordered_set<Operand *> &);
    inline double Cost() const {
        // the lower bound cost of current expression
        return this->cost_;
    }
    inline bool IsComplete() const {
        return this->pool_.empty();
    }
    const vertex_1D_t &MatchOrder() const;
    inline Expression *Parent() const {
        return this->parent_;
    }
    void PopAll(operand_1D_t &);
    void PopTopIsomorphic(operand_1D_t &);
    void PushAll(const operand_1D_t &);
    void ToSingleLine(std::string &) const;

    struct Worse {
        inline bool operator()(const Expression *a, const Expression *b) const {
            return a->cost_ > b->cost_;
        }
    };

    void Write(std::ostream &);

private:
    inline void PushInput(Operand *input) {
        this->input_.push_back(input);
        this->PushPool(input);
    }
    inline void PushPool(Operand *operand) {
        if (not operand->IsBuildingBlock()) {
            this->pool_.push(operand);
        }
    }
    inline void SetCostIncrement(double cost) {
        PRINT(" output cost -" << this->output_->Cost());
#ifndef NDEBUG
        if (cost < this->output_->Cost()) {
            // verify cost lower bound estimation
            std::cout << "Expression.CostIncrement(): Invalid cost lower bound"
                    << std::endl;
            this->Write(std::cout);
            throw;
        }
#endif
        this->cost_ = cost - this->output_->Cost();
    }
    inline void WriteInfo(std::ostream &out) {
        out << "    parent=" << this->parent_;
        if (this->parent_ != nullptr) {
            out << " parent_cost=" << this->parent_->Cost();
        }
        out << " this=" << this << " cost=" << this->Cost() << " pool_size="
                << this->pool_.size() << std::endl;
    }
    inline void WriteInput(std::ostream &out, const size_type index) {
        std::cout << "    input=" << this->input_[index] << " ";
        this->input_[index]->Write(out);
        std::cout << std::endl;
    }
    inline void WriteOutputInput(std::ostream &out) {
        std::cout << "    output=" << this->output_ << " ";
        this->output_->Write(std::cout);
        std::cout << std::endl;
        this->WriteInput(out, 0);
    }

    // https://stackoverflow.com/a/34851417/11193802, segment fault
    // https://stackoverflow.com/a/1480483/11193802
    // sort Operand in ascending order => top is the largest operand
    typedef std::priority_queue<Operand *, operand_1D_t, Operand::Smaller> max_heap_t;
    // cost of the plan
    double cost_;
    // this class does not own any of the following
    // cleared by collecting into set
    Expression *parent_;
    max_heap_t pool_;
    Operand *output_; // Operand maybe shared among Expression
    operand_1D_t input_;

public:
    typedef std::vector<Expression *> expression_1D_t;
    // https://stackoverflow.com/a/34851417/11193802, segment fault
    // https://stackoverflow.com/a/1480483/11193802
    // sort queue element by comp, top is the end
    // sort in cost descending order => lowest cost at the top
    typedef std::priority_queue<Expression *, expression_1D_t, Expression::Worse> min_heap_t;
};

namespace expression {

void cMaskAxisAndMergeAxis(std::string &,
        std::unordered_map<const Operand *, const operand_1D_t *> &,
        const Operand *);

void cMaskAxisMergeAxis(std::string &,
        std::unordered_map<const Operand *, const operand_1D_t *> &,
        const Operand *);

void Throw(const Operand *, const operand_1D_t *);

} // namespace expression

} // namespace branchbound

#endif /* ALGEBRA_OPTIMIZER_BRANCHBOUND_EXPRESSION_HPP_ */
