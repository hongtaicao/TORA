/*
 * singleton.hpp
 *
 *  Created on: 2020-8-25 16:08
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_OPTIMIZER_BRANCHBOUND_SINGLETON_HPP_
#define ALGEBRA_OPTIMIZER_BRANCHBOUND_SINGLETON_HPP_

namespace branchbound {

// https://stackoverflow.com/a/1008289/11193802
template<typename class_T>
class Singleton {
public:
    static class_T& Instance() {
        static class_T instance; // Guaranteed to be destroyed.
        // Instantiated on first use.
        return instance;
    }
    Singleton(const Singleton<class_T> &) = delete;
    Singleton<class_T> &operator=(const Singleton<class_T> &) = delete;

private:
    Singleton() {
    }
};

}

#endif /* ALGEBRA_OPTIMIZER_BRANCHBOUND_SINGLETON_HPP_ */
