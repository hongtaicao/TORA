/*
 * decompositiontable.hpp
 *
 *  Created on: 2020-8-19 3:58
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_OPTIMIZER_BRANCHBOUND_DECOMPOSITIONTABLE_HPP_
#define ALGEBRA_OPTIMIZER_BRANCHBOUND_DECOMPOSITIONTABLE_HPP_

#include <string>

#include "algebra/algorithm/tritree.hpp"
#include "algebra/optimizer/branchbound/isomorphismtable.hpp"
#include "algebra/optimizer/branchbound/partialgraph.hpp"
#include "algebra/optimizer/branchbound/singleton.hpp"
#include "algebra/optimizer/branchbound/type.hpp"
#include "algebra/utility/vector2d.hpp"

namespace branchbound {

class DecompositionTable {
    typedef algebra::Vector2D<size_type> decomposition_t;
public:
    DecompositionTable()
            : algorithm_(DEC_BALANCE), iso_table_(SingleIsoTable::Instance()) {
    }
    ~DecompositionTable() {
        this->Clear();
    }
    DecompositionTable(const DecompositionTable &) = delete;
    DecompositionTable &operator=(const DecompositionTable &) = delete;

    inline std::string Algorihtm() const {
        if (this->algorithm_ == DEC_BALANCE) {
            return "DEC_BALANCE";
        } else if (this->algorithm_ == DEC_MOVE) {
            return "DEC_MOVE";
        } else {
            return "";
        }
    }
    inline void Clear() {
        algebra::DeleteMapValue(this->table_);
        this->table_.clear();
        this->iso_table_.Clear();
    }
    inline const decomposition_t *Decompose(size_type graph_id) {
        return this->DecomposeDFS(graph_id, 1);
    }

    inline const IsomorphismEntry *FindEntry(const PartialGraph *graph) {
        return this->iso_table_.FindEntry(graph);
    }
    inline const IsomorphismEntry *FindEntry(size_type graph_id) {
        return this->iso_table_.FindEntry(graph_id);
    }
    const IsomorphismEntry *InsertFindEntryDelete(PartialGraph *&);

private:
    // identify identical decomposition
    typedef typename algebra::TriTree<size_type> tritree_t;

    void CheckCandidate(decomposition_t &, PartialGraph *, PartialGraph *,
            tritree_t &, size_type);

    // decompose algorithm
    void DecomposeByBalance(decomposition_t &, const PartialGraph * const,
            size_type);
    // decompose algorithm
    inline void DecomposeByMove(decomposition_t &decomp2D,
            const PartialGraph * const graph, size_type depth) {
        // decompose to a building block
        this->DecomposeStart(decomp2D, graph, depth);
        // increase size of right operand
        this->DecomposeRecursion(decomp2D, 0, graph, depth);
    }

    const decomposition_t *DecomposeDFS(size_type, size_type);

    // decompose: increase size of right operand
    void DecomposeRecursion(decomposition_t &, size_type,
            const PartialGraph * const, size_type);
    // decompose into: a graph and a building block
    void DecomposeStart(decomposition_t &, const PartialGraph * const,
            size_type);
    // input PartialGraph *be a nullptr after this call

    inline bool IsCandidatePair(size_type depth, const IsomorphismEntry *left,
            const IsomorphismEntry *right) {
        return (this->IsCandidate(depth, left)
                and this->IsCandidate(depth, right));
    }
    inline bool IsCandidate(size_type depth, const IsomorphismEntry *entry) {
        if ((entry->Graph()->IsBuildingBlock())
                or (this->DecomposeDFS(entry->ID(), depth)->Size() > 0)) {
            // entry is a building block or entry has decomposition
            return true;
        }
        return false;
    }

    const DECOMPOSITION_ALGORITHM algorithm_;
    // both tables do not care about attribute order
    // both tables use the same key of PartialGraph
    // DecompositionTable takes care of decomposition
    std::unordered_map<size_type, const decomposition_t *> table_;
    // PartialGraphTable takes care of isomorphism
    IsomorphismTable &iso_table_;
};

typedef Singleton<DecompositionTable> SingleDecTable;

} // namespace branchbound

#endif /* ALGEBRA_OPTIMIZER_BRANCHBOUND_DECOMPOSITIONTABLE_HPP_ */
