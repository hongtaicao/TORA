/*
 * isomorphism.cpp
 *
 *  Created on: 2020-8-27 18:32
 *      Author: Hongtai Cao
 */

#include <algorithm>
#include <assert.h>
#include <unordered_map>

#include "algebra/algorithm/math.hpp"
#include "algebra/algorithm/tritree.hpp"
#include "algebra/optimizer/branchbound/isomorphism.hpp"
#include "algebra/optimizer/branchbound/type.hpp"

namespace branchbound {

void Isomorphism::BaseOrder(std::vector<size_type> &base_order,
        const vertex_1D_t &order, size_type index) const {
    // compute base graph vertex order under the iso given by its index
    // build vertex to base order
    std::unordered_map<vertex_t, size_type> graph2base;
    const vertex_1D_t *iso = this->iso_->At(index);
    for (size_type i = 0; i < iso->size(); i++) {
        graph2base[(*iso)[i]] = i;
    }
    for (auto &vertex : order) {
        base_order.push_back(graph2base[vertex]);
    }
}

void Isomorphism::BuildIsomorphicMap(vmap_t &vmap) const {
    // they map to identical base_graph vertex
    // build map from anyone to all the others
    auto source = this->iso_->At(0);
    for (size_type i = 1; i < this->iso_->Size(); i++) {
        vmap.AddMap(source, this->iso_->At(i));
    }
}

void Isomorphism::BuildIsomorphicOrder(vmap_t &vmap) {
    // if automorphism is greater than 0, then there are identical order
    // use tritree to remember all identical order under isomorphism
    typedef typename algebra::TriTree<vertex_t> tritree_t;
    tritree_t tritree;
    tritree_t::sequence_t permutation(*this->iso_->At(0));
    std::sort(permutation.begin(), permutation.end());
    do {
        if (tritree.Index(permutation) == 1) {
            this->order_unique_.PushBack(new vertex_1D_t(permutation));
        } else {
            this->order_remain_.PushBack(new vertex_1D_t(permutation));
        }
        // index identical order
        for (size_type index = 0; index < vmap.Size(); index++) {
            tritree_t::sequence_t order;
            vmap.GetMap(order, index, permutation);
            tritree.Index(order);
        }
    } while (std::next_permutation(permutation.begin(), permutation.end()));
    size_type total_order = algebra::factorial(this->iso_->EntrySize());
    assert(this->order_unique_.Size() == total_order / this->iso_->Size());
    assert(
            this->order_remain_.Size()
                    == total_order - this->order_unique_.Size());
}

void Isomorphism::IsomorphicOrder(Vertex2D &result,
        const vertex_1D_t &order) const {
    // add self as result
    for (const auto &item : order) {
        result.PartialPushBack(item);
    }
    result.CopyClearPartial();
    // add isomorphic order
    vmap_t vmap;
    this->BuildIsomorphicMap(vmap);
    for (size_type index = 0; index < vmap.Size(); index++) {
        vertex_1D_t *target = new vertex_1D_t;
        vmap.GetMap(*target, index, order);
        result.PushBack(target);
    }
}

namespace isomorphism {

/***************************************************************************
 * Statement:
 *  Given a permutation of a set, return the index of the permutation.
 *
 * Sample Input: {3, 1, 2}
 * Sample Output: 4
 *
 * Time Complexity of Solution:
 *   Best = Average = Worst = O(n^2)
 * Space Complexity of Solution:
 *   Best = Average = Worst = O(1)
 *
 * Details:
 *   A permutation is an ordering of the elements of a set. So for a set
 *   constituted of the elements 1,2,3; then {1,2,3} and {2,1,3} are two
 *   different permutations of the set. A set of length n has n! permutations.
 *   For example, if a set contains 3 elements, it has 3! = 3*2*1 = 6
 *   permutations. The following algorithm uses the relation between
 *   permutation and factorial to find the index of a given permutation
 *   of a set.
 *
 *   Illustrating by manually getting the index of {2, 4, 3, 1}.
 *   Since this is a 4-element set, we know there are 4! permutations
 *   (4! = 4*3*2*1). If the set only had 3 elements, we would have 3*2*1
 *   permutations. If the set only had 2 elements, we would have 2!=2*1
 *   permutations; and so on.
 *
 *   ASIDE: The decimal system of counting is a positional system.
 *   A 3-element decimal number, for instance, has the following three
 *   positional weights: hundred, ten, unit. Hence, we know the value of the
 *   number 472 because we understand: 4*hundred + 7*ten + 2*unit.
 *
 *   If we treat our 4-element set as a positional system, then we get the
 *   following positional weights: 3!, 2!, 1!, 0. So that the index of
 *   {2, 4, 3, 1} is: x*3!+y*2!+z*1!+w*0. Presently it suffices to find the
 *   values of x,y,z to calculate the index (we ignore w because it is paired
 *   with 0). x,y,z are counters: the number of succeeding elements less than
 *   the element being considered. For example, in {2, 4, 3, 1}, there are
 *   two succeeding elements less than 4 (namely 3 and 1). For 2 it's 1 (1);
 *   for 4 it's 2 (3 and 1); for 3 it's 1 (1); for 1 it's 0.
 *
 *   Now we can calculate the index of {2, 4, 3, 1} as: x=1, y=2, z=1:
 *   x*3!+y*2!+z*1!+w*0 = 1*3! + 2*2! + 1*1! = 6 + 4 + 1 = 11.
 *
 *   Now that we have our algorithm, the trick is implementing it. As you
 *   may imagine there are a number of possible implementations. The
 *   presented implementation focuses on using constant auxiliary memory:
 *   memory = O(1) and time = O(n^2). The code is written for readability.
 **************************************************************************/
size_type IndexOfPermutation(const vertex_1D_t &permutation) {
    // http://www.geekviewpoint.com/java/numbers/permutation_index
    size_type index = 0;
    // position 1 is paired with factor 0 and so is skipped
    size_type position = 2;
    size_type factor = 1;
    for (int p = permutation.size() - 2; p >= 0; p--) {
        size_type successors = 0;
        for (size_type q = p + 1; q < permutation.size(); q++) {
            if (permutation[p] > permutation[q]) {
                successors++;
            }
        }
        index += (successors * factor);
        factor *= position;
        position++;
    }
    return index;
}

} // namespace isomorphism

}
