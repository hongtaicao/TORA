/*
 * decomposeprofile.hpp
 *
 *  Created on: 2020-9-9 4:40
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_OPTIMIZER_BRANCHBOUND_DECOMPOSEPROFILE_HPP_
#define ALGEBRA_OPTIMIZER_BRANCHBOUND_DECOMPOSEPROFILE_HPP_

#include "algebra/optimizer/branchbound/type.hpp"

namespace branchbound {

class DecomposeProfile {
public:
    DecomposeProfile()
            : query_time_(0), initialize_time_(0), fail_branch_(0),
              total_branch_(0), initial_pool_size_(0), remain_pool_size_(0),
              decompose_time_(0), decompose_build_time_(0),
              best_count_(0), best_cost_(0), margin_(0) {
    }

    inline void Reset() {
        // initialize
        this->query_time_ = 0;
        this->initialize_time_ = 0;
        // size
        this->fail_branch_ = 0;
        this->total_branch_ = 0;
        this->initial_pool_size_ = 0;
        this->remain_pool_size_ = 0;
        // cost
        this->decompose_time_ = 0;
        this->decompose_build_time_ = 0;
        this->best_count_ = 0;
        this->best_cost_ = 0;
        this->margin_ = 0;

    }

    // initialize
    double query_time_;
    double initialize_time_;
    // size
    size_type fail_branch_;
    size_type total_branch_;
    size_type initial_pool_size_;
    size_type remain_pool_size_;
    // cost
    double decompose_time_;
    double decompose_build_time_;
    size_type best_count_;
    double best_cost_;
    double margin_;
};

} // namespace branchbound

#endif /* ALGEBRA_OPTIMIZER_BRANCHBOUND_DECOMPOSEPROFILE_HPP_ */
