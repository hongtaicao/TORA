/*
 * isomorphismtable.hpp
 *
 *  Created on: 2020-8-17 12:37
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_OPTIMIZER_BRANCHBOUND_ISOMORPHISMTABLE_HPP_
#define ALGEBRA_OPTIMIZER_BRANCHBOUND_ISOMORPHISMTABLE_HPP_

#include <assert.h>

#include "algebra/optimizer/branchbound/isomorphismentry.hpp"
#include "algebra/optimizer/branchbound/partialgraph.hpp"
#include "algebra/optimizer/branchbound/singleton.hpp"
#include "algebra/optimizer/branchbound/type.hpp"

namespace branchbound {

class IsomorphismTable {
public:
    IsomorphismTable() {
    }
    ~IsomorphismTable() {
        this->Clear();
    }

    IsomorphismTable(const IsomorphismTable &) = delete;
    IsomorphismTable &operator=(const IsomorphismTable &) = delete;

    void Clear();
    inline const IsomorphismEntry *FindEntry(const PartialGraph *graph) {
        return this->iso_table_[graph->ID()];
    }
    inline const IsomorphismEntry *FindEntry(const size_type graph_id) {
        return this->iso_table_[graph_id];
    }
    inline bool InsertSetID(PartialGraph *graph) {
        // return true if inserted and ownership taken
        if ((graph->ID() == 0) and this->InsertAssignID(graph)) {
            // given graph is the base graph
            // ownership is taken
            return true;
        }
        // the given graph should be cleaned outside if necessary
        return false;
    }

private:
    // return true if given graph is inserted
    bool InsertAssignID(PartialGraph *);
    inline size_type NextID() const {
        // ID = 0 is reserved and should not be assigned to any PartialGraph
        return this->iso_table_.size() + 1;
    }

    typedef std::vector<size_type> id_1D_t;
    typedef std::unordered_map<size_type, id_1D_t *> table_u_t;
    typedef std::unordered_map<size_type, table_u_t *> table_b_t;
    typedef std::unordered_map<size_type, table_b_t *> table_k_t;
    std::unordered_map<size_type, table_k_t *> feature_table_;
    /*
     * iso_table_.key == IsomorphismEntry.graph_.id_
     * IsomorphismEntry.graph_ is isomorphic to graph of iso_id_
     * for canonical graphs, they are isomorphic to themselves
     * for non-canonical graphs, iso_id_ is the id of canonical graph
     */
    std::unordered_map<size_type, IsomorphismEntry *> iso_table_;
};

typedef Singleton<IsomorphismTable> SingleIsoTable;

}

#endif /* ALGEBRA_OPTIMIZER_BRANCHBOUND_ISOMORPHISMTABLE_HPP_ */
