/*
 * isomorphismentry.hpp
 *
 *  Created on: 2020-8-24 16:27
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_OPTIMIZER_BRANCHBOUND_ISOMORPHISMENTRY_HPP_
#define ALGEBRA_OPTIMIZER_BRANCHBOUND_ISOMORPHISMENTRY_HPP_

#include <iostream>
#include <ostream>

#include "algebra/basetype.hpp"
#include "algebra/optimizer/branchbound/isomorphism.hpp"
#include "algebra/optimizer/branchbound/partialgraph.hpp"
#include "algebra/optimizer/branchbound/type.hpp"

namespace branchbound {

class IsomorphismEntry {
public:
    IsomorphismEntry(PartialGraph *graph, size_type base_id, Vertex2D *iso_2D)
            : graph_(graph), base_id_(base_id), iso_(new Isomorphism(iso_2D)) {
#ifndef NDEBUG
        this->Write(std::cout);
#endif
    }
    ~IsomorphismEntry() {
        delete this->graph_;
        delete this->iso_;
    }

    inline size_type BaseID() const {
        return this->base_id_;
    }
    inline const PartialGraph *Graph() const {
        return this->graph_;
    }
    inline size_type ID() const {
        return this->graph_->ID();
    }
    inline const Isomorphism *ISO() const {
        return this->iso_;
    }
    inline void Write(std::ostream &out) const {
        out << "IsomorphismEntry::Write()" << std::endl;
        out << "    ID=" << this->ID() << " base_ID=" << this->BaseID()
                << " Isomorphism Size=" << this->iso_->Size()
                << " PartialGraph=";
        this->Graph()->Write(out);
        std::cout << std::endl;
    }

private:
    // own PartialGraph *
    PartialGraph *graph_;
    size_type base_id_;
    const Isomorphism *iso_;
};

} // namespace branchbound

#endif /* ALGEBRA_OPTIMIZER_BRANCHBOUND_ISOMORPHISMENTRY_HPP_ */
