/*
 * decomposegraph.hpp
 *
 *  Created on: 2020-8-16 17:49
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_OPTIMIZER_BRANCHBOUND_DECOMPOSEGRAPH_HPP_
#define ALGEBRA_OPTIMIZER_BRANCHBOUND_DECOMPOSEGRAPH_HPP_

#include <queue>
#include <string>
#include <unordered_set>
#include <vector>

#include "algebra/algorithm/unionfindset.hpp"
#include "algebra/argparser.hpp"
#include "algebra/optimizer/branchbound/decomposeprofile.hpp"
#include "algebra/optimizer/branchbound/decompositiontable.hpp"
#include "algebra/optimizer/branchbound/expression.hpp"
#include "algebra/optimizer/branchbound/operand.hpp"
#include "algebra/optimizer/branchbound/type.hpp"

namespace branchbound {

/*
 * an optimizer that uses shared computation of full graph matching only
 * using dynamic programming for cost estimate
 */
class DecomposeGraph {
    typedef typename Expression::expression_1D_t expression_1D_t;
public:
    DecomposeGraph(const algebra::ArgParser &argparser)
            : argparser_(argparser), dec_table_(SingleDecTable::Instance()) {
    }
    ~DecomposeGraph() {
        this->Clear();
    }

    void BuildExpression();
    inline void Clear() {
        this->ClearPool();
        this->ClearTable();
    }
    void ClearPool();
    void ClearTable() {
        this->dec_table_.Clear();
    }
    const expression_1D_t &Completed() const {
        return this->completed_;
    }
    void Initialize();
    const DecomposeProfile &Profile() const {
        return this->profile_;
    }
    inline Expression *Top() {
        // retrieve the top Operand and remove it from pool
        Expression *top = this->pool_.top();
        this->pool_.pop();
        return top;
    }

private:
    // build an expression for sharing among operands
    void BuildShared(Expression *, const operand_1D_t &, const operand_1D_t &);
    // build an expression for a single operand
    void BuildSingle(Expression *, const operand_1D_t &, const operand_1D_t &);
    void BuildSingleInner(Expression *, const operand_1D_t &, Operand *,
            const operand_1D_t &, const operand_1D_t &);

    const algebra::ArgParser &argparser_;
    DecomposeProfile profile_;
    DecompositionTable &dec_table_;
    // DecomposeGraph is the owner of Expression * and Operand *
    expression_1D_t completed_;
    typename Expression::min_heap_t pool_;
    // used for resource release
    // owner of Expression * and Operand *
    std::unordered_set<Expression *> expression_set_;
    std::unordered_set<Operand *> operand_set_;
};

namespace decomposegraph {

void BuildOperand(operand_1D_t &, const IsomorphismEntry * const);
typedef algebra::UnionFindSet<Operand *> ufs_t;
typedef typename ufs_t::label2item_t ufs_group_t;
Expression *BuildShared(Expression *, const operand_1D_t &, ufs_group_t &);
bool PossibleDecomposition(const vertex_1D_t &, const IsomorphismEntry * const,
        const IsomorphismEntry * const);

}

} // namespace algebra

#endif /* ALGEBRA_OPTIMIZER_BRANCHBOUND_DECOMPOSEGRAPH_HPP_ */
