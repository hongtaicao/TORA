/*
 * isomorphism.hpp
 *
 *  Created on: 2020-8-27 13:32
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_OPTIMIZER_BRANCHBOUND_ISOMORPHISM_HPP_
#define ALGEBRA_OPTIMIZER_BRANCHBOUND_ISOMORPHISM_HPP_

#include <unordered_map>
#include <vector>

#include "algebra/optimizer/branchbound/type.hpp"
#include "algebra/utility/access.hpp"

namespace branchbound {

namespace isomorphism {

template<typename item_T>
class VectorMap {
public:
    typedef std::vector<item_T> item_1D_t;
    ~VectorMap();

    void AddMap(const item_1D_t *, const item_1D_t *);

    template<typename item_1D_T>
    void GetMap(item_1D_T &, const size_type, const item_1D_T &);
    inline size_type Size() const {
        return this->data_.size();
    }

private:
    typedef std::unordered_map<item_T, item_T> map_t;
    std::vector<map_t *> data_;
};

template<typename item_T>
VectorMap<item_T>::~VectorMap() {
    algebra::DeleteContent(this->data_);
}

template<typename item_T>
void VectorMap<item_T>::AddMap(const item_1D_t *source,
        const item_1D_t *target) {
    map_t *map = new map_t;
    for (size_type i = 0; i < source->size(); i++) {
        (*map)[(*source)[i]] = (*target)[i];
    }
    this->data_.push_back(map);
}

template<typename item_T>
template<typename item_1D_T>
void VectorMap<item_T>::GetMap(item_1D_T &result, const size_type index,
        const item_1D_T &source) {
    map_t *map = this->data_[index];
    for (size_type i = 0; i < source.size(); i++) {
        result.push_back(algebra::GetMap(map, source[i]));
    }
}

} // namespace isomorphism

class Isomorphism {
    typedef isomorphism::VectorMap<vertex_t> vmap_t;
public:
    Isomorphism(const Vertex2D *iso_2D)
            : iso_(iso_2D) {
        vmap_t vmap;
        this->BuildIsomorphicMap(vmap);
        this->BuildIsomorphicOrder(vmap);
    }
    ~Isomorphism() {
        delete this->iso_;
    }

    void BaseOrder(std::vector<size_type> &, const vertex_1D_t &,
            size_type) const;
    void IsomorphicOrder(Vertex2D &, const vertex_1D_t &) const;
    const typename Vertex2D::vector_2D_t &OrderUnique() const {
        // return all orders that are not isomorphic
        return this->order_unique_.Data();
    }
    const typename Vertex2D::vector_2D_t &OrderRemain() const {
        // every order is identical to one order in order_unique_ under iso
        return this->order_remain_.Data();
    }
    inline size_type Size() const {
        return this->iso_->Size();
    }

private:
    void BuildIsomorphicMap(vmap_t &) const;
    /*
     * if a single isomorphic mapping, then all permutations are unique
     *
     * if two isomorphic mappings, then all permutations can be divided into
     * two groups, the order in one group will have an isomorphic order in the
     * other group that yield the same graph
     */
    void BuildIsomorphicOrder(vmap_t &);

    // owner of *iso_
    const Vertex2D *iso_;
    Vertex2D order_unique_;
    Vertex2D order_remain_;
};

} // namespace branchbound

#endif /* ALGEBRA_OPTIMIZER_BRANCHBOUND_ISOMORPHISM_HPP_ */
