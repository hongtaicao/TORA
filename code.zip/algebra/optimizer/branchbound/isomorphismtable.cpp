/*
 * isomorphismtable.cpp
 *
 *  Created on: 2020-8-21 17:25
 *      Author: Hongtai Cao
 */

#include "algebra/optimizer/branchbound/isomorphismentry.hpp"
#include "algebra/optimizer/branchbound/isomorphismtable.hpp"
#include "algebra/optimizer/branchbound/type.hpp"
#include "algebra/utility/access.hpp"

namespace branchbound {

bool IsomorphismTable::InsertAssignID(PartialGraph *graph) {
    // return true if a new ID assigned
    if (this->feature_table_.count(graph->SizeV()) == 0) {
        this->feature_table_[graph->SizeV()] = new table_k_t;
    }
    table_k_t *table_k = this->feature_table_[graph->SizeV()];
    if (table_k->count(graph->SizeUnK()) == 0) {
        table_k->emplace(graph->SizeUnK(), new table_b_t);
    }
    table_b_t *table_b = table_k->at(graph->SizeUnK());
    if (table_b->count(graph->SizeB()) == 0) {
        table_b->emplace(graph->SizeB(), new table_u_t);
    }
    table_u_t *table_u = table_b->at(graph->SizeB());
    if (table_u->count(graph->SizeU()) == 0) {
        table_u->emplace(graph->SizeU(), new id_1D_t);
    }
    id_1D_t *candidate = table_u->at(graph->SizeU());
    size_type base_id = 0;
    Vertex2D *iso = new Vertex2D; // owner unknown
    for (const auto &id : (*candidate)) {
        const PartialGraph *base_graph = this->iso_table_[id]->Graph();
        if (graph->Isomorphic(base_graph, iso)) {
            if (graph->Identical(base_graph, iso)) {
                // graph already in the table
                graph->ID(id);
                delete iso; // no owner
                return false;
            }
            // graph not in the table, but isomorphic to an existing one
            base_id = id;
            break;
        }
    }
    // new graph inserted
    // iso owner is IsomorphismEntry.Isomorphism
    graph->ID(this->NextID());
    if (iso->Size() == 0) {
        // update iso if not found
        graph->Isomorphic(graph, iso);
    }
    if (base_id == 0) {
        // new graph and not isomorphic to any existing
        base_id = graph->ID();
        // update feature_table_
        candidate->push_back(base_id);
        // update iso_table_
        this->iso_table_[base_id] = new IsomorphismEntry(graph, base_id, iso);
    } else {
        // isomorphic to an existing one
        // update iso_table_ only
        this->iso_table_[graph->ID()] = new IsomorphismEntry(graph, base_id,
                iso);
    }
    return true;
}

void IsomorphismTable::Clear() {
    // this table does not own PartialGraph *
    // do not delete PartialGraph *
    for (auto &pair_v : this->feature_table_) {
        for (auto &pair_k : (*pair_v.second)) {
            for (auto &pair_b : (*pair_k.second)) {
                // delete table_u content
                algebra::DeleteMapValue(*pair_b.second); // delete id_1D_t
                delete pair_b.second; // delete table_u
            }
            delete pair_k.second; // delete table_b
        }
        delete pair_v.second; // delete table_k
    }
    this->feature_table_.clear();
    // delete IsomorphismEntry *
    algebra::DeleteMapValue(this->iso_table_);
    this->iso_table_.clear();
}

} // namespace branchbound
