/*
 * type.hpp
 *
 *  Created on: 2020-8-19 3:11
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_OPTIMIZER_BRANCHBOUND_TYPE_HPP_
#define ALGEBRA_OPTIMIZER_BRANCHBOUND_TYPE_HPP_

#include "algebra/basetype.hpp"
#include "algebra/graph/graph.hpp"
#include "algebra/utility/vector2d.hpp"

namespace branchbound {

#define FULL_ORDER 1

enum DECOMPOSITION_ALGORITHM {
    DEC_BALANCE,
    DEC_MOVE,
};

typedef algebra::query_size_t vertex_t;
typedef algebra::Graph<algebra::query_size_t> graph_t;
typedef algebra::size_type size_type;
typedef algebra::Vector2D<vertex_t> Vertex2D;
typedef typename graph_t::vertex_1D_t vertex_1D_t;
typedef typename graph_t::edgemap_t edgemap_t;
typedef typename graph_t::set_t set_t;

} // namespace branchbound

#endif /* ALGEBRA_OPTIMIZER_BRANCHBOUND_TYPE_HPP_ */
