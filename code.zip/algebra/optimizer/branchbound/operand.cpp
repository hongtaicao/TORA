/*
 * operand.cpp
 *
 *  Created on: 2020-8-19 18:00
 *      Author: Hongtai Cao
 */

#include <algorithm>
#include <deque>
#include <iostream>
#include <ostream>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "algebra/algorithm/tritree.hpp"
#include "algebra/basetype.hpp"
#include "algebra/expression/basenode.hpp"
#include "algebra/expression/initialize.hpp"
#include "algebra/optimizer/branchbound/operand.hpp"
#include "algebra/optimizer/branchbound/type.hpp"
#include "algebra/utility/access.hpp"
#include "algebra/utility/tostring.hpp"

namespace branchbound {

// define static variables
// http://www.cplusplus.com/forum/beginner/121530/
double Operand::B;
double Operand::N;
double Operand::U;
double Operand::UT;
double Operand::V;

void SetDataParameter(const std::string &data_file) {
    // update metric target
    typedef algebra::edgestore_t edgestore_t;
    edgestore_t bidirection, unidirection, ut;
    typename algebra::complement_t complement;
    typename algebra::storagebuilder_t builder;
    algebra::BuildBNUUT(data_file, &builder, &bidirection, &complement);
    builder.CreateU(&unidirection);
    builder.CreateUT(&ut);
#ifndef NDEBUG
    std::cout << "operand::SetDataParameter(): edge size ";
    operand::WriteParameter(std::cout, bidirection.RowSize(),
            complement.RowSize(), unidirection.RowSize(), ut.RowSize(),
            complement.LoopSize());
    std::cout << std::endl;
#endif
    // average neighbor for each edge type
    operand::SetParameter(Operand::B, bidirection);
    operand::SetParameter(Operand::N, complement);
    operand::SetParameter(Operand::U, unidirection);
    operand::SetParameter(Operand::UT, ut);
    // number of vertex
    Operand::V = complement.LoopSize();
    std::cout << "operand::SetDataParameter(): actual parameter ";
    operand::WriteParameter(std::cout, Operand::B, Operand::N, Operand::U,
            Operand::UT, Operand::V);
    std::cout << std::endl;
}

double Operand::CostIsomorphic(const Operand *source) const {
    // reorder cost using source
    // if identical: then cost is 0, otherwise, cost is the size of operand
    // check isomorphic orders as well, not only surface order
    const Operand *large = this, *small = source;
    if (large->entry_->ISO()->OrderUnique().size()
            < small->entry_->ISO()->OrderUnique().size()) {
        // swap them and only index one base order of the smaller
        std::swap(small, large);
    }
    typedef typename algebra::TriTree<size_type> tritree_t;
    tritree_t tritree;
    typename tritree_t::sequence_t base_order;
    large->entry_->ISO()->BaseOrder(base_order, *large->match_order_, 0);
    tritree.Index(base_order);
    for (size_type index = 0; index < small->entry_->ISO()->Size(); index++) {
        // verify all isomorphic mapping
        typename tritree_t::sequence_t base_order;
        small->entry_->ISO()->BaseOrder(base_order, *small->match_order_,
                index);
        if (tritree.Index(base_order) > 1) {
            // find identical order
            return 0;
        }
    }
    // need to transpose, cost is OperandSize
    return this->TransposeCost();
}

double Operand::EstimateCost() {
    // the minimum join cost
    // compute attribute size
    const PartialGraph *graph = this->entry_->Graph();
    for (size_type i = 0; i < this->match_order_->size(); i++) {
        vertex_t a = algebra::Get(this->match_order_, i);
        double attr_size = Operand::V;
        // determine the minimum size using all previous edge connection
        for (size_type j = 0; j < i; j++) {
            vertex_t b = algebra::Get(this->match_order_, j);
            attr_size = operand::ExpectMatchSize(attr_size,
                    operand::Multiplicity(a, b, graph));
        }
        this->table_[a] = attr_size;
    }
    // operand cost is self join cost
    return Operand::JoinCostFullOrder(*this->match_order_, *this, *this);
}

size_type Operand::FindAttribute(const vertex_t attribute) const {
    for (size_type i = 0; i < this->match_order_->size(); i++) {
        if (algebra::Get(this->match_order_, i) == attribute) {
            return i;
        }
    }
    return this->match_order_->size();
}

double Operand::JoinCost(const Operand *result, const Operand *left,
        const Operand *right) {
    if (FULL_ORDER) {
        vertex_1D_t join_order;
        operand::ParallelJoinOrder(join_order, *left->match_order_,
                *right->match_order_);
        if (operand::IsPrefix(join_order, *left->match_order_)) {
            return Operand::JoinCostFullOrder(*result->match_order_, *right,
                    *left);
        } else {
            return Operand::JoinCostFullOrder(*result->match_order_, *left,
                    *right);
        }
    } else {
        return Operand::JoinCostIsomorphic(*left, *right);
    }
}

double Operand::JoinCostFullOrder(const vertex_1D_t &result,
        const Operand &left, const Operand &prefix) {
    // supported join: join_order is prefix of one operand
    // join cost under surface order only
    double cost = 0, match_size = 1;
    typedef std::deque<vertex_t> deque_t;
    deque_t join_order;
    operand::ParallelJoinOrder(join_order, *left.match_order_,
            *prefix.match_order_);
    deque_t l_attr(left.match_order_->begin(), left.match_order_->end());
    deque_t p_attr(prefix.match_order_->begin(), prefix.match_order_->end());
    for (size_type i = 0; i < result.size(); i++) {
        vertex_t attr = result[i];
        if ((not join_order.empty()) and (join_order.front() == attr)) {
            // join attribute
            double l_size = left.AttributeSize(attr);
            double r_size = prefix.AttributeSize(attr);
            cost += (match_size * std::min(l_size, r_size));
            match_size *= operand::ExpectMatchSize(l_size, r_size);
            join_order.pop_front();
            l_attr.pop_front();
            p_attr.pop_front();
        } else {
            // non-join attribute
            if ((not l_attr.empty()) and (l_attr.front() == attr)) {
                // scan left
                match_size *= left.AttributeSize(attr);
                cost += match_size;
                l_attr.pop_front();
            } else {
                // this must be scan prefix
                match_size *= prefix.AttributeSize(attr);
                cost += match_size;
                p_attr.pop_front();
            }
        }
    }
    return cost;
}

double Operand::JoinCostIsomorphic(const Operand &, const Operand &) {
    // return min cost under all isomorphic order
    /*
     * TODO
     * 1. create operand using isomorphic order
     * 2. filter valid order
     * 3. call Operand::JoinCostFullOrder() and get min of all orders
     * Drawback
     * the found order are not reflected by the operands
     * this a back approach
     */
    std::cout << "Operand::JoinCostIsomorphic() NotImplemented" << std::endl;
    throw;
}

bool Operand::PrefixOrderFullOrder(const vertex_1D_t &result,
        const vertex_1D_t *left, const vertex_1D_t *prefix) {
    /*
     * 1. prefix of one operand must be the join attribute
     * 2. the join order is the same order as result
     * 3. non join attribute should be able to form result order
     */
    typedef std::deque<vertex_t> deque_t;
    deque_t join_order;
    if (not operand::ParallelJoinOrder(join_order, *left, *prefix)) {
        return false;
    }
    if (operand::IsPrefix(join_order, *left)) {
        std::swap(left, prefix);
    } else if (not operand::IsPrefix(join_order, *prefix)) {
        // not a prefix
        return false;
    }
    // check join order match result
    deque_t l_attr(left->begin(), left->end());
    deque_t p_attr(prefix->begin(), prefix->end());
    for (size_type i = 0; i < result.size(); i++) {
        vertex_t attr = result[i];
        if ((not join_order.empty()) and (join_order.front() == attr)) {
            // join attribute
            if ((l_attr.empty()) or (l_attr.front() != attr)) {
                return false;
            }
            if ((l_attr.empty()) or (p_attr.front() != attr)) {
                return false;
            }
            join_order.pop_front();
            l_attr.pop_front();
            p_attr.pop_front();
        } else {
            // non-join attribute
            // scan left first until it is empty
            if (not l_attr.empty()) {
                if (l_attr.front() == attr) {
                    l_attr.pop_front();
                } else {
                    // left is not empty, then scan left is required
                    return false;
                }
            } else if ((not p_attr.empty()) and (p_attr.front() == attr)) {
                // scan prefix when left is emtpy
                p_attr.pop_front();
            } else {
                // must equal either front
                return false;
            }
        }
    }
    return true;
}

bool Operand::PrefixOrderIsomorphic(const Operand &result, const Operand &small,
        const Operand &large) {
    // supported join attributes should be prefix in one operand
    // check all group of Isomorphic order
    Vertex2D small_iso, large_iso, result_iso;
    small.entry_->ISO()->IsomorphicOrder(small_iso, *small.match_order_);
    large.entry_->ISO()->IsomorphicOrder(large_iso, *large.match_order_);
    result.entry_->ISO()->IsomorphicOrder(result_iso, *result.match_order_);
    for (const auto &outer : result_iso.Data()) {
        for (const auto &middle : small_iso.Data()) {
            for (const auto &inner : large_iso.Data()) {
                if (Operand::PrefixOrderFullOrder(*outer, middle, inner)) {
                    return true;
                }
            }
        }
    }
    return false;
}

double Operand::ScanCost(double &attribute_size, size_type index) const {
    double cost = 0;
    while (index < this->match_order_->size()) {
        attribute_size *= this->AttributeSize(this->match_order_->at(index));
        cost += attribute_size;
        index++;
    }
    return cost;
}

void Operand::Write(std::ostream &out) const {
    // write self useful information as text segment
    // name(graph:attribute_order):cost
    // write name: id->base_id
    out << this->Graph()->ID() << "->" << this->entry_->BaseID() << "(";
    // write graph: graph_vertex\unknown_pair
    this->Graph()->Write(out);
    // write remaining: attribute_order):cost
    out << ":" << algebra::OrderedToString(*this->match_order_) << "):"
            << this->cost_;
}

namespace operand {

void AddToPool(std::vector<size_type> &numerator,
        std::vector<size_type> &denominator, size_type t, size_type c) {
    if (c > t) {
        numerator.push_back(0);
    } else if (c * 2 > t) {
        AddToPool(numerator, denominator, t, t - c);
    } else {
        for (size_type i = 0; i < c; i++) {
            numerator.push_back(t - i);
        }
        while (c > 1) {
            denominator.push_back(c);
            c--;
        }
    }
}

double CombinationProbability(size_type c1, size_type t1, size_type c2,
        size_type t2, size_type c3, size_type t3) {
    // compute choosefrom(c1,t1) * choosefrom(c2,t2) / choosefrom(c3,t3)
    std::vector<size_type> numerator, denominator;
    AddToPool(numerator, denominator, t1, c1);
    AddToPool(numerator, denominator, t2, c2);
    AddToPool(denominator, numerator, t3, c3);
    std::sort(numerator.begin(), numerator.end());
    std::sort(denominator.begin(), denominator.end());
    long double prob = 1;
    while ((not numerator.empty()) and (not denominator.empty())) {
        prob *= ((long double) numerator.back()
                / (long double) denominator.back());
        numerator.pop_back();
        denominator.pop_back();
    }
    while (not numerator.empty()) {
        prob *= numerator.back();
        numerator.pop_back();
    }
    while (not denominator.empty()) {
        prob /= denominator.back();
        denominator.pop_back();
    }
    return prob;
}

double ExpectMatchSize2(double a, double b) {
    // select a vertex from pool, select b vertex from pool
    // expect match vertex number
    double small = a, large = b;
    if (small > large) {
        small = b;
        large = a;
    }
    size_type remain = (size_type) Operand::V - large;
    if (remain < 1) {
        return small;
    }
    size_type match = 1;
    if (small > remain) {
        match = std::max(match, (size_type) small - remain);
    }
    double expectation = 0;
    for (; match <= small; match++) {
        double p = CombinationProbability(match, large, small - match, remain,
                small, Operand::V);
        expectation += (match * p);
    }
    return expectation;
}

inline double Multiplicity(const vertex_t a, const vertex_t b,
        const PartialGraph *graph) {
    if (graph->HasEdge(a, b)) {
        if (graph->HasEdge(b, a)) {
            return Operand::B;
        }
        return Operand::U;
    } else if (graph->HasEdge(b, a)) {
        return Operand::UT;
    } else if (graph->HasUnknown(a, b)) {
        return Operand::V;
    }
    return Operand::N;
}

inline void WriteParameter(std::ostream &out, const double b, const double n,
        const double u, const double ut, const size_type v) {
    std::streamsize ss = out.precision(15);
    out << "B=" << b << " n=" << n << " u=" << u << " ut=" << ut << " v=" << v;
    out.precision(ss);
}

} // namespace operand

} // namespace branchbound
