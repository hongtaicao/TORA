/*
 * branchbound.hpp
 *
 *  Created on: 2020-10-13 12:52
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_OPTIMIZER_BRANCHBOUND_BRANCHBOUND_HPP_
#define ALGEBRA_OPTIMIZER_BRANCHBOUND_BRANCHBOUND_HPP_

#include "algebra/argparser.hpp"

namespace branchbound {

double main(algebra::ArgParser &); // return time cost
// the above function makes use of the following functions
// return expressing parsing time cost
double EstimateExpression(algebra::ArgParser &);
/*
 * return expressing parsing time cost
 * second argument is the data reading time cost
 */
double OptimizeExpression(algebra::ArgParser &, double);

}

#endif /* ALGEBRA_OPTIMIZER_BRANCHBOUND_BRANCHBOUND_HPP_ */
