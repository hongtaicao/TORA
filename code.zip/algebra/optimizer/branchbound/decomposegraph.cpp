/*
 * decomposegraph.cpp
 *
 *  Created on: 2020-8-25 2:04
 *      Author: Hongtai Cao
 */

#include <iostream>
#include <string>
#include <unordered_set>
#include <vector>

#include "algebra/basetype.hpp"
#include "algebra/io/writer.hpp"
#include "algebra/optimizer/branchbound/decomposegraph.hpp"
#include "algebra/optimizer/branchbound/decompositiontable.hpp"
#include "algebra/optimizer/branchbound/expression.hpp"
#include "algebra/optimizer/branchbound/isomorphismentry.hpp"
#include "algebra/optimizer/branchbound/operand.hpp"
#include "algebra/optimizer/branchbound/partialgraph.hpp"
#include "algebra/optimizer/branchbound/type.hpp"
#include "algebra/utility/misc.hpp"

namespace branchbound {

void DecomposeGraph::BuildExpression() {
    // pool is in a valid state with some in-complete expression
    const algebra::timepoint_t &start = algebra::GetTimepoint();
    Expression *top_e = nullptr;
    while (not this->pool_.empty()) {
        PRINT("DecomposeGraph.BuildExpression() pool size=");
        PRINTLINE(this->pool_.size());
        size_type pool_size = this->pool_.size();
        top_e = this->Top();
        if (top_e->IsComplete()) {
            // the top of pool is a completed expression
            // this is the solution
            break;
        }
        operand_1D_t operand_1D, pending;
        top_e->PopTopIsomorphic(operand_1D);
        top_e->PopAll(pending);
        if (this->argparser_.AblationShare()) {
            while (operand_1D.size() > 1) {
                pending.push_back(operand_1D.back());
                operand_1D.pop_back();
            }
        }
        if (operand_1D.size() > 1) {
            this->BuildShared(top_e, operand_1D, pending);
        } else {
            this->BuildSingle(top_e, operand_1D, pending);
        }
        if (this->pool_.size() < pool_size) {
            // top_e is dropped, can't be a parent of any Expression
            this->expression_set_.insert(top_e);
            // some pending are Expression.input_, which are parent of top_e
            this->operand_set_.insert(pending.begin(), pending.end());
            this->profile_.fail_branch_++;
        }
        this->profile_.total_branch_++;
    }
    this->completed_.push_back(top_e);
    while (not this->pool_.empty()) {
        if (this->pool_.top()->IsComplete()
                and this->pool_.top()->Cost() == top_e->Cost()) {
            this->completed_.push_back(this->pool_.top());
            this->pool_.pop();
        } else {
            break;
        }
    }
    // profile
    this->profile_.best_count_ = this->completed_.size();
    this->profile_.best_cost_ = top_e->Cost();
    this->profile_.decompose_build_time_ = algebra::GetTimeCost(start);
    this->profile_.remain_pool_size_ = this->pool_.size();
    if (this->pool_.empty()) {
        this->profile_.margin_ = 0;
    } else {
        this->profile_.margin_ = this->pool_.top()->Cost()
                - this->profile_.best_cost_;
    }
    PRINTLINE("DecomposeGraph.BuildExpression() done.");
}

void DecomposeGraph::BuildShared(Expression *top_e,
        const operand_1D_t &operand_1D, const operand_1D_t &pending) {
    decomposegraph::ufs_group_t group;
    Expression *shared_parent = decomposegraph::BuildShared(top_e, operand_1D,
            group);
    // chain all group head
    for (const auto &i_pair : group) {
        // choose one group head
        Operand *input_op = i_pair.second;
        Expression *exp = shared_parent;
        for (auto &o_pair : group) {
            if (i_pair.first == o_pair.first) {
                // skip self group. already chained
                continue;
            }
            // chain head of different group
            exp = new Expression(exp, o_pair.second, input_op);
            PRINT("DecomposeGraph::BuildShared(): output(label,operand)=(");
            PRINT(o_pair.first << "," << o_pair.second << ")");
            PRINT("input(label,operand)=(" << i_pair.first << ",");
            PRINTLINE(i_pair.second << ") ");
        }
        exp->PushAll(pending);
        this->pool_.push(exp);
    }
}

void DecomposeGraph::BuildSingle(Expression *top_e,
        const operand_1D_t &operand_1D, const operand_1D_t &pending) {
    // a single isomorphic operand case
    double loop_cost = 0;
    const algebra::timepoint_t &start = algebra::GetTimepoint();
    Operand *top_o = operand_1D[0];
    // explore all possible attribute order
    for (auto &pair : this->dec_table_.Decompose(top_o->Graph()->ID())->Data()) {
        // a possible decomposition
        const algebra::timepoint_t &loop_start = algebra::GetTimepoint();
        size_type i = (*pair)[0], j = (*pair)[1];
        const IsomorphismEntry *left_e = this->dec_table_.FindEntry(i);
        const IsomorphismEntry *right_e = this->dec_table_.FindEntry(j);
        if (not decomposegraph::PossibleDecomposition(top_o->MatchOrder(),
                left_e, right_e)) {
#ifndef NDEBUG
            std::cout << "DecomposeGraph::BuildSingle() skip Decomposition"
                    << std::endl;
            top_o->Write(std::cout);
            std::cout << std::endl;
            left_e->Graph()->Write(std::cout);
            std::cout << std::endl;
            right_e->Graph()->Write(std::cout);
            std::cout << std::endl;
#endif
            continue;
        }
        operand_1D_t left_1D, right_1D;
        decomposegraph::BuildOperand(left_1D, left_e);
        decomposegraph::BuildOperand(right_1D, right_e);
        // explore all possible attribute order
        this->BuildSingleInner(top_e, pending, top_o, left_1D, right_1D);
        loop_cost += algebra::GetTimeCost(loop_start);
    }
    this->profile_.decompose_time_ += (algebra::GetTimeCost(start) - loop_cost);
}

void DecomposeGraph::BuildSingleInner(Expression *top_e,
        const operand_1D_t &pending, Operand *top_o,
        const operand_1D_t &left_1D, const operand_1D_t &right_1D) {
    operand_1D_t left_remain, right_remain;
    std::unordered_set<Operand *> skipped_set, used_set;
    for (auto left_op : left_1D) {
        for (auto right_op : right_1D) {
            // filter out order that are equivalent under cost model
            if (Operand::SupportedOrder(top_o, left_op, right_op)) {
                left_remain.push_back(left_op);
                right_remain.push_back(right_op);
            } else {
                skipped_set.insert(left_op);
                skipped_set.insert(right_op);
                continue;
            }
        }
    }
    size_type candidate_size = left_remain.size();
    if (this->argparser_.AblationOrder()) {
        candidate_size = 1;
    }
    for (size_type i = 0; i < candidate_size; i++) {
        Operand *left_op = left_remain[i], *right_op = right_remain[i];
#ifndef NDEBUG
        std::cout << "DecomposeGraph::BuildSingleInner() supported order"
                << std::endl << "    ";
        left_op->Write(std::cout);
        std::cout << std::endl << "    ";
        right_op->Write(std::cout);
        std::cout << std::endl;
#endif
        Expression *exp = new Expression(top_e, top_o, left_op, right_op);
        used_set.insert(left_op);
        used_set.insert(right_op);
        exp->PushAll(pending);
        this->pool_.push(exp);
    }
    // clean up not used Operand *
    for (auto &item : skipped_set) {
        if (used_set.count(item) == 0) {
            delete item;
        }
    }
}

void DecomposeGraph::ClearPool() {
    // a parent Expression * is shared by its children Expression *
    // Operand * are shared among children Expression *
    // clean up completed_
    for (auto expression : this->completed_) {
        expression->CollectResource(this->expression_set_, this->operand_set_);
    }
    // clean up pool_
    while (not this->pool_.empty()) {
        Expression *expression = this->pool_.top();
        expression->CollectResource(this->expression_set_, this->operand_set_);
        // This calls the removed element's destructor.
        // destructor of a pointer does nothing
        this->pool_.pop();
    }
    // release resource
    algebra::DeleteContent(this->expression_set_);
    this->expression_set_.clear();
    algebra::DeleteContent(this->operand_set_);
    this->operand_set_.clear();
}

void DecomposeGraph::Initialize() {
    const algebra::timepoint_t &query_start = algebra::GetTimepoint();
    PartialGraph *graph = new PartialGraph(this->argparser_.Query());
    this->profile_.query_time_ = algebra::GetTimeCost(query_start);
    // insert final result into pool
    // build operand by adding attribute order
    const algebra::timepoint_t &init_start = algebra::GetTimepoint();
    this->ClearPool();
    const IsomorphismEntry *entry = this->dec_table_.InsertFindEntryDelete(
            graph);
    // this build order for operands using non-isomorphic orders only
    for (auto &order : entry->ISO()->OrderUnique()) {
        this->pool_.push(new Expression(new Operand(order, entry)));
    }
    this->profile_.initialize_time_ = algebra::GetTimeCost(init_start);
    this->profile_.initial_pool_size_ = this->pool_.size();
    PRINT("DecomposeGraph::InitializePool(): Initial Pool Size=");
    PRINTLINE(this->pool_.size());
}

namespace decomposegraph {

void BuildOperand(operand_1D_t &operand_1D,
        const IsomorphismEntry * const entry) {
    // this build order for operands using non-isomorphic orders
    for (auto &order : entry->ISO()->OrderUnique()) {
        operand_1D.push_back(new Operand(order, entry));
    }
    if (FULL_ORDER) {
        // this add remaining surface order
        for (auto &order : entry->ISO()->OrderRemain()) {
            operand_1D.push_back(new Operand(order, entry));
        }
    }
}

Expression *BuildShared(Expression *exp, const operand_1D_t &operand_1D,
        ufs_group_t &group) {
    // process shared expression
    /*
     * divide isomorphic operands into groups based on the transpose cost
     * 0 cost operands are in the same group
     * choose an operand from each group as the source
     */
    ufs_t ufs;
    for (auto &operand : operand_1D) {
        ufs.Add(operand);
    }
    // put all operand into groups whose transpose cost is 0
    for (size_type index = 1; index < operand_1D.size(); index++) {
        for (size_type base = 0; base < index; base++) {
            if (operand_1D[index]->Cost(operand_1D[base]) == 0) {
                ufs.Union(operand_1D[index], operand_1D[base]);
                break;
            }
        }
    }
    // choose one source from each group
    ufs.GetUnionItem(group);
    PRINT("decomposegraph::BuildShared(): shared size=");
    PRINTLINE(operand_1D.size() << " group size=" << group.size());
    // chain each group first using group head
    for (auto &operand : operand_1D) {
        ufs_t::label_t label = ufs.Find(operand);
        if (operand != group[label]) {
            // skip chain self
            exp = new Expression(exp, operand, group[label]);
            PRINT("decomposegraph::BuildShared(): non-head operand=");
            PRINTLINE(operand << " label=" << label);
        }
    }
    return exp;
}

bool PrefixDecomposition(const vertex_1D_t &order, const vertex_1D_t &left,
        const vertex_1D_t &right) {
    // use join heuristic to filter supported decomposition for join
    std::vector<vertex_t> join_order;
    operand::ParallelJoinOrder(join_order, left, right);
    set_t join_set(join_order.begin(), join_order.end());
    size_type head = 0, tail = 0;
    for (size_type i = 0; i < order.size(); i++) {
        if (join_set.count(order[i])) {
            if (join_set.count(order[head]) == 0) {
                head = i;
            }
            tail = i;
        }
    }
    if (order.size() - tail - 1
            < std::min(left.size(), right.size()) - join_set.size()) {
        // join_order is a prefix for one of them
        // can't join if trailing size < prefix operand remaining
        return false;
    }
    return true;
}

bool PossibleDecomposition(const vertex_1D_t &order,
        const IsomorphismEntry * const left_e,
        const IsomorphismEntry * const right_e) {
    for (auto &outer : left_e->ISO()->OrderUnique()) {
        for (auto &inner : right_e->ISO()->OrderUnique()) {
            if (PrefixDecomposition(order, *outer, *inner)) {
                // a single case is enough
                return true;
            }
            return false;
        }
    }
    return false;
}

} // namespace decomposegraph

} // namespace branchbound
