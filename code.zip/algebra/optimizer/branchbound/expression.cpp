/*
 * expression.cpp
 *
 *  Created on: 2020-8-25 18:19
 *      Author: Hongtai Cao
 */

#include <deque>
#include <iostream>
#include <ostream>
#include <string>
#include <unordered_map>
#include <utility>

#include "algebra/basetype.hpp"
#include "algebra/io/writer.hpp"
#include "algebra/optimizer/branchbound/expression.hpp"
#include "algebra/optimizer/branchbound/operand.hpp"
#include "algebra/optimizer/branchbound/type.hpp"

namespace branchbound {

void Expression::CollectResource(
        std::unordered_set<Expression *> &expression_set,
        std::unordered_set<Operand *> &operand_set) {
    for (auto &item : this->input_) {
        operand_set.insert(item);
    }
    if (this->output_ != nullptr) {
        operand_set.insert(this->output_);
    }
    while (not this->pool_.empty()) {
        operand_set.insert(this->pool_.top());
        this->pool_.pop();
    }
    expression_set.insert(this);
    if (this->parent_ != nullptr) {
        this->parent_->CollectResource(expression_set, operand_set);
    }
}

const vertex_1D_t &Expression::MatchOrder() const {
    const Expression *exp = this;
    while (exp->parent_ != nullptr) {
        exp = exp->parent_;
    }
    return exp->input_[0]->MatchOrder();
}

void Expression::PopAll(operand_1D_t &pending) {
    while (not this->pool_.empty()) {
        pending.push_back(this->pool_.top());
        this->pool_.pop();
    }
}

void Expression::PopTopIsomorphic(operand_1D_t &result) {
    // retrieve the top Operand that are isomorphic and remove from pool
    // do not retrieve building block
    Operand *top = this->pool_.top();
    result.push_back(top);
    this->pool_.pop();
    while ((not this->pool_.empty()) and top->Isomorphic(this->pool_.top())) {
        result.push_back(this->pool_.top());
        this->pool_.pop();
    }
}

void Expression::PushAll(const operand_1D_t &pending) {
    for (auto &item : pending) {
        this->PushPool(item);
    }
}

void Expression::ToSingleLine(std::string &result) const {
    // convert self into a single line expression
    /*
     * allowed operation
     * Mask
     * MaskAxisMerge
     * MaskAxisMergeAxis
     * MaskMerge
     * Merge
     */
    std::unordered_map<const Operand *, const operand_1D_t *> out2in;
    const Expression *exp = this;
    while (exp->output_ != nullptr) {
        out2in[exp->output_] = &exp->input_;
        exp = exp->parent_;
    }
    // the final result
    expression::cMaskAxisMergeAxis(result, out2in, exp->input_[0]);
}

void Expression::Write(std::ostream &out) {
    /*
     * write parent first
     * write format:
     * X
     * = Y
     * x Z
     */
    if (this->parent_ != nullptr) {
        this->parent_->Write(out);
    }
    out << "Expression::Write() total cost=" << this->Cost() << std::endl;
    if (this->output_ != nullptr) {
        this->output_->Write(out);
        out << std::endl;
    }
    if (this->input_.size() > 0) {
        out << "= ";
        this->input_[0]->Write(out);
        out << std::endl;
    }
    for (size_type i = 1; i < this->input_.size(); i++) {
        out << "x ";
        this->input_[i]->Write(out);
        out << std::endl;
    }
}

Expression::Expression(Operand *input)
        : parent_(nullptr), output_(nullptr) {
    // model final result
    this->cost_ = input->Cost(); // input estimate cost
    this->PushInput(input);
#ifndef NDEBUG
    std::cout << "Expression.Constructor(): final result" << std::endl;
    this->WriteInfo(std::cout);
    this->WriteInput(std::cout, 0);
#endif
}

Expression::Expression(Expression *parent, Operand *output, Operand *input)
        : parent_(parent), output_(output) {
    // model re-order
    /*
     * replace: output estimate cost
     * with: transpose cost + input estimate cost
     */
    this->PushInput(input);
#ifndef NDEBUG
    std::cout << "Expression.Constructor(): transpose" << std::endl;
    this->WriteOutputInput(std::cout);
    std::cout << "    output cost (transpose) +" << output->Cost(input)
            << " input cost +" << input->Cost();
#endif
    this->SetCostIncrement(output->Cost(input) + input->Cost());
    if (parent != nullptr) {
        // add parent cost
        this->cost_ += parent->Cost();
    }
    PRINTLINE(" parent cost +" << parent->Cost());
#ifndef NDEBUG
    this->WriteInfo(std::cout);
#endif
}

Expression::Expression(Expression *parent, Operand *output, Operand *left_op,
        Operand *right_op)
        : parent_(parent), output_(output) {
    // model graph join
    this->PushInput(left_op);
    this->PushInput(right_op);
#ifndef NDEBUG
    std::cout << "Expression.Constructor(): join" << std::endl;
    this->WriteOutputInput(std::cout);
    this->WriteInput(std::cout, 1);
#endif
    // cost: computation cost of a join operation
    this->cost_ = Operand::JoinCost(this->output_, left_op, right_op);
    PRINT("    join cost=" << this->cost_);
    // set up next operand to decompose and estimate the operand cost
    if ((not left_op->IsBuildingBlock()) and (left_op->Isomorphic(right_op))) {
        // special case: both are not building block and they are isomorphic
        // add min cost of either left_op or right_op
        this->cost_ += (left_op->Cost(right_op) + right_op->Cost());
        // not building block
        PRINT(" left cost (transpose) +" << left_op->Cost(right_op));
        PRINT(" right cost +" << right_op->Cost());
    } else {
        for (auto &item : this->input_) {
            // process building block
            if (not item->IsBuildingBlock()) {
                // building block does not further decompose
                // therefore it does not estimate Operand.Cost()
                this->cost_ += item->Cost();
                PRINT(" item cost +" << item->Cost());
            }
        }
    }
    this->SetCostIncrement(this->cost_);
    // cost: parent expression cost
    if (parent != nullptr) {
        this->cost_ += parent->Cost();
    }
    PRINTLINE(" parent cost +" << parent->Cost());
#ifndef NDEBUG
    this->WriteInfo(std::cout);
#endif
}

namespace expression {

void cMaskAxisAndMergeAxis(std::string &result,
        std::unordered_map<const Operand *, const operand_1D_t *> &out2in,
        const Operand *target) {
    // MaskAxis, MergeAxis, Transpose
    if (target->IsBuildingBlock()) {
        result.append(target->BuildingBlock());
        return;
    }
    const operand_1D_t *input = out2in[target];
    if (input->size() == 1) {
        // Transpose
        Operand *source = (*input)[0];
        std::deque<size_type> axis_order;
        Operand::Transpose(axis_order, source, target);
        if (axis_order.size() > 0) {
            result.append("Transpose(");
            cMaskAxisAndMergeAxis(result, out2in, source);
            result.append(",[");
            result.append(algebra::OrderedToString(axis_order));
            result.append("])");
        } else {
            cMaskAxisAndMergeAxis(result, out2in, source);
        }
    } else if (input->size() == 2) {
        // MaskAxis / MergeAxis
        Operand *left = (*input)[0], *prefix = (*input)[1];
        std::deque<vertex_t> join_order;
        operand::ParallelJoinOrder(join_order, left->MatchOrder(),
                prefix->MatchOrder());
        // determine left and prefix
        if ((left->Size() <= prefix->Size())
                and operand::IsPrefix(join_order, left->MatchOrder())) {
            std::swap(left, prefix);
        } else if (not operand::IsPrefix(join_order, prefix->MatchOrder())) {
            // not a prefix. not supported
            Throw(target, input);
        }
        // determine operation
        if (join_order.size() < prefix->Size()) {
            // Merge
            result.append("MergeAxis(");
        } else {
            // Mask
            result.append("MaskAxis(");
        }
        // determine axis_order. this modifies join_order
        std::deque<size_type> axis_order;
        for (size_type i = 0; i < left->Size(); i++) {
            if (join_order.empty()) {
                break;
            }
            if (left->MatchOrder()[i] == join_order.front()) {
                axis_order.push_back(i);
                join_order.pop_front();
            }
        }
        cMaskAxisAndMergeAxis(result, out2in, left);
        result.append(",[");
        result.append(algebra::OrderedToString(axis_order));
        result.append("],");
        cMaskAxisAndMergeAxis(result, out2in, prefix);
        result.append(")");
    } else {
        // not supported
        Throw(target, input);
    }
}

void cMaskAxisMergeAxis(std::string &result,
        std::unordered_map<const Operand *, const operand_1D_t *> &out2in,
        const Operand *target) {
    // MaskAxisMergeAxis when possible
    if (target->IsBuildingBlock()) {
        result.append(target->BuildingBlock());
        return;
    }
    const operand_1D_t *input = out2in[target];
    if (input->size() == 1) {
        // Transpose
        Operand *source = (*input)[0];
        std::deque<size_type> axis_order;
        Operand::Transpose(axis_order, source, target);
        if (axis_order.size() > 0) {
            result.append("Transpose(");
            cMaskAxisMergeAxis(result, out2in, source);
            result.append(",[");
            result.append(algebra::OrderedToString(axis_order));
            result.append("])");
        } else {
            cMaskAxisMergeAxis(result, out2in, source);
        }
    } else if (input->size() == 2) {
        // MaskAxis / MergeAxis
        Operand *left = (*input)[0], *prefix = (*input)[1];
        std::deque<vertex_t> join_order;
        operand::ParallelJoinOrder(join_order, left->MatchOrder(),
                prefix->MatchOrder());
        // determine left and prefix
        if ((left->Size() <= prefix->Size())
                and operand::IsPrefix(join_order, left->MatchOrder())) {
            std::swap(left, prefix);
        } else if (not operand::IsPrefix(join_order, prefix->MatchOrder())) {
            // not a prefix. not supported
            Throw(target, input);
        }
        // determine operation
        bool is_maskaxis = false;
        if (join_order.size() < prefix->Size()) {
            // Merge
            result.append("MergeAxis(");
        } else {
            // Mask
            const std::string MaskAxis = "cMaskAxis";
            if ((result.size() < MaskAxis.size())
                    or (result.substr(result.size() - MaskAxis.size())
                            != MaskAxis)) {
                // collapse neighboring MaskAxis
                result.append(MaskAxis);
                is_maskaxis = true;
            }
        }
        // determine axis_order. this modifies join_order
        std::deque<size_type> axis_order;
        for (size_type i = 0; i < left->Size(); i++) {
            if (join_order.empty()) {
                break;
            }
            if (left->MatchOrder()[i] == join_order.front()) {
                axis_order.push_back(i);
                join_order.pop_front();
            }
        }
        cMaskAxisMergeAxis(result, out2in, left);
        result.append(",[");
        result.append(algebra::OrderedToString(axis_order));
        result.append("],");
        cMaskAxisMergeAxis(result, out2in, prefix);
        if (is_maskaxis) {
            result.append(")");
        }
    } else {
        // not supported
        Throw(target, input);
    }
}

void Throw(const Operand *output, const operand_1D_t *input) {
    std::cout << "expression.Throw(): output=";
    output->Write(std::cout);
    std::cout << " input=";
    if (input->size() > 0) {
        input->at(0)->Write(std::cout);
    }
    for (size_type i = 1; i < input->size(); i++) {
        std::cout << ", ";
        input->at(i)->Write(std::cout);
    }
    std::cout << std::endl;
    throw;
}

} // namespace expression

} // namespace branchbound
