/*
 * initialize.hpp
 *
 *  Created on: 2020-4-18 8:50
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_EXPRESSION_INITIALIZE_HPP_
#define ALGEBRA_EXPRESSION_INITIALIZE_HPP_

#include <string>
#include <unordered_map>

#include "algebra/argparser.hpp"
#include "algebra/basetype.hpp"
#include "algebra/expression/basenode.hpp"
#include "algebra/storage/storagebuilder.hpp"

namespace algebra {

class Leaf;

typedef StorageBuilder<data_size_t> storagebuilder_t;
void BuildBNUUT(const std::string &, storagebuilder_t *, edgestore_t *,
        complement_t *);

// initialize using graph adjacency
int BuildPoolByBuilder(Leaf *, const ArgParser &);
int BuildPoolByStorage(Leaf *, const ArgParser &);
void BuildPoolByBuildingBlock(Leaf *, const ArgParser &);
void PrepareInitialization(const ArgParser &);

} // namespace algebra

#endif /* ALGEBRA_EXPRESSION_INITIALIZE_HPP_ */
