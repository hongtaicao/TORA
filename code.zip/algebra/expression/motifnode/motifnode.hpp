/*
 * motifnode.hpp
 *
 * graph node for motif adjacency computation
 *
 * a motif graph node takes a subgraph node as inputs
 * therefore it should not count subgraph node time cost
 *
 *  Created on: 2021-3-23 11:49
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_EXPRESSION_MOTIFNODE_MOTIFNODE_HPP_
#define ALGEBRA_EXPRESSION_MOTIFNODE_MOTIFNODE_HPP_

#include <assert.h>
#include <deque>
#include <iostream>

#include "algebra/basetype.hpp"
#include "algebra/expression/basenode.hpp"
#include "algebra/expression/motifnode/motifparser.hpp"
#include "algebra/io/logger.hpp"
#include "algebra/io/writer.hpp"
#include "algebra/storage/convert/coordinate2d.hpp"
#include "algebra/storage/convert/table2d.hpp"
#include "algebra/storage/nestedmap/base.hpp"
#include "algebra/storage/nestedmap/nestedmap.hpp"

namespace motif_node {

typedef algebra::size_type size_type;

template<typename T>
inline void EvaluateStartInfo(const std::string &classname, const T *object,
        const size_type use_count, const std::string &expression) {
    algebra::Ignore(classname);
    algebra::Ignore(object);
    algebra::Ignore(use_count);
    algebra::Ignore(expression);
    PRINT(classname.substr(0, 10) << "Evaluate() start " << object);
    PRINTLINE(" use_count=" << use_count << " " << expression);
}

template<typename T>
inline void EvaluateDoneInfo(const std::string &classname, const T *object,
        const size_type use_count, const std::string &expression) {
    algebra::Ignore(classname);
    algebra::Ignore(object);
    algebra::Ignore(use_count);
    algebra::Ignore(expression);
    PRINT(classname.substr(0, 10) << "Evaluate() done  " << object);
    PRINT(" use_count=" << use_count << " " << expression);
}

template<typename T>
inline void SizeInfo(T &obj) {
    algebra::Ignore(obj);
    PRINTLINE(" size=(" << obj.RowSize() << ", " << obj.ColumnSize()<< ")");
}

} // namespace motif_node

namespace algebra {

class InputNode: public BaseNode {
    typedef convert::Table2D<data_size_t> table_t;

public:
    InputNode(const std::string &expression, BaseNode *basenode,
            const ADJACENCY_FORMAT f)
            : BaseNode(expression), format(f) {
        this->basenode_ = basenode;
        this->subgraph_ = nullptr;
    }

    inline storage_t *Evaluate() override {
        // cannot call BaseNode::Evaluate() because this->cache_ is nullptr
#ifndef NDEBUG
        motif_node::EvaluateStartInfo("InputNode:", this, this->UseCount(),
                this->Expression());
#endif
        if (this->subgraph_ == nullptr) {
            this->EvaluateInput();
        }
        if (this->format == ADJ_TABLE) {
            if (this->subgraph_2D_.RowSize() == 0) {
                this->subgraph_->To_2D(this->subgraph_2D_);
            }
        }
#ifndef NDEBUG
        motif_node::EvaluateDoneInfo("InputNode:", this, this->UseCount(),
                this->Expression());
        if (this->format == ADJ_TABLE) {
            motif_node::SizeInfo(this->subgraph_2D_);
        } else {
            motif_node::SizeInfo(*this->subgraph_);
        }
#endif
        return this->subgraph_;
    }
    inline void EvaluateDone() override {
        /*
         * postpone input->EvaluateDone() before this->EvaluateDone()
         * because of sharing
         */
        this->basenode_->EvaluateDone();
        BaseNode::EvaluateDone();
    }
    // subgraph cost
    inline storage_t *EvaluateInput() {
        // should not call EvaluateDone on basenode_ because results are used
        if (this->subgraph_ == nullptr) {
            this->subgraph_ = this->basenode_->Evaluate();
        }
        return this->subgraph_;
    }
    inline void Print(size_type leading_space) override {
        BaseNode::Print(leading_space);
        this->basenode_->Print(leading_space + 2);
    }
    inline storage_t *Storage() {
        return this->subgraph_;
    }
    inline table_t &Table() {
        return this->subgraph_2D_;
    }
    inline size_type VertexSize() const override {
        return this->basenode_->VertexSize();
    }

    const ADJACENCY_FORMAT format;

protected:
    virtual inline storage_t *Compute() override final {
        // use nullptr to avoid double delete on storage_t *basenode_->cache_
        return nullptr;
    }
    virtual BaseNode *NodeInner(size_type vertex_size) override {
        return this->basenode_->Node(vertex_size);
    }

private:
    BaseNode *basenode_; // not owned
    // subgraph result in different format
    storage_t *subgraph_; // not owned
    table_t subgraph_2D_;
};

class MotifBaseNode: public BaseNode {
    // a class defines interface functions
    // computation is to change the storage format
public:
    typedef data_size_t item_T;
    typedef convert::Coordinate2D<item_T> matrix_t;
    typedef convert::Table2D<item_T> table_t;

    MotifBaseNode(const std::string &expression, InputNode *input_node)
            : BaseNode(expression), input_node_(input_node) {
        this->pool_.push_back(this);
    }

    static size_type InstanceCount() {
        // used by ReportCost
        return MotifBaseNode::pool_.size();
    }

    virtual inline storage_t *Evaluate() override {
        return this->input_node_->Evaluate();
    }
    inline void EvaluateStartInfo(const std::string &classname) const {
        motif_node::EvaluateStartInfo(classname, this, this->UseCount(),
                this->Expression());
    }
    virtual inline void EvaluateDone() override {
        /*
         * postpone input->EvaluateDone() before this->EvaluateDone()
         * because of sharing
         */
        this->input_node_->EvaluateDone();
        BaseNode::EvaluateDone();
    }
    inline void EvaluateDoneInfo(const std::string &classname) const {
        motif_node::EvaluateDoneInfo(classname, this, this->UseCount(),
                this->Expression());
        PRINT(" adjacency_2D.KeySize()=" << this->adjacency_2D_.KeySize());
        PRINTLINE(" Sum()=" << this->adjacency_2D_.Sum());
    }

    inline void EvaluateInput() {
        this->input_node_->EvaluateInput();
    }
    inline const matrix_t &Matrix() const {
        return this->adjacency_2D_;
    }

    inline bool Match(MotifBaseNode *other) {
        return this->Matrix().Equal(other->Matrix());
    }
    virtual void Print(size_type leading_space) override {
        BaseNode::Print(leading_space);
        this->input_node_->Print(leading_space + 2);
    }
    void ReportCost(Logger *) const;
    inline size_type Sum() const {
        return this->adjacency_2D_.Sum();
    }
    virtual size_type VertexSize() const override {
        return this->input_node_->VertexSize();
    }

protected:
    virtual inline storage_t *Compute() override final {
        // use nullptr to avoid double delete on storage_t *cache_
        return nullptr;
    }
    virtual BaseNode *NodeInner(size_type vertex_size) override {
        return this->input_node_->Node(vertex_size);
    }

    // state
    std::unordered_map<std::string, double> cost_info_;

    InputNode *input_node_; // not owned
    matrix_t adjacency_2D_; // final result matrix

private:
    static std::deque<MotifBaseNode *> pool_; // not owned
};

class MotifNode: public MotifBaseNode {
    // a wrapper of SumNode
    // no actual computation
public:
    MotifNode(const std::string &expression, InputNode *input_node,
            BaseNode *adjacency_node)
            : MotifBaseNode(expression, input_node) {
        assert(input_node->format == ADJ_FOREST);
        this->adjacency_node_ = adjacency_node;
    }

    inline storage_t *Evaluate() override {
        MotifBaseNode::Evaluate();
        return this->adjacency_node_->Evaluate();
    }
    inline void EvaluateDone() override {
        // input->EvaluateDone() is called inside
        this->adjacency_node_->EvaluateDone();
        // should not Call MotifBaseNode::EvaluateDone()
        BaseNode::EvaluateDone();
    }
    void EvaluateAdjacency() {
        storage_t *adjacency = this->adjacency_node_->Evaluate();
        MotifBaseNode::table_t adjacency_2D;
        adjacency->To_2D(adjacency_2D);
        adjacency_2D.ToCoordinate2D(this->adjacency_2D_);
    }
    virtual void Print(size_type leading_space) override {
        BaseNode::Print(leading_space);
        this->adjacency_node_->Print(leading_space + 2);
    }

private:
    BaseNode *adjacency_node_;
};

class BaselineNode: public MotifBaseNode {
public:
    BaselineNode(const std::string &expression, InputNode *input_node)
            : MotifBaseNode(expression, input_node) {
        assert(input_node->format == ADJ_TABLE);
    }

    storage_t *Evaluate() override;
};

class ReduceUniqueNode: public MotifBaseNode {
public:
    typedef MotifBaseNode::item_T item_T;
    typedef _STORAGE_::Base<MotifBaseNode::item_T> storage_base_t;
    typedef _STORAGE_::NestedMapUniform<MotifBaseNode::item_T> unique_t;

    ReduceUniqueNode(const std::string &expression, InputNode *input_node)
            : MotifBaseNode(expression, input_node) {
        assert(input_node->format == ADJ_FOREST);
    }

    storage_t *Evaluate() override;
};

class ScaleReduceNode: public MotifBaseNode {
public:
    ScaleReduceNode(const std::string &expression, InputNode *input_node)
            : MotifBaseNode(expression, input_node) {
        // parse adjacency expression using Storage
        // apply expression to a different storage format
        assert(input_node->format == ADJ_TABLE);
        this->parser_.CreateNode(expression);
    }

    storage_t *Evaluate() override;

private:
    motif_node::MotifParser parser_;
};

} // namespace algebra

namespace motif_node {

typedef algebra::ReduceUniqueNode::storage_base_t storage_base_t;
typedef algebra::ReduceUniqueNode::item_T item_T;
typedef algebra::ReduceUniqueNode::MotifBaseNode::matrix_t matrix_t;
typedef std::deque<item_T> path_t;

void reduce(matrix_t &, storage_base_t *, path_t &);
void unique(storage_base_t *, storage_base_t *, path_t &);

} // namespace motif_node

#endif /* ALGEBRA_EXPRESSION_MOTIFNODE_MOTIFNODE_HPP_ */
