/*
 * motifnode.cpp
 *
 *  Created on: 2021-3-24 3:17
 *      Author: Hongtai Cao
 */

#include <algorithm>
#include <deque>
#include <iostream>
#include <string>

#include "algebra/algorithm/motifadjacency.hpp"
#include "algebra/basetype.hpp"
#include "algebra/io/logger.hpp"
#include "algebra/expression/motifnode/motifnode.hpp"
#include "algebra/storage/nestedmap/base.hpp"
#include "algebra/utility/misc.hpp"

namespace algebra {

std::deque<MotifBaseNode *> MotifBaseNode::pool_;

void MotifBaseNode::ReportCost(Logger *logger) const {
    // ensure all instance write the same number of cost_info_
    size_type cost_count = 0;
    for (size_type i = 0; i < MotifBaseNode::InstanceCount(); i++) {
        cost_count = std::max(cost_count,
                MotifBaseNode::pool_[i]->cost_info_.size());
    }
    // sort key and assign id
    std::deque<std::string> keylist;
    SortMapKey(this->cost_info_, keylist);
    for (size_type i = 0; i < cost_count; i++) {
        std::string key = "_" + std::to_string(i);
        if (i < keylist.size()) {
            key = keylist[i] + key;
            if (i > 0) {
                std::cout << " ";
            }
            if (logger != nullptr) {
                logger->AddResult(key,
                        std::to_string(this->cost_info_.at(key)));
            }
            std::cout << key << "=" << this->cost_info_.at(key);
        } else if (logger != nullptr) {
            // no std::cout but should add empty result
            logger->AddResult(key, "");
        }
    }
}

inline storage_t *BaselineNode::Evaluate() {
    this->EvaluateStartInfo("BLineNode::");
    MotifBaseNode::Evaluate();
    if (this->cost_info_.size() == 0) {
        // sort
        this->cost_info_["cost_BaselineNode_sort"] = baseline::SortSubgraph(
                this->input_node_->Table());
        // build
        this->cost_info_["cost_BaselineNode_build"] =
                baseline::ComputeAdjacency(this->adjacency_2D_,
                        this->input_node_->Table());
    }
    this->EvaluateDoneInfo("BLineNode::");
    return nullptr;
}

storage_t *ScaleReduceNode::Evaluate() {
    this->EvaluateStartInfo("ScReNode::");
    MotifBaseNode::Evaluate();
    for (const auto &op : this->parser_.ScaleReduce1D()) {
        MotifBaseNode::matrix_t partial_2D;
        // sum
        for (size_type index = 0; index < this->input_node_->Table().RowSize();
                index++) {
            const auto graph = this->input_node_->Table().Get(index);
            partial_2D.Add(graph->at(op.axis[0]), graph->at(op.axis[1]));
        }
        // scale
        this->adjacency_2D_.Add(partial_2D, op.Scalar());
    }
    this->EvaluateDoneInfo("ScReNode::");
    return nullptr;
}

storage_t *ReduceUniqueNode::Evaluate() {
    this->EvaluateStartInfo("ReUnNode::");
    storage_base_t *result = (storage_base_t *) MotifBaseNode::Evaluate();
    unique_t u_result;
    std::deque<item_T> path;
    const algebra::timepoint_t &start_unique = algebra::GetTimepoint();
    motif_node::unique(&u_result, result, path);
    this->cost_info_["cost_ReduceUniqueNode_unique"] = algebra::GetTimeCost(
            start_unique);
    const algebra::timepoint_t &start_reduce = algebra::GetTimepoint();
    motif_node::reduce(this->adjacency_2D_, &u_result, path);
    this->cost_info_["cost_ReduceUniqueNode_reduce"] = algebra::GetTimeCost(
            start_reduce);
    this->EvaluateDoneInfo("ReUnNode::");
    PRINT("                           unique");
    motif_node::SizeInfo(u_result);
    return nullptr;
}

} // namespace algebra

namespace motif_node {

void reduce(matrix_t &adjacency_2D, storage_base_t *u_result, path_t &path) {
    for (storage_base_t::iterator_t *pair = u_result->CreateIterator();
            nestedmap::InRange(pair); pair->Advance()) {
        if (pair->Value() == nullptr) {
            while (nestedmap::InRange(pair)) {
                path.push_back(pair->Key());
                for (size_type row = 0; row < path.size(); row++) {
                    item_T coo1 = path[row];
                    for (size_type col = row + 1; col < path.size(); col++) {
                        adjacency_2D.Add(coo1, path[col]);
                        adjacency_2D.Add(path[col], coo1);
                    }
                }
                path.pop_back();
                pair->Advance();
            }
            return;
        } else {
            path.push_back(pair->Key());
            reduce(adjacency_2D, pair->Value(), path);
            path.pop_back();
        }
    }
}

void unique(storage_base_t *u_result, storage_base_t *result, path_t &path) {
    for (storage_base_t::iterator_t *pair = result->CreateIterator();
            nestedmap::InRange(pair); pair->Advance()) {
        if (pair->Value() == nullptr) {
            while (nestedmap::InRange(pair)) {
                path_t copy(path.begin(), path.end());
                copy.push_back(pair->Key());
                std::sort(copy.begin(), copy.end());
                u_result->PushBack(copy);
                pair->Advance();
            }
            return;
        } else {
            path.push_back(pair->Key());
            unique(u_result, pair->Value(), path);
            path.pop_back();
        }
    }
}

} // namespace notif_node
