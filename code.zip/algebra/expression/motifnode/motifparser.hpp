/*
 * motifparser.hpp
 *
 * parse motif adjacency expression partially for scale and reduce only
 *
 *  Created on: 2021-3-23 17:32
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_EXPRESSION_MOTIFNODE_MOTIFPARSER_HPP_
#define ALGEBRA_EXPRESSION_MOTIFNODE_MOTIFPARSER_HPP_

#include <string>
#include <vector>

#include "algebra/basetype.hpp"
#include "algebra/expression/basenode.hpp"
#include "algebra/expression/parser.hpp"

namespace motif_node {

class ScaleReduce {
    typedef algebra::Parser<algebra::BaseNode *>::axis_t axis_t;
public:
    ScaleReduce(const axis_t &axis)
            : axis(axis.begin(), axis.end()), scalar_(1.0) {
    }
    inline void Scalar(const algebra::scalar_t scalar) {
        this->scalar_ = scalar;
    }
    inline algebra::scalar_t Scalar() const {
        return this->scalar_;
    }

    const axis_t axis;

private:
    algebra::scalar_t scalar_;
};

class MotifParser: public algebra::Parser<algebra::BaseNode *> {
    typedef algebra::BaseNode * node_T;
    typedef Parser<node_T>::axis_t axis_t;
    typedef Parser<node_T>::axis_1D_t axis_1D_t;
    typedef Parser<node_T>::axis_2D_t axis_2D_t;
    typedef Parser<node_T>::node_1D_t node_1D_t;
    typedef Parser<node_T>::node_2D_t node_2D_t;

    typedef std::vector<algebra::scalar_t> scalar_1D_t;
    typedef std::vector<axis_t> reduce_1D_t;
    typedef std::vector<ScaleReduce> scale_reduce_1D_t;

public:
    MotifParser()
            : Parser<algebra::BaseNode *>(), index_(0) {
        this->IgnoreOperator("ADJ_FOREST");
        this->IgnoreOperator("ADJ_TABLE");
        this->IgnoreOperator("SCALE_REDUCE");
        this->IgnoreOperator("REDUCE_UNIQUE");
    }

    const scale_reduce_1D_t &ScaleReduce1D() const {
        return this->scale_reduce_;
    }

protected:
    void AddCache(const std::string &, node_T) override {
    }
    bool HasCache(const std::string &) override {
        return false;
    }
    node_T GetCache(const std::string &) override {
        return nullptr;
    }

    virtual node_T CreateLeaf(const std::string &) override {
        return nullptr;
    }
    virtual node_T CreateLeafFilter(const std::string &, const std::string &,
            const std::string &, const std::string &) override {
        return nullptr;
    }

    inline node_T CreateAxisNode(const std::string &,
            const algebra::OPERATOR_NAME operation, node_T, axis_t *axis)
                    override {
        assert(axis != nullptr);
        if (algebra::ConfigName(operation) == "REDUCE_OP") {
            this->scale_reduce_.push_back(ScaleReduce(*axis));
        }
        this->Delete(axis);
        return nullptr;
    }
    inline node_T CreateBinaryNode(const std::string &,
            const algebra::OPERATOR_NAME, node_T, node_T) override {
        return nullptr;
    }
    inline node_T CreateMaskMergeNode(const std::string &, node_T, node_T,
            node_T) override {
        return nullptr;
    }
    inline node_T CreateMaskAxisMergeNode(const std::string &, node_T, node_T,
            axis_1D_t *axis_1D, node_1D_t *node_1D) override {
        this->Delete(axis_1D);
        this->Delete(node_1D);
        return nullptr;
    }
    inline node_T CreateMaskAxisMergeAxisNode(const std::string &, node_T,
            axis_t *axis, node_T, axis_1D_t *axis_1D, node_1D_t *node_1D)
                    override {
        this->Delete(axis);
        this->Delete(axis_1D);
        this->Delete(node_1D);
        return nullptr;
    }
    inline node_T CreatecMaskAxisMergeAxisNode(const std::string &, node_T,
            axis_t *axis, node_T, axis_1D_t *axis_1D, node_1D_t *node_1D)
                    override {
        this->Delete(axis);
        this->Delete(axis_1D);
        this->Delete(node_1D);
        return nullptr;
    }
    inline node_T CreateMask_Merge__by(const std::string &, node_T, node_T,
            node_1D_t *node_1D, const std::string &) override {

        this->Delete(node_1D);
        return nullptr;
    }
    inline node_T CreatePipelineNode(const std::string &, node_T,
            axis_1D_t *axis_1D, node_1D_t *node_1D, axis_2D_t *mask_axis_2D,
            node_2D_t *mask_node_2D) override {
        this->Delete(axis_1D);
        this->Delete(node_1D);
        this->Delete(mask_axis_2D);
        this->Delete(mask_node_2D);
        return nullptr;
    }
    inline node_T CreateScaleNode(const std::string &, node_T,
            algebra::scalar_t scalar) override {
        this->scale_reduce_.back().Scalar(scalar);
        return nullptr;
    }
    inline node_T CreateSumNode(const std::string &, node_1D_t *node_1D)
            override {
        this->Delete(node_1D);
        return nullptr;
    }

private:
    inline void Delete(axis_t *axis) {
        delete axis;
    }
    inline void Delete(axis_1D_t *axis_1D) {
        algebra::DeleteContent(*axis_1D);
        delete axis_1D;
    }
    inline void Delete(axis_2D_t *axis_2D) {
        for (auto axis_1D : (*axis_2D)) {
            algebra::DeleteContent(*axis_1D);
            delete axis_1D;
        }
        delete axis_2D;
    }
    inline void Delete(node_1D_t *node_1D) {
        algebra::DeleteContent(*node_1D);
        delete node_1D;
    }
    inline void Delete(node_2D_t *node_2D) {
        for (auto node_1D : (*node_2D)) {
            algebra::DeleteContent(*node_1D);
            delete node_1D;
        }
        delete node_2D;
    }

    algebra::size_type index_;
    scale_reduce_1D_t scale_reduce_;
};

} // namespace motif_node

#endif /* ALGEBRA_EXPRESSION_MOTIFNODE_MOTIFPARSER_HPP_ */
