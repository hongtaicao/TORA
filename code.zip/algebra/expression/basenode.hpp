/*
 * basenode.hpp
 *
 * responsible for result caching and sharing
 *
 *  Created on: 2020-1-4 16:39:07
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_EXPRESSION_BASENODE_HPP_
#define ALGEBRA_EXPRESSION_BASENODE_HPP_

#include <assert.h>
#include <string>

#include "algebra/basetype.hpp"
#include "algebra/io/writer.hpp"
#include "algebra/storage/nestedmap/nestedmap.hpp"
#include "algebra/storage/nestedmap/nestedmap_complement.hpp"
#include "algebra/storage/relation/pointer_complement.hpp"
#include "algebra/storage/relation/pointer_relation.hpp"
#include "algebra/storage/storage.hpp"

namespace algebra {

// type implementation
typedef _STORAGE_::Adjacency<data_size_t> adjacency_t;
typedef _STORAGE_::EdgeStore<data_size_t> edgestore_t;
typedef _STORAGE_::Complement<data_size_t> complement_t;
typedef _STORAGE_::StorageSum<data_size_t> storagesum_t;
typedef _STORAGE_::Storage<data_size_t> storage_t;

class BaseNode {
public:
    typedef algebra::T_1D<BaseNode *> basenode_1D_t;
    // https://stackoverflow.com/a/4467690/11193802
    /* Make sure the members appear in the initializer list in the same order
     * as they appear in the class
     */
    BaseNode(const std::string &expression)
            : cache_(nullptr), cache_owner_(true), expression_(expression) {
        this->use_count_ = 1;
        PRINTLINE("BaseNode() " << this << " " << this->expression_);
    }
    // Delete BaseNode * using ComputationGraph.key2index_
    virtual ~BaseNode() {
        PRINT("~BaseNode() " << this << " cache=" << this->cache_);
        PRINT(" use_count=" << this->use_count_ << " cache_owner=");
        PRINTLINE(BOOL_STRING(this->cache_owner_) << " " << this->expression_);
        if (this->cache_owner_) {
            assert((this->cache_ == nullptr) or (this->use_count_ == 0));
#ifdef LATE_DELETE
            delete this->cache_;
#endif
        }
    }

    BaseNode(const BaseNode &) = delete;
    BaseNode &operator=(const BaseNode &) = delete;

    inline void AssignCache(storage_t *cache, bool cache_owner) {
        // depending on how cache is assigned. this might not be the owner
        this->cache_ = cache;
        this->cache_owner_ = cache_owner;
    }
    // can only Evaluate() the same node or its parents
    // children can be deleted therefore call this method is undefined
    virtual inline storage_t *Evaluate() {
        // or condition in #if
        // https://stackoverflow.com/a/55016661/11193802
        PRINT("BaseNode::Evaluate() start " << this << " cache=");
        PRINT(this->cache_ << " use_count=" << this->use_count_ << " ");
        PRINTLINE(this->expression_);
        if (this->cache_ == nullptr) {
            this->cache_ = this->Compute();
        }
        PRINT("BaseNode::Evaluate() done  " << this << " cache=");
        PRINT(this->cache_ << " use_count=" << this->use_count_ << " ");
        PRINT(this->expression_ << " size=(" << this->cache_->RowSize());
        PRINTLINE(", " << this->cache_->ColumnSize() << ")");
        return this->cache_;
    }
    // should be called explicitly for the top most Evaluate() node
    virtual inline void EvaluateDone() {
        PRINT("BaseNode::EvaluateDone() " << this << " cache=");
        PRINT(this->cache_ << " use_count=" << this->use_count_ << " ");
        PRINTLINE(this->expression_);
        assert(this->use_count_ > 0);
        this->use_count_--;
#ifndef LATE_DELETE
        // resource can be released here because it is fully used
        // delete at this point increase runtime but lower space cost
        if (this->use_count_ == 0) {
            if (this->cache_owner_) {
                // result is not needed any more
                delete this->cache_;
                this->cache_ = nullptr;
            }
        }
#endif
    }
    inline const std::string &Expression() const {
        return this->expression_;
    }
    inline void Expression(const std::string &expression) {
        this->expression_ = expression;
    }
    /*
     * return the last BaseNode of the given size
     * if given size is larger, then return self
     */
    BaseNode *Node(size_type vertex_size) {
        if (vertex_size >= this->VertexSize()) {
            return this;
        }
        return this->NodeInner(vertex_size);
    }
    virtual BaseNode *NodeInner(size_type) = 0;
    // it is allow to implement pure virtual method, but uncommon
    // make Print not a pure virtual method
    // https://stackoverflow.com/a/2089176/11193802
    virtual void Print(size_type);
    inline BaseNode *ShallowCopy() {
        // BaseNode fully materialize the underlying internal data
        // no need to ShallowCopy underlying data
        this->use_count_++;
        return this;
    }
    virtual size_type VertexSize() const = 0;

protected:
    /*
     * this is only for subclass use only
     * the same node cannot compute more than once
     * can delete intermediate result when possible
     */
    virtual storage_t *Compute() = 0;
    inline size_type UseCount() const {
        return this->use_count_;
    }

private:
    /*
     * cache_ and use_count_ work together to control the storage_t deletion
     * every result of storage_t * is on heap and should be deleted later
     * cache_ captures every storage_t *
     * Evaluate() capture result into cache_
     * DeleteEvaluate() capture cache_ deletion
     */
    storage_t *cache_;
    bool cache_owner_;
    std::string expression_;
    size_type use_count_;
};

} // namespace algebra

#endif /* ALGEBRA_EXPRESSION_BASENODE_HPP_ */
