/*
 * creator.hpp
 *
 *  Created on: 2020-10-12 12:51
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_EXPRESSION_CREATOR_HPP_
#define ALGEBRA_EXPRESSION_CREATOR_HPP_

#include <string>

#include "algebra/basetype.hpp"
#include "algebra/expression/basenode.hpp"
#include "algebra/expression/node/node.hpp"
#include "algebra/expression/parser.hpp"

namespace algebra {

class Creator: public Parser<BaseNode *> {
    typedef BaseNode * node_T;
public:
    typedef Parser<node_T>::axis_t axis_t;
    typedef Parser<node_T>::axis_1D_t axis_1D_t;
    typedef Parser<node_T>::axis_2D_t axis_2D_t;
    typedef Parser<node_T>::node_1D_t node_1D_t;
    typedef Parser<node_T>::node_2D_t node_2D_t;
    virtual ~Creator() override {
    }

protected:
    virtual void AddCache(const std::string &, node_T) override = 0;
    virtual bool HasCache(const std::string &) override = 0;
    virtual node_T GetCache(const std::string &) override = 0;

    virtual node_T CreateLeaf(const std::string &) override = 0;
    virtual node_T CreateLeafFilter(const std::string &, const std::string &,
            const std::string &, const std::string &) override = 0;

    inline node_T CreateAxisNode(const std::string &expression,
            const OPERATOR_NAME operation, node_T node, axis_t *axis) override {
        return new AxisNode(expression, operation, node, axis);
    }
    inline node_T CreateBinaryNode(const std::string &expression,
            const OPERATOR_NAME operation, node_T left, node_T right) override {
        return new BinaryNode(expression, operation, left, right);
    }
    inline node_T CreateMaskMergeNode(const std::string &expression, node_T left,
            node_T right, node_T mask) override {
        return new MaskMergeNode(expression, left, right, mask);
    }
    inline node_T CreateMaskAxisMergeNode(const std::string &expression,
            node_T left, node_T right, axis_1D_t *axis_1D, node_1D_t *mask_1D)
                    override {
        return new MaskAxisMergeNode(expression, left, right, axis_1D, mask_1D);
    }
    inline node_T CreateMaskAxisMergeAxisNode(const std::string &expression,
            node_T left, axis_t *merge_axis, node_T right, axis_1D_t *axis_1D,
            node_1D_t *node_1D) override {
        return new MaskAxisMergeAxisNode(expression, left, merge_axis, right,
                axis_1D, node_1D);
    }
    inline node_T CreatecMaskAxisMergeAxisNode(const std::string &expression,
            node_T left, axis_t *merge_axis, node_T right, axis_1D_t *axis_1D,
            node_1D_t *node_1D) override {
        return new cMaskAxisMergeAxisNode(expression, left, merge_axis, right,
                axis_1D, node_1D);
    }
    inline node_T CreateMask_Merge__by(const std::string &expression,
            node_T left, node_T right, node_1D_t *node_1D,
            const std::string &key) override {
        return new Mask_Merge__by(expression, left, right, node_1D, key);
    }
    inline node_T CreatePipelineNode(const std::string &expression, node_T left,
            axis_1D_t *merge_axis_1D, node_1D_t *merge_node_1D,
            axis_2D_t *mask_axis_2D, node_2D_t *mask_node_2D) override {
        return new PipelineNode(expression, left, merge_axis_1D, merge_node_1D,
                mask_axis_2D, mask_node_2D);
    }
    inline node_T CreateScaleNode(const std::string &expression, node_T node,
            scalar_t scalar) override {
        return new ScaleNode(expression, node, scalar);
    }
    inline node_T CreateSumNode(const std::string &expression,
            node_1D_t *node_1D) override {
        return new SumNode(expression, node_1D);
    }
};

} // namespace algebra

#endif /* ALGEBRA_EXPRESSION_CREATOR_HPP_ */
