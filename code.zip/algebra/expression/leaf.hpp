/*
 * leaf.hpp
 *
 *  Created on: 2020-9-11 20:38
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_EXPRESSION_LEAF_HPP_
#define ALGEBRA_EXPRESSION_LEAF_HPP_

#include <assert.h>
#include <iostream>
#include <string>
#include <unordered_map>
#include <unordered_set>

#include "algebra/basetype.hpp"
#include "algebra/expression/basenode.hpp"
#include "algebra/io/writer.hpp"
#include "algebra/utility/access.hpp"
#include "algebra/utility/tostring.hpp"

namespace algebra {

class Leaf {
    /*
     * this is the owner for building block without arguments, not BaseNode
     * BaseNode is the owner for building blocks with arguments
     */
public:
    typedef _STORAGE_::Base<data_size_t> storage_t;
    typedef std::unordered_map<std::string, storage_t *> pool_t;
    typedef std::unordered_map<std::string, Leaf *> data_t;
    typedef std::vector<size_type> degree_t;

    Leaf()
            : is_built_(false), node_(nullptr) {
    }
    ~Leaf() {
        PRINT("~Leaf() " << this << " is_built_=");
        PRINT(BOOL_STRING(this->is_built_) << " pool size=");
        PRINT(this->pool_.size() << " degree=[");
        PRINTLINE(OrderedToString(this->degree_) << "]");
        algebra::DeleteMapValue(this->data_);
        algebra::DeleteMapValue(this->pool_);
    }

    inline void Add(const std::string &key, BaseNode *node) {
        assert((key == "A") or (Leaf::LEAF_SET.count(key) > 0));
        assert((this->data_.count(key) == 0) or (not this->data_[key]->node_));
        this->AddLeaf(key)->node_ = node;
    }
    inline void Add(const std::string &key, BaseNode *node,
            const std::string &head_degree_distribution,
            const std::string &tail_degree_distribution) {
        assert(Leaf::LEAF_SET.count(key) > 0);
        Leaf *leaf = this->AddLeaf(key);
        leaf = leaf->AddLeaf(head_degree_distribution);
        leaf->AddLeaf(tail_degree_distribution)->node_ = node;
    }
    int Build(const ArgParser &);
    inline bool Has(const std::string &key) const {
        return this->data_.count(key) != 0;
    }
    inline void AddPool(const std::string &key, storage_t *storage) {
        // own all leaf without argument
        this->pool_[key] = storage;
    }

    static const std::unordered_set<std::string> LEAF_SET;

private:
    // a function pointer
    using FunctionPointer = bool (*)(storage_t *, storage_t *,
            storage_t *, data_size_t, const degree_t &);

    inline Leaf *AddLeaf(const std::string &key) {
        if (this->data_.count(key) == 0) {
            this->data_[key] = new Leaf;
        }
        return this->data_[key];
    }
    void ApplyFilter(); // complete all leaf evaluate using pool
    void BuildPoolByEvaluate(); // build pool using adjacency
    int BuildByDirect(const ArgParser &); // build pool by read file
    FunctionPointer FilterFunction(const degree_t &);
    inline storage_t *GetFilter(const std::string &key) {
        if (this->InPool(key)) {
            return this->pool_[key];
        }
        return nullptr;
    }
    inline bool InPool(const std::string &key) const {
        return this->pool_.count(key) != 0;
    }
    void ParseFilter(); // add leaf to pool based on degree filter need

    bool is_built_;
    BaseNode *node_; // owned by expression, here is for AssignCache()
    // owner content of following
    data_t data_;
    degree_t degree_;
    pool_t pool_;
};

namespace leaf {

inline void AddU(Leaf::data_t &, const Leaf::degree_t &);
inline void AddUT(Leaf::data_t &, const Leaf::degree_t &);
void BuildDegree(const std::string &, bool, Leaf::data_t &, Leaf::degree_t &,
        const std::string &);
inline void DebugFilterFunction(const Leaf::degree_t &, const std::string &);
inline bool IsFiltered(Leaf::storage_t *, data_size_t, size_type);
inline bool IsFiltered_(Leaf::storage_t *, Leaf::storage_t *, Leaf::storage_t *,
        data_size_t, const Leaf::degree_t &);
inline bool IsFilteredB(Leaf::storage_t *, Leaf::storage_t *, Leaf::storage_t *,
        data_size_t, const Leaf::degree_t &);
inline bool IsFilteredBU(Leaf::storage_t *, Leaf::storage_t *,
        Leaf::storage_t *, data_size_t, const Leaf::degree_t &);
inline bool IsFilteredBUT(Leaf::storage_t *, Leaf::storage_t *,
        Leaf::storage_t *, data_size_t, const std::vector<size_type> &);
inline bool IsFilteredBUUT(Leaf::storage_t *, Leaf::storage_t *,
        Leaf::storage_t *, data_size_t, const Leaf::degree_t &);
inline bool IsFilteredU(Leaf::storage_t *, Leaf::storage_t *, Leaf::storage_t *,
        data_size_t, const Leaf::degree_t &);
inline bool IsFilteredUT(Leaf::storage_t *, Leaf::storage_t *,
        Leaf::storage_t *, data_size_t, const Leaf::degree_t &);
inline bool IsFilteredUUT(Leaf::storage_t *, Leaf::storage_t *,
        Leaf::storage_t *, data_size_t, const Leaf::degree_t &);
bool NotDummyDegree(Leaf::degree_t &, size_type);
inline void DebugNotDummyDegreeAfter(const Leaf::degree_t &);
inline void DebugNotDummyDegreeBefore(const Leaf::degree_t &, size_type);

} // namespace leaf

} // namespace algebra

#endif /* ALGEBRA_EXPRESSION_LEAF_HPP_ */
