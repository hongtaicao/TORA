/*
 * parser.hpp
 *
 *  Created on: 2020-10-12 14:03
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_EXPRESSION_PARSER_HPP_
#define ALGEBRA_EXPRESSION_PARSER_HPP_

#include <assert.h>
#include <regex>
#include <stdlib.h>
#include <string>
#include <unordered_set>
#include <vector>

#include "algebra/basetype.hpp"
#include "algebra/expression/leaf.hpp"
#include "algebra/io/writer.hpp"

namespace algebra {

template<typename node_T>
class Parser {
public:
    typedef T_1D<query_size_t> axis_t;
    typedef T_1D<axis_t *> axis_1D_t;
    typedef T_1D<axis_1D_t *> axis_2D_t;
    typedef T_1D<node_T> node_1D_t;
    typedef T_1D<node_1D_t *> node_2D_t;

    Parser() {
    }
    virtual ~Parser() {
    }
    node_T CreateNode(const std::string &);
    inline node_T Parse(const std::string &expression) {
        // replace special character
        return this->CreateNode(
                std::regex_replace(expression, std::regex("[\\t\\n\\r\\s]"),
                        ""));
    }

    // match Mask%d_%d__%d_%dMerge%d_%d__%dby%d compile_level=2
    static const std::regex P_MAAMEA_C2;

protected:
    inline void IgnoreOperator(const std::string &op) {
        this->ignore_.insert(op);
    }

    virtual void AddCache(const std::string &, node_T) = 0;
    virtual bool HasCache(const std::string &) = 0;
    virtual node_T GetCache(const std::string &) = 0;
    virtual node_T CreateAxisNode(const std::string &, const OPERATOR_NAME,
            node_T, axis_t *) = 0;
    virtual node_T CreateBinaryNode(const std::string &, const OPERATOR_NAME,
            node_T, node_T) = 0;
    virtual node_T CreateLeaf(const std::string &) = 0;
    virtual node_T CreateLeafFilter(const std::string &, const std::string &,
            const std::string &, const std::string &) = 0;
    virtual node_T CreateMaskMergeNode(const std::string &, node_T, node_T,
            node_T) = 0;
    virtual node_T CreateMaskAxisMergeNode(const std::string &, node_T, node_T,
            axis_1D_t *, node_1D_t *) = 0;
    virtual node_T CreateMaskAxisMergeAxisNode(const std::string &, node_T,
            axis_t *, node_T, axis_1D_t *, node_1D_t *) = 0;
    virtual node_T CreatecMaskAxisMergeAxisNode(const std::string &, node_T,
            axis_t *, node_T, axis_1D_t *, node_1D_t *) = 0;
    virtual node_T CreateMask_Merge__by(const std::string &, node_T, node_T,
            node_1D_t *, const std::string &) = 0;
    virtual node_T CreatePipelineNode(const std::string &, node_T, axis_1D_t *,
            node_1D_t *, axis_2D_t *, node_2D_t *) = 0;
    virtual node_T CreateScaleNode(const std::string &, node_T, scalar_t) = 0;
    virtual node_T CreateSumNode(const std::string &, node_1D_t *) = 0;

private:
    void ParseMaskAxis(axis_1D_t *, node_1D_t *, const std::string &, size_type,
            size_type);

    std::unordered_set<std::string> ignore_;
};

template<typename node_T>
const std::regex Parser<node_T>::P_MAAMEA_C2(
        "^Mask(?:\\d+_\\d+)?(?:__\\d+_\\d+)*Merge\\d+(?:_\\d+)*__\\d+by\\d+$");

template<typename node_T>
node_T Parser<node_T>::CreateNode(const std::string &expression) {
    if (this->HasCache(expression)) {
        return this->GetCache(expression);
    }
    std::string::size_type find_operator = expression.find("(");
    if (find_operator == std::string::npos) {
        // a leaf without argument
        return this->CreateLeaf(expression);
    }
    // a leaf with arguments or an operation
    node_T node = nullptr;
    std::string op = expression.substr(0, find_operator);
    // process sub-expr
    size_type start = find_operator + 1;
    size_type stop = expression.size() - 1;
    size_type comma_1 = GetPairedBracketEnd(expression, start, stop);
    std::string arg_1 = GetSubstr(expression, start, comma_1);
    assert((arg_1.size() > 0));
    comma_1++;
    size_type comma_2 = GetPairedBracketEnd(expression, comma_1, stop);
    std::string arg_2 = GetSubstr(expression, comma_1, comma_2);
    PRINT("Parser::CreateNode() " << op << ": " << arg_1 << " " << arg_2);
    // process each Node
    if (this->ignore_.count(op) > 0) {
        PRINTLINE("");
        return this->CreateNode(arg_1);
    } else if (Leaf::LEAF_SET.count(op) > 0) {
        PRINTLINE("");
        return this->CreateLeafFilter(expression, op, arg_1, arg_2);
    } else if (op == "Mask") {
        PRINTLINE("");
        node = this->CreateBinaryNode(expression, MASK_OP,
                this->CreateNode(arg_1), this->CreateNode(arg_2));
    } else if (op == "MaskMerge") {
        comma_2++;
        std::string mask = GetSubstr(expression, comma_2, stop);
        PRINTLINE(" " << mask);
        node = this->CreateMaskMergeNode(expression, this->CreateNode(arg_1),
                this->CreateNode(arg_2), this->CreateNode(mask));
    } else if (op == "MaskAxisMerge") {
        // parse
        PRINTLINE("");
        axis_1D_t *axis_1D = new axis_1D_t;
        node_1D_t *node_1D = new node_1D_t;
        this->ParseMaskAxis(axis_1D, node_1D, expression, comma_2 + 1, stop);
        node = this->CreateMaskAxisMergeNode(expression,
                this->CreateNode(arg_1), this->CreateNode(arg_2), axis_1D,
                node_1D);
    } else if ((op == "MaskAxisMergeAxis") or (op == "cMaskAxisMergeAxis")) {
        // parse
        // MaskAxisMergeAxis(left,right,merge_axis[,mask,mask_axis])
        start = comma_2 + 1;
        comma_1 = GetPairedBracketEnd(expression, start, stop);
        std::string right = GetSubstr(expression, start, comma_1);
        PRINT(" " << right);
        axis_1D_t *axis_1D = new axis_1D_t;
        node_1D_t *node_1D = new node_1D_t;
        // createNode()
        this->ParseMaskAxis(axis_1D, node_1D, expression, comma_1 + 1, stop);
        axis_t *axis = new axis_t;
        ParseAxis(axis, arg_2);
        if (op == "MaskAxisMergeAxis") {
            node = this->CreateMaskAxisMergeAxisNode(expression,
                    this->CreateNode(arg_1), axis, this->CreateNode(right),
                    axis_1D, node_1D);
        } else {
            node = this->CreatecMaskAxisMergeAxisNode(expression,
                    this->CreateNode(arg_1), axis, this->CreateNode(right),
                    axis_1D, node_1D);
        }
    } else if (std::regex_match(op, P_MAAMEA_C2)) {
        PRINTLINE("");
        node_1D_t *mask_1D = new node_1D_t;
        for (start = comma_2 + 1; start < stop; start = comma_2 + 1) {
            comma_2 = GetPairedBracketEnd(expression, start, stop);
            mask_1D->push_back(
                    this->CreateNode(GetSubstr(expression, start, comma_2)));
        }
        node = this->CreateMask_Merge__by(expression, this->CreateNode(arg_1),
                this->CreateNode(arg_2), mask_1D, op);
    } else if (op == "Merge") {
        PRINTLINE("");
        node = this->CreateBinaryNode(expression, MERGE_OP,
                this->CreateNode(arg_1), this->CreateNode(arg_2));
    } else if (op == "Pipeline") {
        PRINTLINE("");
        axis_1D_t *merge_axis_1D = new axis_1D_t;
        node_1D_t *merge_node_1D = new node_1D_t;
        axis_2D_t *mask_axis_2D = new axis_2D_t;
        node_2D_t *mask_node_2D = new node_2D_t;
        if (arg_2.size() > 0) {
            size_type comma_2, comma_3;
            for (size_type level = 1; comma_1 < stop; level++) {
                // merge_axis
                comma_2 = GetPairedBracketEnd(expression, comma_1, stop);
                axis_t *axis = new axis_t;
                ParseAxis(axis, GetSubstr(expression, comma_1, comma_2));
                merge_axis_1D->push_back(axis);
                // merge_node
                comma_2++;
                comma_3 = GetPairedBracketEnd(expression, comma_2, stop);
                merge_node_1D->push_back(
                        this->CreateNode(
                                GetSubstr(expression, comma_2, comma_3)));
                // mask_axis and mask_node
                axis_1D_t *mask_axis_1D = new axis_1D_t;
                node_1D_t *mask_node_1D = new node_1D_t;
                for (size_type i = 0; i < level; i++) {
                    comma_2 = comma_3 + 1;
                    comma_3 = GetPairedBracketEnd(expression, comma_2, stop);
                    axis_t *axis = new axis_t;
                    ParseAxis(axis, GetSubstr(expression, comma_2, comma_3));
                    mask_axis_1D->push_back(axis);
                    comma_2 = comma_3 + 1;
                    comma_3 = GetPairedBracketEnd(expression, comma_2, stop);
                    mask_node_1D->push_back(
                            this->CreateNode(
                                    GetSubstr(expression, comma_2, comma_3)));
                }
                comma_1 = comma_3 + 1;
                mask_axis_2D->push_back(mask_axis_1D);
                mask_node_2D->push_back(mask_node_1D);
            }
        }
        node = this->CreatePipelineNode(expression, this->CreateNode(arg_1),
                merge_axis_1D, merge_node_1D, mask_axis_2D, mask_node_2D);
    } else if (op == "Reduce") {
        axis_t *axis = new axis_t;
        ParseAxis(axis, arg_2);
#ifndef NDEBUG
        std::cout << " Print1D: ";
        if (axis == nullptr) {
            std::cout << std::endl;
        } else {
            Print1D(*axis);
        }
#endif
        node = this->CreateAxisNode(expression, REDUCE_OP,
                this->CreateNode(arg_1), axis);
    } else if (op == "Scale") {
        scalar_t scalar = std::atof(arg_2.c_str());
        PRINTLINE(" scalar: " << scalar);
        node = this->CreateScaleNode(expression, this->CreateNode(arg_1),
                scalar);
    } else if (op == "Sum") {
        // parse
        std::vector<std::string> string_1D;
        string_1D.push_back(arg_1);
        // loop for the renaming
        do {
            string_1D.push_back(arg_2);
            start = comma_2 + 1;
            comma_2 = GetPairedBracketEnd(expression, start, stop);
            arg_2 = GetSubstr(expression, start, comma_2);
        } while (arg_2.size() > 0);
#ifndef NDEBUG
        // skip arg_1, arg_2
        for (size_type i = 2; i < string_1D.size(); i++) {
            std::cout << " " << string_1D[i];
        }
        std::cout << std::endl;
#endif
        // CreateNode()
        node_1D_t *node_1D = new node_1D_t;
        for (const auto &item : string_1D) {
            node_1D->push_back(this->CreateNode(item));
        }
        node = this->CreateSumNode(expression, node_1D);
    } else if (op == "Transpose") {
        axis_t *axis = new axis_t;
        ParseAxis(axis, arg_2);
#ifndef NDEBUG
        std::cout << " Print1D: ";
        if (axis == nullptr) {
            std::cout << std::endl;
        } else {
            Print1D(*axis);
        }
#endif
        node = this->CreateAxisNode(expression, TRANSPOSE_OP,
                this->CreateNode(arg_1), axis);
    } else {
        std::cout << std::endl;
        std::cout << "Construction::CreateNode(): unknown operator=" << op;
        std::cout << std::endl;
        throw;
    }
    this->AddCache(expression, node);
    return node;
}

template<typename node_T>
void Parser<node_T>::ParseMaskAxis(axis_1D_t *axis_1D, node_1D_t *node_1D,
        const std::string &expression, size_type start, size_type stop) {
    std::vector<std::string> axis_str_1D;
    std::vector<std::string> mask_str_1D;
    algebra::ParseMaskAxis(axis_str_1D, mask_str_1D, expression, start, stop);
    for (size_type i = 0; i < axis_str_1D.size(); i++) {
        axis_t *axis = new axis_t;
        ParseAxis(axis, axis_str_1D[i]);
        axis_1D->push_back(axis);
        node_1D->push_back(this->CreateNode(mask_str_1D[i]));
    }
}

} // namespace algebra

#endif /* ALGEBRA_EXPRESSION_PARSER_HPP_ */
