/*
 * node.hpp
 *
 * derived class of BaseNode
 *
 *  Created on: 2020-2-22 1:49
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_EXPRESSION_NODE_NODE_HPP_
#define ALGEBRA_EXPRESSION_NODE_NODE_HPP_

#include <algorithm>
#include <iostream>

#include "algebra/basetype.hpp"
#include "algebra/expression/basenode.hpp"
#include "algebra/storage/storage.hpp"

namespace algebra {

// expression graph node using algebra operation
// Created on: 2020-2-21 20:12
class AdjacencyNode: public BaseNode {
public:
    AdjacencyNode(const std::string &expression)
            : BaseNode(expression) {
    }

protected:
    // adjacency
    inline storage_t *Compute() override {
        // dummy operation. should never be here
        // BaseNode.cache_ should set before the first Evaluate()
        std::cout << "AdjacencyNode(): Error call Compute() on "
                << this->Expression() << std::endl;
        throw;
    }
    inline BaseNode *NodeInner(size_type) override {
        return this;
    }
    inline size_type VertexSize() const override {
        return 2;
    }
};

// expression graph node using operation based on axis
// Created on: 2020-2-21 21:22
class AxisNode: public BaseNode {
public:
    typedef typename storage_t::axis_t axis_t;
    AxisNode(const std::string &expression, OPERATOR_NAME operation,
            BaseNode *graphnode, axis_t *axis)
            : BaseNode(expression), graphnode_(graphnode), axis_(axis) {
        this->operation_ = operation;
    }
    virtual ~AxisNode() override;
    inline void Print(size_type leading_space) override {
        BaseNode::Print(leading_space);
        this->graphnode_->Print(leading_space + 2);
    }

protected:
    storage_t *Compute() override;
    inline BaseNode *NodeInner(size_type vertex_size) override {
        return this->graphnode_->Node(vertex_size);
    }
    inline size_type VertexSize() const override {
        if (this->axis_ == nullptr) {
            return this->graphnode_->VertexSize();
        }
        return this->axis_->size();
    }

private:
    OPERATOR_NAME operation_;
    BaseNode *graphnode_;
    axis_t *axis_;
};

// expression graph node using binary operation on two graph node *
// Created on: 2020-2-21 20:44
class BinaryNode: public BaseNode {
public:
    BinaryNode(const std::string &expression, OPERATOR_NAME operation,
            BaseNode *left, BaseNode *right)
            : BaseNode(expression), left_(left), right_(right) {
        this->operation_ = operation;
    }
    inline void Print(size_type leading_space) override {
        BaseNode::Print(leading_space);
        leading_space += 2;
        this->left_->Print(leading_space);
        this->right_->Print(leading_space);
    }

protected:
    // mask, merge, minus
    storage_t *Compute() override;
    inline BaseNode *NodeInner(size_type vertex_size) override {
        if (this->left_->VertexSize() >= this->right_->VertexSize()) {
            return this->left_->Node(vertex_size);
        }
        return this->right_->Node(vertex_size);
    }
    inline size_type VertexSize() const override {
        unsigned int vertex_size = std::max(this->left_->VertexSize(),
                this->right_->VertexSize());
        if (this->operation_ == algebra::MERGE_OP) {
            vertex_size += 1;
        }
        return vertex_size;
    }

private:
    OPERATOR_NAME operation_;
    BaseNode *left_;
    BaseNode *right_;
};

// expression graphnode using non-edge operation
class ComplementNode: public BaseNode {
public:
    ComplementNode(const std::string &expression, BaseNode *adj, BaseNode *ut)
            : BaseNode(expression), adj_(adj), ut_(ut) {
    }

protected:
    // nonedge
    inline storage_t *Compute() override {
        storage_t *output = new complement_t(this->adj_->Evaluate(),
                this->ut_->Evaluate());
        this->adj_->EvaluateDone();
        this->ut_->EvaluateDone();
        return output;
    }
    inline BaseNode *NodeInner(size_type) override {
        return this;
    }
    inline size_type VertexSize() const override {
        return 2;
    }

private:
    BaseNode *adj_;
    BaseNode *ut_;
};

class MaskAxisMergeNode: public BaseNode {
public:
    typedef typename storage_t::axis_1D_t axis_1D_t;
    typedef typename storage_t::axis_2D_t axis_2D_t;

    MaskAxisMergeNode(const std::string &expression, BaseNode *left,
            BaseNode *right, axis_1D_t *axis_1D, basenode_1D_t *mask_1D)
            : BaseNode(expression), left_(left), right_(right) {
        this->axis_1D_ = axis_1D;
        this->mask_1D_ = mask_1D;
    }
    virtual ~MaskAxisMergeNode() override;
    virtual inline void Print(size_type leading_space) override;

protected:
    virtual storage_t *Compute() override;
    void ComputeDone();
    void ComputeMaskAxis(storage_t::axis_2D_t &, storage_t::storage_1D_t &);
    inline void PrintLeft(size_type leading_space) {
        this->left_->Print(leading_space);
    }
    inline BaseNode *NodeInner(size_type vertex_size) override {
        if (this->left_->VertexSize() >= this->right_->VertexSize()) {
            return this->left_->Node(vertex_size);
        }
        return this->right_->Node(vertex_size);
    }
    inline void PrintRight(size_type leading_space) {
        this->right_->Print(leading_space);
    }
    void PrintMaskAxis(size_type);
    inline size_type VertexSize() const override {
        size_type left_size = this->left_->VertexSize();
        size_type right_size = this->right_->VertexSize();
        if (left_size >= right_size) {
            return left_size + 1;
        }
        return right_size + 1;
    }

    axis_1D_t *axis_1D_;
    basenode_1D_t *mask_1D_;
    BaseNode *left_;
    BaseNode *right_;
};

class MaskAxisMergeAxisNode: public MaskAxisMergeNode {
public:
    typedef typename storage_t::axis_t axis_t;
    typedef typename storage_t::axis_1D_t axis_1D_t;
    typedef typename storage_t::axis_2D_t axis_2D_t;

    MaskAxisMergeAxisNode(const std::string &expression, BaseNode *left,
            axis_t *merge_axis, BaseNode *right, axis_1D_t *axis_1D,
            basenode_1D_t *mask_1D)
            : MaskAxisMergeNode(expression, left, right, axis_1D, mask_1D) {
        this->merge_axis_ = merge_axis;
    }
    virtual ~MaskAxisMergeAxisNode() override;
    inline void Print(size_type leading_space) override;

protected:
    storage_t *Compute() override;
    inline size_type VertexSize() const override {
        return this->left_->VertexSize() + this->right_->VertexSize()
                - this->merge_axis_->size();
    }

    axis_t *merge_axis_;
};

class cMaskAxisMergeAxisNode: public MaskAxisMergeAxisNode {
    // compiled MaskAxisMergeAxis
public:
    typedef typename storage_t::axis_t axis_t;
    typedef typename storage_t::axis_1D_t axis_1D_t;
    typedef typename storage_t::axis_2D_t axis_2D_t;

    cMaskAxisMergeAxisNode(const std::string &expression, BaseNode *left,
            axis_t *merge_axis, BaseNode *right, axis_1D_t *axis_1D,
            basenode_1D_t *mask_1D)
            : MaskAxisMergeAxisNode(expression, left, merge_axis, right,
                    axis_1D, mask_1D) {
    }

protected:
    storage_t *Compute() override;
};

class Mask_Merge__by: public BaseNode {
    // compiled MaskAxisMergeAxis
public:
    Mask_Merge__by(const std::string &expression, BaseNode *left,
            BaseNode *right, basenode_1D_t *mask_1D, const std::string &key)
            : BaseNode(expression), left_(left), right_(right), mask_1D_(
                    mask_1D), key_(key) {
    }
    ~Mask_Merge__by() {
        delete this->mask_1D_;
    }
    void Print(size_type) override;

protected:
    storage_t *Compute() override;
    BaseNode *NodeInner(size_type) override;
    size_type VertexSize() const override;

private:
    void ParseKey(int *size) const {
        std::string merge__by = this->key_.substr(this->key_.find("Merge"));
        auto pos = merge__by.find("__");
        std::string axis = merge__by.substr(0, pos);
        size[2] = std::count(axis.begin(), axis.end(), '_');
        std::string by = merge__by.substr(pos + 2);
        size[0] = std::stoi(by, nullptr);
        size[1] = std::stoi(by.substr(by.find("by") + 2), nullptr);
    }

    BaseNode *left_;
    BaseNode *right_;
    basenode_1D_t *mask_1D_;
    const std::string key_;
};

class MaskMergeNode: public BaseNode {
public:
    MaskMergeNode(const std::string &expression, BaseNode *left,
            BaseNode *right, BaseNode *mask)
            : BaseNode(expression), left_(left), right_(right), mask_(mask) {
    }
    inline void Print(size_type leading_space) override {
        BaseNode::Print(leading_space);
        leading_space += 2;
        this->left_->Print(leading_space);
        this->right_->Print(leading_space);
        this->mask_->Print(leading_space);
    }

protected:
    inline storage_t *Compute() override {
        storage_t *left = this->left_->Evaluate();
        storage_t *right = this->right_->Evaluate();
        storage_t *mask = this->mask_->Evaluate();
        storage_t *output = left->MaskMerge(right, mask);
        this->left_->EvaluateDone();
        this->right_->EvaluateDone();
        this->mask_->EvaluateDone();
        return output;
    }
    inline BaseNode *NodeInner(size_type vertex_size) override {
        if (this->left_->VertexSize() >= this->right_->VertexSize()) {
            return this->left_->Node(vertex_size);
        }
        return this->right_->Node(vertex_size);
    }
    inline size_type VertexSize() const override {
        return std::max(this->left_->VertexSize(), this->right_->VertexSize())
                + 1;
    }

private:
    BaseNode *left_;
    BaseNode *right_;
    BaseNode *mask_;
};

// expression graph node using pipeline operation
class PipelineNode: public BaseNode {
public:
    typedef typename storage_t::axis_t axis_t;
    typedef typename storage_t::axis_1D_t axis_1D_t;
    typedef typename storage_t::axis_2D_t axis_2D_t;
    typedef typename BaseNode::basenode_1D_t basenode_1D_t;
    typedef T_1D<basenode_1D_t *> basenode_2D_t;

    PipelineNode(const std::string &expression, BaseNode *left,
            axis_1D_t *merge_axis_1D, basenode_1D_t *merge_node_1D,
            axis_2D_t *mask_axis_2D, basenode_2D_t *mask_node_2D)
            : BaseNode(expression), left_(left), merge_axis_1D_(merge_axis_1D),
              mask_axis_2D_(mask_axis_2D), merge_node_1D_(merge_node_1D),
              mask_node_2D_(mask_node_2D) {
    }
    ~PipelineNode() override;
    inline void Print(size_type) override;

protected:
    storage_t *Compute() override;
    BaseNode *NodeInner(size_type) override;
    size_type VertexSize() const override;

private:
    BaseNode *left_;
    axis_1D_t *merge_axis_1D_;
    axis_2D_t *mask_axis_2D_;
    basenode_1D_t *merge_node_1D_;
    basenode_2D_t *mask_node_2D_;
};

// expression graph node using scale operation
// Created on: 2020-2-21 21:33
class ScaleNode: public BaseNode {
public:
    typedef algebra::scalar_t scalar_t;

    ScaleNode(const std::string &expression, BaseNode *graphnode,
            scalar_t scalar)
            : BaseNode(expression), graphnode_(graphnode), scalar_(scalar) {
    }
    inline void Print(size_type leading_space) override {
        BaseNode::Print(leading_space);
        this->graphnode_->Print(leading_space + 2);
    }

protected:
    // scale
    inline storage_t *Compute() override {
        storage_t *result = this->graphnode_->Evaluate()->Scale(this->scalar_);
        this->graphnode_->EvaluateDone();
        return result;
    }
    inline BaseNode *NodeInner(size_type vertex_size) override {
        return this->graphnode_->Node(vertex_size);
    }
    inline size_type VertexSize() const override {
        return this->graphnode_->VertexSize();
    }

private:
    BaseNode *graphnode_;
    scalar_t scalar_;
};

// expression graph node using sum operation
// Created on: 2020-2-21 21:41
class SumNode: public BaseNode {
public:
    typedef typename BaseNode::basenode_1D_t basenode_1D_t;

    SumNode(const std::string &expression, basenode_1D_t *nodelist)
            : BaseNode(expression), nodelist_(nodelist) {
    }
    virtual ~SumNode() override;
    void Print(size_type) override;

protected:
    storage_t *Compute() override;
    BaseNode *NodeInner(size_type) override;
    size_type VertexSize() const override;

private:
    basenode_1D_t *nodelist_;
};

} // namespace algebra

#endif /* ALGEBRA_EXPRESSION_NODE_NODE_HPP_ */
