/*
 * node.cpp
 *
 *  Created on: 2020-1-8 3:53:05
 *      Author: Hongtai Cao
 */

#include <algorithm>
#include <assert.h>
#include <iostream>
#include <string>
#include <unordered_map>

#include "algebra/expression/basenode.hpp"
#include "algebra/expression/node/node.hpp"
#include "algebra/io/writer.hpp"
#include "algebra/utility/access.hpp"

namespace algebra {

void BaseNode::Print(size_type leading_space) {
    while (leading_space > 0) {
        std::cout << " ";
        leading_space--;
    }
    std::cout << this << " use_count=" << this->use_count_ << " "
            << this->expression_ << std::endl;
}

// reduce, transpose
AxisNode::~AxisNode() {
    delete this->axis_;
}

storage_t *AxisNode::Compute() {
    storage_t *operand = this->graphnode_->Evaluate();
    storage_t *output = nullptr;
    switch (this->operation_) {
    case algebra::REDUCE_OP: {
        output = operand->Reduce(this->axis_);
        break;
    }
    case algebra::TRANSPOSE_OP: {
        output = operand->Transpose(this->axis_);
        break;
    }
    default: {
        assert(false);
    }
    }
    this->graphnode_->EvaluateDone();
    return output;
}

// mask, merge, minus
storage_t *BinaryNode::Compute() {
    storage_t *left = this->left_->Evaluate();
    storage_t *right = this->right_->Evaluate();
    storage_t *output = nullptr;
    switch (this->operation_) {
    case algebra::MASK_OP: {
        output = left->Mask(right);
        break;
    }
    case algebra::MERGE_OP: {
        output = left->Merge(right);
        break;
    }
    case algebra::MINUS_OP: {
        output = left->Minus(right);
        break;
    }
    default: {
        assert(false);
    }
    }
    this->left_->EvaluateDone();
    this->right_->EvaluateDone();
    return output;
}

// MaskAxisMerge
MaskAxisMergeNode::~MaskAxisMergeNode() {
    algebra::DeleteContent(*this->axis_1D_);
    delete this->axis_1D_;
}

storage_t *MaskAxisMergeNode::Compute() {
    // build strorage_1D and axis_2D
    storage_t::axis_2D_t axis_2D;
    storage_t::storage_1D_t storage_1D;
    this->ComputeMaskAxis(axis_2D, storage_1D);
    // Evaluate
    storage_t *result = this->left_->Evaluate()->MaskAxisMerge(
            this->right_->Evaluate(), axis_2D, storage_1D);
    // EvaluateDone
    this->ComputeDone();
    return result;
}

void MaskAxisMergeNode::ComputeDone() {
    this->left_->EvaluateDone();
    this->right_->EvaluateDone();
    for (auto &item : (*this->mask_1D_)) {
        item->EvaluateDone();
    }
}

void MaskAxisMergeNode::ComputeMaskAxis(storage_t::axis_2D_t &axis_2D,
        storage_t::storage_1D_t &storage_1D) {
    std::unordered_map<std::string, storage_t::axis_1D_t *> expr2axis_1D;
    for (size_type i = 0; i < this->mask_1D_->size(); i++) {
        BaseNode *item = algebra::Get(this->mask_1D_, i);
        const std::string &expr = item->Expression();
        if (expr2axis_1D.count(expr) == 0) {
            storage_t::axis_1D_t *axis_1D = new storage_t::axis_1D_t;
            expr2axis_1D[expr] = axis_1D;
            storage_1D.push_back(item->Evaluate());
            axis_2D.push_back(axis_1D);
        }
        expr2axis_1D[expr]->push_back(algebra::Get(this->axis_1D_, i));
    }
}

void MaskAxisMergeNode::Print(size_type leading_space) {
    BaseNode::Print(leading_space);
    leading_space += 2;
    this->PrintLeft(leading_space);
    this->PrintRight(leading_space);
    this->PrintMaskAxis(leading_space);
}

void MaskAxisMergeNode::PrintMaskAxis(size_type leading_space) {
    for (size_type i = 0; i < this->mask_1D_->size(); i++) {
        algebra::PrintAxis(leading_space, *algebra::Get(this->axis_1D_, i));
        algebra::Get(this->mask_1D_, i)->Print(1);
    }
}

// MaskAxisMergeAxis
MaskAxisMergeAxisNode::~MaskAxisMergeAxisNode() {
    delete this->merge_axis_;
}

storage_t *MaskAxisMergeAxisNode::Compute() {
    // compute axis_2D and strorage_1D
    storage_t::axis_2D_t axis_2D;
    storage_t::storage_1D_t storage_1D;
    this->ComputeMaskAxis(axis_2D, storage_1D);
    // Evaluate
    storage_t *result = this->left_->Evaluate()->MaskAxisMergeAxis(
            *this->merge_axis_, this->right_->Evaluate(), axis_2D, storage_1D);
    // EvaluateDone
    this->ComputeDone();
    return result;
}

void MaskAxisMergeAxisNode::Print(size_type leading_space) {
    BaseNode::Print(leading_space);
    leading_space += 2;
    this->PrintLeft(leading_space);
    algebra::PrintAxis(leading_space, *this->merge_axis_);
    this->PrintRight(leading_space);
    this->PrintMaskAxis(leading_space);
}

// cMaskAxisMergeAxisNode
storage_t *cMaskAxisMergeAxisNode::Compute() {
    // compute mask_1D
    storage_t::storage_1D_t mask_1D;
    for (auto &item : (*this->mask_1D_)) {
        mask_1D.push_back(item->Evaluate());
    }
    // Evaluate
    storage_t *result = this->left_->Evaluate()->cMaskAxisMergeAxis(
            *this->merge_axis_, this->right_->Evaluate(), *this->axis_1D_,
            mask_1D);
    // EvaluateDone
    this->ComputeDone();
    return result;
}

// Mask_Merge__by
storage_t *Mask_Merge__by::Compute() {
    storage_t::storage_1D_t mask_1D;
    for (auto &item : (*this->mask_1D_)) {
        mask_1D.push_back(item->Evaluate());
    }
    storage_t *result = this->left_->Evaluate()->Mask_Merge__by(
            this->right_->Evaluate(), mask_1D, this->key_);
    this->left_->EvaluateDone();
    this->right_->EvaluateDone();
    for (auto &item : (*this->mask_1D_)) {
        item->EvaluateDone();
    }
    return result;
}

BaseNode *Mask_Merge__by::NodeInner(size_type vertex_size) {
    int size[3];
    this->ParseKey(size);
    if (size[0] >= size[1]) {
        return this->left_->Node(vertex_size);
    }
    return this->right_->Node(vertex_size);
}

void Mask_Merge__by::Print(size_type leading_space) {
    BaseNode::Print(leading_space);
    leading_space += 2;
    this->left_->Print(leading_space);
    this->right_->Print(leading_space);
    for (auto &item : (*this->mask_1D_)) {
        item->Print(leading_space);
    }
}

size_type Mask_Merge__by::VertexSize() const {
    int size[3];
    this->ParseKey(size);
    return size[0] + size[1] - size[2];
}

// Pipeline
PipelineNode::~PipelineNode() {
    DeleteContent(*this->merge_axis_1D_);
    delete this->merge_axis_1D_;
    for (size_type i = 0; i < this->mask_axis_2D_->size(); i++) {
        auto *mask_axis_1D = algebra::Get(this->mask_axis_2D_, i);
        auto *mask_node_1D = algebra::Get(this->mask_node_2D_, i);
        DeleteContent(*mask_axis_1D);
        delete mask_axis_1D;
        delete mask_node_1D; // content is BaseNode, owned by node_index_
    }
    delete this->mask_axis_2D_;
    delete this->mask_node_2D_;
}

void PipelineNode::Print(size_type leading_space) {
    BaseNode::Print(leading_space);
    leading_space += 2;
    this->left_->Print(leading_space);
    for (size_type level = 0; level < this->merge_axis_1D_->size(); level++) {
        PrintAxis(leading_space, *algebra::Get(this->merge_axis_1D_, level));
        axis_1D_t *mask_axis_1D = algebra::Get(this->mask_axis_2D_, level);
        basenode_1D_t *mask_node_1D = algebra::Get(this->mask_node_2D_, level);
        for (size_type i = 0; i < this->mask_axis_2D_->size(); i++) {
            PrintAxis(leading_space, *algebra::Get(mask_axis_1D, i));
            algebra::Get(mask_node_1D, i)->Print(1);
        }
    }
}

storage_t *PipelineNode::Compute() {
    storage_t::storage_1D_t storage_1D;
    storage_t::storage_2D_t storage_2D;
    for (size_type level = 0; level < this->merge_axis_1D_->size(); level++) {
        storage_1D.push_back(
                algebra::Get(this->merge_node_1D_, level)->Evaluate());
        storage_t::storage_1D_t *mask_node_1D = new storage_t::storage_1D_t;
        for (auto &item : (*algebra::Get(this->mask_node_2D_, level))) {
            mask_node_1D->push_back(item->Evaluate());
        }
        storage_2D.push_back(mask_node_1D);
    }
    storage_t *result = this->left_->Evaluate()->Pipeline(*this->merge_axis_1D_,
            storage_1D, *this->mask_axis_2D_, storage_2D);
    this->left_->EvaluateDone();
    for (size_type level = 0; level < this->merge_axis_1D_->size(); level++) {
        algebra::Get(this->merge_node_1D_, level)->EvaluateDone();
        for (auto &item : (*algebra::Get(this->mask_node_2D_, level))) {
            item->EvaluateDone();
        }
    }
    DeleteContent(storage_2D);
    return result;
}

BaseNode *PipelineNode::NodeInner(size_type vertex_size) {
    // choose the next max VertexSize node
    BaseNode *max_node = this->left_;
    size_type max_size = this->left_->VertexSize();
    for (auto &item : (*this->merge_node_1D_)) {
        size_type candidate = item->VertexSize();
        if (candidate > max_size) {
            max_size = candidate;
            max_node = item;
        }
    }
    return max_node->Node(vertex_size);
}

size_type PipelineNode::VertexSize() const {
    size_type vertex_size = this->left_->VertexSize();
    for (size_type i = 0; i < this->merge_axis_1D_->size(); i++) {
        vertex_size += (vertex_size + (*this->merge_node_1D_)[0]->VertexSize()
                - (*this->merge_axis_1D_)[0]->size());
    }
    return vertex_size;
}

// sum
SumNode::~SumNode() {
    delete this->nodelist_;
}

storage_t *SumNode::Compute() {
    storagesum_t::storage_1D_t storage_1D;
    for (auto &item : (*this->nodelist_)) {
        storage_1D.push_back(item->Evaluate());
    }
    storage_t *result = new storagesum_t(storage_1D);
    for (size_type i = 0; i < this->nodelist_->size(); i++) {
        algebra::Get(this->nodelist_, i)->EvaluateDone();
    }
    return result;
}

BaseNode *SumNode::NodeInner(size_type vertex_size) {
    for (auto &item : (*this->nodelist_)) {
        return item->Node(vertex_size);
    }
    return this;
}

void SumNode::Print(size_type leading_space) {
    BaseNode::Print(leading_space);
    leading_space += 2;
    for (const auto &node : *this->nodelist_) {
        node->Print(leading_space);
    }
}

size_type SumNode::VertexSize() const {
    for (auto &item : (*this->nodelist_)) {
        return item->VertexSize();
    }
    return 0;
}

}
// namespace algebra
