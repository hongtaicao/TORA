/*
 * leaf.cpp
 *
 *  Created on: 2020-9-12 2:46
 *      Author: Hongtai Cao
 */

#include <assert.h>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>

#include "algebra/basetype.hpp"
#include "algebra/expression/basenode.hpp"
#include "algebra/expression/initialize.hpp"
#include "algebra/expression/leaf.hpp"
#include "algebra/io/filereader.hpp"
#include "algebra/io/writer.hpp"
#include "algebra/utility/misc.hpp"
#include "algebra/utility/parse.hpp"
#include "algebra/utility/tostring.hpp"

namespace algebra {

const std::unordered_set<std::string> Leaf::LEAF_SET( { "B", "U", "UT", "N" });

void Leaf::ApplyFilter() {
    // assign cache using this->pool_
    storage_t *b = this->GetFilter("B"), *u = this->GetFilter("U");
    storage_t *ut = this->GetFilter("UT");
    for (auto pair : this->data_) {
        assert(this->InPool(pair.first));
        storage_t *source = this->pool_[pair.first];
        if (pair.second->node_ != nullptr) {
            // leaf without filter
            pair.second->node_->AssignCache(source, false);
        }
        if (pair.first == "N") {
            // N is not supported in leaf with argument
            continue;
        }
        // create new cache using the pool
        for (auto head_dist : pair.second->data_) {
            const degree_t &head_degree = head_dist.second->degree_;
            auto head_filter = this->FilterFunction(head_degree);
            for (auto tail_dist : head_dist.second->data_) {
                // leaf with filter
                const degree_t &tail_degree = tail_dist.second->degree_;
                if (head_degree.empty() and tail_degree.empty()) {
                    // no filter
                    tail_dist.second->node_->AssignCache(source, false);
                    continue;
                }
                edgestore_t *filtered = new edgestore_t;
                auto tail_filter = this->FilterFunction(tail_degree);
                for (auto head = source->CreateIterator();
                _STORAGE_::InRange(head); head->Advance()) {
                    // filter head
                    if (head_filter(b, u, ut, head->Key(), head_degree)) {
                        continue;
                    }
                    edgestore_t *child_map = new edgestore_t;
                    for (auto tail = head->Value()->CreateIterator();
                    _STORAGE_::InRange(tail); tail->Advance()) {
                        // filter tail
                        if (tail_filter(b, u, ut, tail->Key(), tail_degree)) {
                            continue;
                        }
                        child_map->Insert(tail->Key());
                    }
                    filtered->InsertNonEmpty(head->Key(), child_map);
                }
                tail_dist.second->node_->AssignCache(filtered, true);
            }
        }
    }
}

int Leaf::Build(const ArgParser &argparser) {
    // compute the leaf of expression and return the case code
    if (argparser.LeafFilter()) {
        // prepare for degree filter
        this->ParseFilter();
    }
    // initialize leaf
    int code = 0;
    if (argparser.Leaf() == LEAF_BUILDINGBLOCK) {
        // read building block file
        BuildPoolByBuildingBlock(this, argparser);
    } else {
        // read adjacency file
        if (argparser.Leaf() == LEAF_ADJACENCY_STORAGE) {
            // read adjacency file and direct construct
            code = BuildPoolByStorage(this, argparser);
        } else if (argparser.Leaf() == LEAF_ADJACENCY_BUILDER) {
            // read adjacency file and use builder
            code = BuildPoolByBuilder(this, argparser);
        } else if (argparser.Leaf() == LEAF_ADJACENCY_EVALUATE) {
            // read adjacency file and evaluate
            // evaluate leaf from A
            this->BuildPoolByEvaluate();
        }
    }
    if (argparser.AblationComplement() and this->Has("N")) {
        storage_t *storage = this->pool_["N"];
        edgestore_t *edgestore = new edgestore_t;
        for (auto head = storage->CreateIterator();
        _STORAGE_::InRange(head); head->Advance()) {
            edgestore_t *child_map = new edgestore_t;
            for (auto tail = head->Value()->CreateIterator();
            _STORAGE_::InRange(tail); tail->Advance()) {
                child_map->Insert(tail->Key());
            }
            edgestore->InsertNonEmpty(head->Key(), child_map);
        }
        delete storage;
        this->pool_["N"] = edgestore;
    }
    // all leaf are ready, perform degree filter
    this->ApplyFilter();
    return code;
}

void Leaf::BuildPoolByEvaluate() {
    // build pool by evaluate Adjacency
    // evaluated result ownership is transfered to this->pool_
    for (auto pair : this->data_) {
        if (pair.second->node_ != nullptr) {
            this->AddPool(pair.first,
                    (storage_t *) pair.second->node_->Evaluate());
            continue;
        }
        for (auto head_dist : pair.second->data_) {
            for (auto tail_dist : head_dist.second->data_) {
                this->AddPool(pair.first,
                        (storage_t *) tail_dist.second->node_->Evaluate());
                break;
            }
            break;
        }
    }
}

typename Leaf::FunctionPointer Leaf::FilterFunction(const degree_t &degree) {
    if (degree.empty()) {
        leaf::DebugFilterFunction(degree, "IsFiltered_");
        return leaf::IsFiltered_;
    } else if (degree[0]) {
        if (degree[1]) {
            if (degree[2]) {
                leaf::DebugFilterFunction(degree, "IsFilteredBUUT");
                return leaf::IsFilteredBUUT;
            }
            leaf::DebugFilterFunction(degree, "IsFilteredBU");
            return leaf::IsFilteredBU;
        } else if (degree[2]) {
            leaf::DebugFilterFunction(degree, "IsFilteredBUT");
            return leaf::IsFilteredBUT;
        }
        leaf::DebugFilterFunction(degree, "IsFilteredB");
        return leaf::IsFilteredB;
    } else if (degree[1]) {
        if (degree[2]) {
            leaf::DebugFilterFunction(degree, "IsFilteredUUT");
            return leaf::IsFilteredUUT;
        }
        leaf::DebugFilterFunction(degree, "IsFilteredU");
        return leaf::IsFilteredU;
    } else if (degree[2]) {
        leaf::DebugFilterFunction(degree, "IsFilteredUT");
        return leaf::IsFilteredUT;
    }
    leaf::DebugFilterFunction(degree, "IsFiltered_");
    return leaf::IsFiltered_;
}

void Leaf::ParseFilter() {
    for (auto pair : this->data_) {
        for (auto head_dist : pair.second->data_) {
            leaf::BuildDegree(pair.first, true, this->data_,
                    head_dist.second->degree_, head_dist.first);
            for (auto tail_dist : head_dist.second->data_) {
                leaf::BuildDegree(pair.first, false, this->data_,
                        tail_dist.second->degree_, tail_dist.first);
            }
        }
    }
}

namespace leaf {

inline void AddU(Leaf::data_t &data, const Leaf::degree_t &degree) {
    if (degree[1] > 1) {
        if (data.count("U") == 0) {
            data["U"] = new Leaf;
        }
    }
}

inline void AddUT(Leaf::data_t &data, const Leaf::degree_t &degree) {
    if (degree[2] > 1) {
        if (data.count("UT") == 0) {
            data["UT"] = new Leaf;
        }
    }
}

void BuildDegree(const std::string &key, bool head, Leaf::data_t &data,
        Leaf::degree_t &degree, const std::string &axis) {
    // add additional building block if required by degree
    algebra::ParseAxis(&degree, axis);
    if (degree.size() > 0) {
        if (key == "B") {
            if (leaf::NotDummyDegree(degree, 0)) {
                leaf::AddU(data, degree);
                leaf::AddUT(data, degree);
            }
        } else if (key == "U") {
            // U satisfy ([0,1,0],[0,0,1])
            if (head) {
                if (leaf::NotDummyDegree(degree, 1)) {
                    leaf::AddUT(data, degree);
                }
            } else {
                if (leaf::NotDummyDegree(degree, 2)) {
                    leaf::AddUT(data, degree);
                }
            }
        } else {
            // UT satisfy ([0,0,1],[0,1,0])
            if (head) {
                if (leaf::NotDummyDegree(degree, 2)) {
                    leaf::AddU(data, degree);
                }
            } else {
                if (leaf::NotDummyDegree(degree, 1)) {
                    leaf::AddU(data, degree);
                }
            }
        }
    }
}

inline void DebugFilterFunction(const Leaf::degree_t &degree,
        const std::string &name) {
    // https://stackoverflow.com/a/15764679/11193802
    // silence warning: unused parameter 'degree'
    Ignore(degree);
    Ignore(name);
    PRINT("leaf::FilterFunctionDebug(): [" << OrderedToString(degree));
    PRINTLINE("] FilterFunction=" << name);
}

inline bool IsFiltered(Leaf::storage_t *storage, data_size_t key,
        size_type threshold) {
    assert(threshold > 1);
    assert(storage != nullptr);
    // filter key when
    // 1. not Match => this type of degree is 0
    // 2. Match but degree smaller than threshold
    return (not storage->KeyMatch(key))
            or (storage->Value(key)->LoopSize()) < threshold;
}

inline bool IsFiltered_(Leaf::storage_t *, Leaf::storage_t *, Leaf::storage_t *,
        data_size_t, const Leaf::degree_t &) {
    return false;
}

inline bool IsFilteredB(Leaf::storage_t *b, Leaf::storage_t *,
        Leaf::storage_t *, data_size_t key, const Leaf::degree_t &degree) {
    if (leaf::IsFiltered(b, key, degree[0])) {
        return true;
    }
    return false;
}

inline bool IsFilteredBU(Leaf::storage_t *b, Leaf::storage_t *u,
        Leaf::storage_t *, data_size_t key, const Leaf::degree_t &degree) {
    if (leaf::IsFiltered(b, key, degree[0])) {
        return true;
    }
    if (leaf::IsFiltered(u, key, degree[1])) {
        return true;
    }
    return false;
}

inline bool IsFilteredBUT(Leaf::storage_t *b, Leaf::storage_t *,
        Leaf::storage_t *ut, data_size_t key,
        const std::vector<size_type> &degree) {
    if (leaf::IsFiltered(b, key, degree[0])) {
        return true;
    }
    if (leaf::IsFiltered(ut, key, degree[2])) {
        return true;
    }
    return false;
}

inline bool IsFilteredBUUT(Leaf::storage_t *b, Leaf::storage_t *u,
        Leaf::storage_t *ut, data_size_t key, const Leaf::degree_t &degree) {
    if (leaf::IsFiltered(b, key, degree[0])) {
        return true;
    }
    if (leaf::IsFiltered(u, key, degree[1])) {
        return true;
    }
    if (leaf::IsFiltered(ut, key, degree[2])) {
        return true;
    }
    return false;
}

inline bool IsFilteredU(Leaf::storage_t *, Leaf::storage_t *u,
        Leaf::storage_t *, data_size_t key, const Leaf::degree_t &degree) {
    if (leaf::IsFiltered(u, key, degree[1])) {
        return true;
    }
    return false;
}

inline bool IsFilteredUT(Leaf::storage_t *, Leaf::storage_t *,
        Leaf::storage_t *ut, data_size_t key, const Leaf::degree_t &degree) {
    if (leaf::IsFiltered(ut, key, degree[2])) {
        return true;
    }
    return false;
}

inline bool IsFilteredUUT(Leaf::storage_t *, Leaf::storage_t *u,
        Leaf::storage_t *ut, data_size_t key, const Leaf::degree_t &degree) {
    if (leaf::IsFiltered(u, key, degree[1])) {
        return true;
    }
    if (leaf::IsFiltered(ut, key, degree[2])) {
        return true;
    }
    return false;
}

bool NotDummyDegree(Leaf::degree_t &degree, size_type axis) {
    if (axis == 0) {
        if (degree[0] == 1) {
            DebugNotDummyDegreeBefore(degree, axis);
            degree[0] = 0;
            DebugNotDummyDegreeAfter(degree);
            return degree[1] or degree[2];
        }
    } else if (axis == 1) {
        if (degree[1] == 1) {
            DebugNotDummyDegreeBefore(degree, axis);
            degree[1] = 0;
            DebugNotDummyDegreeAfter(degree);
            return degree[0] or degree[2];
        }
    } else {
        if (degree[2] == 1) {
            DebugNotDummyDegreeBefore(degree, axis);
            degree[2] = 0;
            DebugNotDummyDegreeAfter(degree);
            return degree[0] or degree[1];
        }
    }
    return degree[0] or degree[1] or degree[2];
}

inline void DebugNotDummyDegreeAfter(const Leaf::degree_t &degree) {
    Ignore(degree);
    PRINTLINE(" after=[" << OrderedToString(degree) << "]");
}

inline void DebugNotDummyDegreeBefore(const Leaf::degree_t &degree,
        size_type axis) {
    Ignore(degree);
    Ignore(axis);
    PRINT("leaf::NotDummyDegreeDebug() axis=" << axis << " before=[");
    PRINTLINE(OrderedToString(degree) << "]");
}

} // namespace leaf

} // namespace algebra
