/*
 * initialize.cpp
 *
 *  Created on: 2020-4-18 8:58
 *      Author: Hongtai Cao
 */

#include <string>
#include <unordered_set>

#include "algebra/argparser.hpp"
#include "algebra/basetype.hpp"
#include "algebra/expression/basenode.hpp"
#include "algebra/expression/initialize.hpp"
#include "algebra/expression/leaf.hpp"
#include "algebra/io/filereader.hpp"
#include "algebra/storage/nestedmap/base.hpp"
#include "algebra/utility/misc.hpp"

namespace algebra {

namespace by_builder {

inline void AddUToN(storagebuilder_t *builder, complement_t *complement) {
    complement->AddUFast(builder);
    complement->Sorted();
}

inline void AssignUUT(Leaf *leaf, const storagebuilder_t *builder) {
    if (leaf->Has("U") > 0) {
        leaf->AddPool("U",
                (_STORAGE_::Base<data_size_t> *) builder->CreateU(
                        new edgestore_t));
    }
    if (leaf->Has("UT") > 0) {
        leaf->AddPool("UT",
                (_STORAGE_::Base<data_size_t> *) builder->CreateUT(
                        new edgestore_t));
    }
}

} // namespace build_by_builder

namespace by_storage {

inline void AddUnidirectToN(edgestore_t *u, complement_t *complement) {
    complement->AddEdgeFast(u);
    complement->Sorted();
}

void FilterBy(edgestore_t *target, edgestore_t *b) {
    // only improve the performance
    if (target->LoopSize() < b->LoopSize()) {
        target->Filter();
    } else {
        for (auto it = b->CreateIterator(); _STORAGE_::InRange(it);
                it->Advance()) {
            if ((target->KeyMatch(it->Key()))
                    and (target->Value(it->Key())->LoopSize() == 0)) {
                target->DeleteErase(it->Key());
            }
        }
    }
    target->Sorted();
}

void BuildReverse(edgestore_t *target, edgestore_t *source) {
    // build ut from u
    for (auto outer = source->CreateIterator(); _STORAGE_::InRange(outer);
            outer->Advance()) {
        for (auto inner = outer->Value()->CreateIterator();
        _STORAGE_::InRange(inner); inner->Advance()) {
            target->Insert(inner->Key(), outer->Key());
        }
    }
    target->Sorted();
}

} // namespace by_storage

namespace init_by_A {

template<typename builder_T>
inline void ParseB(data_size_t from_vertex, data_size_t to_vertex,
        builder_T *builder, edgestore_t *bidirection, complement_t *,
        const data_size_t &) {
    if (from_vertex > to_vertex) {
        if (builder->Has(to_vertex, from_vertex)) {
            // bi-directional edge
            bidirection->Insert(from_vertex, to_vertex);
            bidirection->Insert(to_vertex, from_vertex);
        }
    } else {
        builder->Insert(from_vertex, to_vertex);
    }
}

template<typename builder_T>
inline void ParseBNU(data_size_t from_vertex, data_size_t to_vertex,
        builder_T *builder, edgestore_t *bidirection, complement_t *complement,
        const data_size_t &) {
    if (from_vertex > to_vertex) {
        if (builder->Has(to_vertex, from_vertex)) {
            // bi-directional
            builder->Erase(to_vertex, from_vertex);
            bidirection->Insert(from_vertex, to_vertex);
            bidirection->Insert(to_vertex, from_vertex);
        } else {
            builder->Insert(from_vertex, to_vertex);
        }
    } else {
        builder->Insert(from_vertex, to_vertex);
    }
    // add adjacency^T
    complement->InsertFast(to_vertex, from_vertex);
}

template<typename builder_T>
inline void ParseBNUAdjacency(data_size_t from_vertex, data_size_t to_vertex,
        builder_T *builder, edgestore_t *bidirection, complement_t *complement,
        data_size_t &vertex_count) {
    if (from_vertex > to_vertex) {
        if (builder->Has(to_vertex, from_vertex)) {
            // bi-directional
            builder->Erase(to_vertex, from_vertex);
            bidirection->Insert(from_vertex, to_vertex);
            bidirection->Insert(to_vertex, from_vertex);
        } else {
            builder->Insert(from_vertex, to_vertex);
        }
        vertex_count = std::max(vertex_count, from_vertex);
    } else {
        builder->Insert(from_vertex, to_vertex);
        vertex_count = std::max(vertex_count, to_vertex);
    }
    // add adjacency^T
    complement->Insert(to_vertex, from_vertex);
}

template<typename builder_T>
inline void ParseBNUT(data_size_t from_vertex, data_size_t to_vertex,
        builder_T *ut, edgestore_t *bidirection, complement_t *complement,
        const data_size_t &) {
    if (from_vertex > to_vertex) {
        if (ut->Has(from_vertex, to_vertex)) {
            // bi-directional
            ut->Erase(from_vertex, to_vertex);
            bidirection->Insert(from_vertex, to_vertex);
            bidirection->Insert(to_vertex, from_vertex);
        } else {
            ut->Insert(to_vertex, from_vertex);
        }
    } else {
        ut->Insert(to_vertex, from_vertex);
    }
    // add adjacency
    complement->InsertFast(from_vertex, to_vertex);
}

template<typename builder_T>
inline void ParseBNUTAdjacency(data_size_t from_vertex, data_size_t to_vertex,
        builder_T *ut, edgestore_t *bidirection, complement_t *complement,
        data_size_t &vertex_count) {
    if (from_vertex > to_vertex) {
        if (ut->Has(from_vertex, to_vertex)) {
            // bi-directional
            ut->Erase(from_vertex, to_vertex);
            bidirection->Insert(from_vertex, to_vertex);
            bidirection->Insert(to_vertex, from_vertex);
        } else {
            ut->Insert(to_vertex, from_vertex);
        }
        vertex_count = std::max(vertex_count, from_vertex);
    } else {
        ut->Insert(to_vertex, from_vertex);
        vertex_count = std::max(vertex_count, to_vertex);
    }
    // add adjacency
    complement->Insert(from_vertex, to_vertex);
}

template<typename builder_T>
inline void ParseBU(data_size_t from_vertex, data_size_t to_vertex,
        builder_T *builder, edgestore_t *bidirection, complement_t *,
        const data_size_t &) {
    if (from_vertex > to_vertex) {
        if (builder->Has(to_vertex, from_vertex)) {
            // bi-directional
            builder->Erase(to_vertex, from_vertex);
            bidirection->Insert(from_vertex, to_vertex);
            bidirection->Insert(to_vertex, from_vertex);
        } else {
            builder->Insert(from_vertex, to_vertex);
        }
    } else {
        builder->Insert(from_vertex, to_vertex);
    }
}

template<typename builder_T>
inline void ParseBUT(data_size_t from_vertex, data_size_t to_vertex,
        builder_T *builder, edgestore_t *bidirection, complement_t *,
        const data_size_t &) {
    if (from_vertex > to_vertex) {
        if (builder->Has(from_vertex, to_vertex)) {
            // bi-directional
            builder->Erase(from_vertex, to_vertex);
            bidirection->Insert(from_vertex, to_vertex);
            bidirection->Insert(to_vertex, from_vertex);
        } else {
            builder->Insert(to_vertex, from_vertex);
        }
    } else {
        builder->Insert(to_vertex, from_vertex);
    }
}

template<typename builder_T>
inline void ParseU(data_size_t from_vertex, data_size_t to_vertex,
        builder_T *builder, edgestore_t *, complement_t *,
        const data_size_t &) {
    if (from_vertex > to_vertex) {
        if (builder->Has(to_vertex, from_vertex)) {
            // bi-directional edge
            builder->Erase(to_vertex, from_vertex);
        } else {
            builder->Insert(from_vertex, to_vertex);
        }
    } else {
        builder->Insert(from_vertex, to_vertex);
    }
}

template<typename builder_T>
inline void ParseNU(data_size_t from_vertex, data_size_t to_vertex,
        builder_T *builder, edgestore_t *, complement_t *complement,
        const data_size_t &) {
    ParseU(from_vertex, to_vertex, builder, nullptr, nullptr, 0);
    // add adjacency^T
    complement->InsertFast(to_vertex, from_vertex);
}

template<typename builder_T>
inline void ParseNUAdjacency(data_size_t from_vertex, data_size_t to_vertex,
        builder_T *builder, edgestore_t *, complement_t *complement,
        data_size_t &vertex_count) {
    if (from_vertex > to_vertex) {
        if (builder->Has(to_vertex, from_vertex)) {
            // bi-directional edge
            builder->Erase(to_vertex, from_vertex);
        } else {
            builder->Insert(from_vertex, to_vertex);
        }
        vertex_count = std::max(vertex_count, from_vertex);
    } else {
        builder->Insert(from_vertex, to_vertex);
        vertex_count = std::max(vertex_count, to_vertex);
    }
    // add adjacency^T
    complement->Insert(to_vertex, from_vertex);
}

template<typename builder_T>
inline void ParseUT(data_size_t from_vertex, data_size_t to_vertex,
        builder_T *builder, edgestore_t *, complement_t *,
        const data_size_t &) {
    if (from_vertex > to_vertex) {
        if (builder->Has(from_vertex, to_vertex)) {
            // bi-directional
            builder->Erase(from_vertex, to_vertex);
        } else {
            builder->Insert(to_vertex, from_vertex);
        }
    } else {
        builder->Insert(to_vertex, from_vertex);
    }
}

template<typename builder_T>
inline void ParseNUT(data_size_t from_vertex, data_size_t to_vertex,
        builder_T *builder, edgestore_t *, complement_t *complement,
        const data_size_t &) {
    ParseUT(from_vertex, to_vertex, builder, nullptr, nullptr, 0);
    // add adjacency
    complement->InsertFast(from_vertex, to_vertex);
}

template<typename builder_T>
inline void ParseNUTAdjacency(data_size_t from_vertex, data_size_t to_vertex,
        builder_T *builder, edgestore_t *, complement_t *complement,
        data_size_t &vertex_count) {
    if (from_vertex > to_vertex) {
        if (builder->Has(from_vertex, to_vertex)) {
            // bi-directional edge
            builder->Erase(from_vertex, to_vertex);
        } else {
            builder->Insert(to_vertex, from_vertex);
        }
        vertex_count = std::max(vertex_count, from_vertex);
    } else {
        builder->Insert(to_vertex, from_vertex);
        vertex_count = std::max(vertex_count, to_vertex);
    }
    // add adjacency
    complement->Insert(from_vertex, to_vertex);
}

template<typename builder_T, typename function_T, typename reader_T>
void ReadNeighborList(builder_T *builder, edgestore_t *bidirection,
        complement_t *complement, function_T parse, reader_T &reader) {
    /*
     * vertex_count neighborlist_count
     * from_vertex  neighbor_size to_vertex1 to_vertex2 to_vertex3 ...
     */
    size_type vertex_count, neighborlist_count, neighbor_size;
    reader.Read(vertex_count, neighborlist_count);
    if (complement != nullptr) {
        complement->InitializeWithSelfLoop(vertex_count);
    }
    data_size_t from_vertex, to_vertex;
    while (reader.Read(from_vertex, neighbor_size)) {
        for (; neighbor_size > 0; neighbor_size--) {
            reader.Read(to_vertex);
            parse(from_vertex, to_vertex, builder, bidirection, complement, 0);
        }
    }
}

template<typename builder_T, typename function_T, typename reader_T>
void ReadPairList(builder_T *builder, edgestore_t *bidirection,
        complement_t *complement, function_T parse, reader_T &reader) {
    /*
     * vertex_count pairlist_count
     * from_vertex to_vertex
     * from_vertex to_vertex
     * from_vertex to_vertex
     */
    size_type vertex_count, pairlist_count;
    reader.Read(vertex_count, pairlist_count);
    if (complement != nullptr) {
        complement->InitializeWithSelfLoop(vertex_count);
    }
    data_size_t from_vertex, to_vertex;
    while (reader.Read(from_vertex, to_vertex)) {
        parse(from_vertex, to_vertex, builder, bidirection, complement, 0);
    }
}

template<typename builder_T, typename function_T, typename reader_T>
void ReadPairListAdjacency(builder_T *builder, edgestore_t *bidirection,
        complement_t *complement, function_T parse_adjacency,
        reader_T &reader) {
    // add self loop to complement if needed
    /*
     * from_vertex to_vertex
     * from_vertex to_vertex
     * from_vertex to_vertex
     */
    data_size_t from_vertex, to_vertex;
    data_size_t vertex_count = 0;
    bool status = reader.Read(from_vertex, to_vertex);
    if (status) {
        parse_adjacency(from_vertex, to_vertex, builder, bidirection,
                complement, vertex_count);
        while (reader.Read(from_vertex, to_vertex)) {
            parse_adjacency(from_vertex, to_vertex, builder, bidirection,
                    complement, vertex_count);
        }
        vertex_count += 1;
    }
    if (complement != nullptr) {
        complement->AddSelfLoop(vertex_count);
    }
}

template<typename builder_T, typename parse_T, typename parse_adjacency_T>
void ReadAdjacencyData(const ArgParser &argparser, builder_T *builder,
        edgestore_t *bidirection, complement_t *complement, parse_T parse,
        parse_adjacency_T parse_adjacency) {
    // https://stackoverflow.com/a/16440137/11193802
    // pass function as template argument if can be known as compile time
    if (argparser.LeafFormat() == LEAF_BINARY_BLOCK) {
        // single line file
        /*
         * block binary format
         * data[0] = vertex_count
         * data[1] = key
         * data[2] = next_key_position
         * data[3...next_key_position-1] = neighbor_list
         */
        // read file
        algebra::BinaryReader reader(argparser.DataFile("A"));
        std::vector<data_size_t> data;
        reader.ReadAll(data);
        // parse data
        data_size_t vertex_count = data[0];
        if (complement != nullptr) {
            complement->InitializeWithSelfLoop(vertex_count);
        }
        size_type index = 1;
        while (index < data.size()) {
            data_size_t from_vertex = data[index];
            index++;
            size_type next_index = data[index];
            for (index++; index < next_index; index++) {
                parse(from_vertex, data[index], builder, bidirection,
                        complement, vertex_count);
            }
        }
    } else if (argparser.LeafFormat() == LEAF_BINARY_NEIGHBORLIST) {
        // binary has no line concept
        algebra::BinaryReader reader(argparser.DataFile("A"));
        ReadNeighborList(builder, bidirection, complement, parse, reader);
    } else if (argparser.LeafFormat() == LEAF_BINARY_PAIRLIST) {
        // binary has no line concept
        algebra::BinaryReader reader(argparser.DataFile("A"));
        ReadPairList(builder, bidirection, complement, parse, reader);
    } else if (argparser.LeafFormat() == LEAF_TEXT_NEIGHBORLIST) {
        // multi-line file
        algebra::FileReader reader(argparser.DataFile("A"));
        ReadNeighborList(builder, bidirection, complement, parse, reader);
    } else if (argparser.LeafFormat() == LEAF_TEXT_PAIRLIST) {
        // multi-line file
        algebra::FileReader reader(argparser.DataFile("A"));
        ReadPairList(builder, bidirection, complement, parse, reader);
    } else {
        algebra::FileReader reader(argparser.DataFile());
        ReadPairListAdjacency(builder, bidirection, complement, parse_adjacency,
                reader);
    }
}

inline void PrepareStart() {
    std::cout << algebra::GetCurrentTime() << " initialize/PrepareStart"
            << std::endl;
}

inline void PrepareItem(const std::string &outfile,
        _STORAGE_::Base<data_size_t> *storage) {
    std::cout << algebra::GetCurrentTime() << " initialize/PrepareItem "
            << "size=(" << storage->RowSize() << ", " << storage->ColumnSize()
            << ") " << outfile << std::endl;
}

inline void PrepareDone() {
    std::cout << algebra::GetCurrentTime() << " initialize/PrepareDone"
            << std::endl;
}

} // namespace init_by_A

void BuildBNUUT(const std::string &data, storagebuilder_t *builder,
        edgestore_t *bidirection, complement_t *complement) {
    // read data as adjacency list
    // -format 5=TEXT_PAIRLIST_ADJACENCY
    // -leaf   2=ADJACENCY_BUILDER
    algebra::FileReader reader(data);
    init_by_A::ReadPairListAdjacency(builder, bidirection, complement,
            init_by_A::ParseBNUAdjacency<storagebuilder_t>, reader);
    bidirection->Sorted();
    by_builder::AddUToN(builder, complement);
}

static std::unordered_set<std::string> EDGESTORE_SET = { "B", "U", "UT" };
void BuildPoolByBuildingBlock(Leaf *leaf, const ArgParser &argparser) {
    for (auto &item : EDGESTORE_SET) {
        if (leaf->Has(item)) {
            leaf->AddPool(item, new edgestore_t(argparser, item));
        }
    }
    if (leaf->Has("N")) {
        leaf->AddPool("N", new complement_t(argparser));
    }
}

int BuildPoolByBuilder(Leaf *leaf, const ArgParser &argparser) {
    int case_code = 0;
    storagebuilder_t *builder = new storagebuilder_t;
    if (leaf->Has("B")) {
        // need B
        edgestore_t *bidirection = new edgestore_t;
        if (leaf->Has("N")) {
            // need N
            case_code = 5;
            complement_t *complement = new complement_t;
            init_by_A::ReadAdjacencyData(argparser, builder, bidirection,
                    complement, init_by_A::ParseBNU<storagebuilder_t>,
                    init_by_A::ParseBNUAdjacency<storagebuilder_t>);
            by_builder::AddUToN(builder, complement);
            by_builder::AssignUUT(leaf, builder);
            leaf->AddPool("N", complement);
        } else {
            if (leaf->Has("U") or leaf->Has("UT")) {
                case_code = 4;
                init_by_A::ReadAdjacencyData(argparser, builder, bidirection,
                        nullptr, init_by_A::ParseBU<storagebuilder_t>,
                        init_by_A::ParseBU<storagebuilder_t>);
                by_builder::AssignUUT(leaf, builder);
            } else {
                case_code = 3;
                init_by_A::ReadAdjacencyData(argparser, builder, bidirection,
                        nullptr, init_by_A::ParseB<storagebuilder_t>,
                        init_by_A::ParseB<storagebuilder_t>);
            }
        }
        bidirection->Sorted();
        leaf->AddPool("B", bidirection);
    } else {
        if (leaf->Has("N")) {
            // need N
            case_code = 2;
            complement_t *complement = new complement_t;
            init_by_A::ReadAdjacencyData(argparser, builder, nullptr,
                    complement, init_by_A::ParseNU<storagebuilder_t>,
                    init_by_A::ParseNUAdjacency<storagebuilder_t>);
            by_builder::AddUToN(builder, complement);
            by_builder::AssignUUT(leaf, builder);
            leaf->AddPool("N", complement);
        } else {
            case_code = 1;
            init_by_A::ReadAdjacencyData(argparser, builder, nullptr, nullptr,
                    init_by_A::ParseU<storagebuilder_t>,
                    init_by_A::ParseU<storagebuilder_t>);
            by_builder::AssignUUT(leaf, builder);
        }
    }
    return case_code;
}

int BuildPoolByStorage(Leaf *leaf, const ArgParser &argparser) {
    // build pool by reading adjacency file
    int case_code = 0;
    if (leaf->Has("B")) {
        edgestore_t *bidirection = new edgestore_t;
        if (leaf->Has("N")) {
            complement_t *complement = new complement_t;
            if (leaf->Has("U")) {
                edgestore_t *u = new edgestore_t;
                init_by_A::ReadAdjacencyData(argparser, u, bidirection,
                        complement, init_by_A::ParseBNU<edgestore_t>,
                        init_by_A::ParseBNUAdjacency<edgestore_t>);
                by_storage::FilterBy(u, bidirection);
                by_storage::AddUnidirectToN(u, complement);
                if (leaf->Has("UT")) {
                    case_code = 54; // B, N, U, UT
                    edgestore_t *ut = new edgestore_t;
                    by_storage::BuildReverse(ut, u);
                    leaf->AddPool("UT", ut);
                } else {
                    case_code = 53; // B, N, U
                }
                leaf->AddPool("U", u);
            } else {
                edgestore_t *ut = new edgestore_t;
                init_by_A::ReadAdjacencyData(argparser, ut, bidirection,
                        complement, init_by_A::ParseBNUT<edgestore_t>,
                        init_by_A::ParseBNUTAdjacency<edgestore_t>);
                by_storage::FilterBy(ut, bidirection);
                by_storage::AddUnidirectToN(ut, complement);
                leaf->AddPool("UT", ut);
                if (leaf->Has("UT")) {
                    case_code = 52; // B, N, UT
                } else {
                    case_code = 51; // B, N
                }
            }
            leaf->AddPool("N", complement);
        } else if (leaf->Has("U")) {
            edgestore_t *u = new edgestore_t;
            init_by_A::ReadAdjacencyData(argparser, u, bidirection, nullptr,
                    init_by_A::ParseBU<edgestore_t>,
                    init_by_A::ParseBU<edgestore_t>);
            by_storage::FilterBy(u, bidirection);
            if (leaf->Has("UT")) {
                case_code = 43; // B, U, UT
                edgestore_t *ut = new edgestore_t;
                by_storage::BuildReverse(ut, u);
                leaf->AddPool("UT", ut);
            } else {
                case_code = 42; // B, U
            }
            leaf->AddPool("U", u);
        } else if (leaf->Has("UT")) {
            case_code = 41; // B, UT
            edgestore_t *ut = new edgestore_t;
            init_by_A::ReadAdjacencyData(argparser, ut, bidirection, nullptr,
                    init_by_A::ParseBUT<edgestore_t>,
                    init_by_A::ParseBUT<edgestore_t>);
            by_storage::FilterBy(ut, bidirection);
            leaf->AddPool("UT", ut);
        } else {
            case_code = 31; // B
            edgestore_t *u = new edgestore_t;
            init_by_A::ReadAdjacencyData(argparser, u, bidirection, nullptr,
                    init_by_A::ParseBU<edgestore_t>,
                    init_by_A::ParseBU<edgestore_t>);
            leaf->AddPool("U", u);
        }
        bidirection->Sorted();
        leaf->AddPool("B", bidirection);
    } else {
        if (leaf->Has("N")) {
            complement_t *complement = new complement_t;
            if (leaf->Has("U")) {
                edgestore_t *u = new edgestore_t;
                init_by_A::ReadAdjacencyData(argparser, u, nullptr, complement,
                        init_by_A::ParseNU<edgestore_t>,
                        init_by_A::ParseNUAdjacency<edgestore_t>);
                u->Filter();
                by_storage::AddUnidirectToN(u, complement);
                if (leaf->Has("UT")) {
                    case_code = 24; // N, U, UT
                    edgestore_t *ut = new edgestore_t;
                    by_storage::BuildReverse(ut, u);
                    leaf->AddPool("UT", ut);
                } else {
                    case_code = 23; // N, U
                }
                leaf->AddPool("U", u);
            } else {
                edgestore_t *ut = new edgestore_t;
                init_by_A::ReadAdjacencyData(argparser, ut, nullptr, complement,
                        init_by_A::ParseNUT<edgestore_t>,
                        init_by_A::ParseNUTAdjacency<edgestore_t>);
                ut->Filter();
                by_storage::AddUnidirectToN(ut, complement);
                leaf->AddPool("UT", ut);
                if (leaf->Has("UT")) {
                    case_code = 22; // N, UT
                } else {
                    case_code = 21; // N
                }
            }
            leaf->AddPool("N", complement);
        } else if (leaf->Has("U")) {
            edgestore_t *u = new edgestore_t;
            init_by_A::ReadAdjacencyData(argparser, u, nullptr, nullptr,
                    init_by_A::ParseU<edgestore_t>,
                    init_by_A::ParseU<edgestore_t>);
            u->Filter();
            if (leaf->Has("UT")) {
                case_code = 14; // U, UT
                edgestore_t *ut = new edgestore_t;
                by_storage::BuildReverse(ut, u);
                leaf->AddPool("UT", ut);
            } else {
                case_code = 13; // U
            }
            leaf->AddPool("U", u);
        } else if (leaf->Has("UT")) {
            case_code = 12; // UT
            edgestore_t *ut = new edgestore_t;
            init_by_A::ReadAdjacencyData(argparser, ut, nullptr, nullptr,
                    init_by_A::ParseU<edgestore_t>,
                    init_by_A::ParseU<edgestore_t>);
            ut->Filter();
            leaf->AddPool("UT", ut);
        } else {
            case_code = 11; // nothing
        }
    }
    return case_code;
}

void PrepareInitialization(const ArgParser &argparser) {
    if (argparser.Leaf() == LEAF_BUILDINGBLOCK) {
        // require B, N, U, UT
        std::unordered_set<std::string> missing_leaf;
        for (auto &item : Leaf::LEAF_SET) {
            if (not IsFile(argparser.DataFile(item))) {
                missing_leaf.insert(item);
            }
        }
        if (missing_leaf.size() > 0) {
            init_by_A::PrepareStart();
            _STORAGE_::Base<data_size_t> *storage = nullptr;
            edgestore_t bidirection, unidirection, ut;
            complement_t complement;
            storagebuilder_t builder;
            algebra::BuildBNUUT(argparser.DataFile(), &builder, &bidirection,
                    &complement);
            builder.CreateU(&unidirection);
            builder.CreateUT(&ut);
            for (auto &item : Leaf::LEAF_SET) {
                if (missing_leaf.count(item) > 0) {
                    if (item == "B") {
                        storage = &bidirection;
                    } else if (item == "N") {
                        storage = &complement;
                    } else if (item == "U") {
                        storage = &unidirection;
                    } else if (item == "UT") {
                        storage = &ut;
                    }
                    storage->WriteData(argparser, item);
                    init_by_A::PrepareItem(argparser.DataFile(item), storage);
                }
            }
            init_by_A::PrepareDone();
        }
    } else {
        if (not IsFile(argparser.DataFile("A"))) {
            init_by_A::PrepareStart();
            adjacency_t adjacency(argparser.DataFile());
            adjacency.WriteData(argparser, "A");
            init_by_A::PrepareItem(argparser.DataFile("A"), &adjacency);
            init_by_A::PrepareDone();
        }
    }
}

} // namespace algebra
