/*
 * baseoperand.hpp
 *
 *  Created on: 2020-1-22 9:16
 *      Author: Cao
 */

#ifndef ADJACENCY_OPERAND_BASEOPERAND_HPP_
#define ADJACENCY_OPERAND_BASEOPERAND_HPP_

#include "algebra/basetype.hpp"
#include <assert.h>
#include <iostream>


namespace algebra {

template<typename item_T>
class BaseOperand {
public:
    typedef T_1D<query_size_t> axis_t;
    typedef BaseOperand<item_T> BaseOperand_t;

    /*
     * pass owner = nullptr if itself owns data
     */
    BaseOperand(enum OPERATION operation, BaseOperand<item_T> *owner)
            : operation_(operation), reference_count_(1) {
        if (owner != nullptr) {
            this->owner_ = owner->GetOwner();
            this->IncreaseReferenceCount();
            assert(this->owner_ != this);
        } else {
            this->owner_ = this;
        }
        assert(this->reference_count_ == 1);
    }
    virtual ~BaseOperand() {
    }

    // delete copy
    BaseOperand(const BaseOperand<item_T> &) = delete;
    BaseOperand<item_T> &operator=(const BaseOperand<item_T> &) = delete;

    /*
     * resource release
     * low level reference sharing is allowed
     * in-place operation is not allowed
     * otherwise combine the operations into a single one
     */
    inline bool IsOwner() {
        return this == this->owner_;
    }
    bool ShouldDelete() {
        // handle all non-owner case
        if (!this->IsOwner()) {
            if (this->GetOwner()->ShouldDelete()) {
                delete this->GetOwner();
            }
        }
        // handle all owner case
        this->reference_count_--;
        if (this->reference_count_ < 1) {
            return true;
        }
        return false;
    }

    /*
     * override by derived class
     * can be called on a deleted derived class
     */
    // computation function
    virtual BaseOperand_t *Mask(BaseOperand_t *) {
        std::cout << this << ": unexpected BaseOperand.Mask()" << std::endl;
        assert(false);
        return nullptr;
    }
    virtual BaseOperand_t *Merge(BaseOperand_t *) {
        std::cout << this << ": unexpected BaseOperand.Merge()" << std::endl;
        assert(false);
        return nullptr;
    }
    virtual BaseOperand_t *Minus(BaseOperand_t *) {
        std::cout << this << ": unexpected BaseOperand.Minus()" << std::endl;
        assert(false);
        return nullptr;
    }
    virtual BaseOperand_t *Reduce(axis_t *) {
        std::cout << this << ": unexpected BaseOperand.Reduce()" << std::endl;
        assert(false);
        return nullptr;
    }
    virtual BaseOperand_t *Scale(scalar_t) {
        std::cout << this << ": unexpected BaseOperand.Scale()" << std::endl;
        assert(false);
        return nullptr;
    }
    virtual BaseOperand_t *Transpose(axis_t *) {
        std::cout << this << ": unexpected BaseOperand.Transpose()"
                << std::endl;
        assert(false);
        return nullptr;
    }
    // implementation specific function
    virtual void AddValue(item_T, item_T, item_T) {
        std::cout << this << ": unexpected BaseOperand.AddValue()" << std::endl;
        assert(false);
    }
    virtual size_type MatchCount() {
        // subgrpah matching result count
        std::cout << this << ": unexpected BaseOperand.MatchCount()"
                << std::endl;
        assert(false);
        return 0;
    }
    virtual size_type MatrixElementSum() {
        // motif adjacency matrix element sum
        std::cout << this << ": unexpected BaseOperand.MatrixElementSum()"
                << std::endl;
        assert(false);
        return 0;
    }
    virtual T_1D<item_T> *NextAt(size_type) = 0;
    virtual void Print() {
        std::cout << this << ": unexpected BaseOperand.Print()" << std::endl;
        assert(false);
    }
    virtual BaseOperand_t *ShallowCopy() = 0;
    virtual std::string Size2String() = 0;
    virtual void WriteData(const std::string &) = 0;

protected:
    /*
     * determine what to delete
     * operation that creates this, the operation type
     */
    const enum OPERATION operation_;

private:
    // handle delete
    inline void DecreaseReferenceCount() {
        this->GetOwner()->reference_count_--;
    }
    inline void IncreaseReferenceCount() {
        this->GetOwner()->reference_count_++;
    }
    inline BaseOperand_t *GetOwner() {
        if (this->IsOwner()) {
            return this;
        }
        return this->owner_->GetOwner();
    }

    // point to the owner, can point to self
    BaseOperand_t *owner_;
    /*
     * determine when to delete
     * number of times this->data_ is referenced
     * owner: >= 1 (this + shared copy)
     * non-owner: always 1 (this)
     */
    size_type reference_count_;
};

}

#endif /* ADJACENCY_OPERAND_BASEOPERAND_HPP_ */
