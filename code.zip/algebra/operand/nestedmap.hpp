/*
 * nestedmap.hpp
 *
 *  Created on: 2020-1-20 10:50
 *      Author: Cao
 */

#ifndef ADJACENCY_OPERAND_NESTEDMAP_HPP_
#define ADJACENCY_OPERAND_NESTEDMAP_HPP_

#include "algebra/basetype.hpp"
#include "algebra/operand/baseoperand.hpp"
#include "algebra/utility.hpp"
#include <algorithm>
#include <string>
#include <unordered_map>


namespace algebra {

template<typename item_T>
class NestedMap: public BaseOperand<item_T> {
public:
    typedef BaseOperand<item_T> BaseOperand_t;
    typedef std::unordered_map<item_T, item_T> col2count;
    typedef std::unordered_map<item_T, col2count *> data_t;

    NestedMap(enum OPERATION, BaseOperand_t *);
    ~NestedMap();

    NestedMap<item_T> *Scale(scalar_t);
    static NestedMap<item_T> *Sum(T_1D<NestedMap<item_T> *> *argument);

    void AddValue(item_T, item_T, item_T);
    size_type MatrixElementSum();
    inline T_1D<item_T> *NextAt(size_type cursor) {
        // read row by row
        return nullptr;
    }
    void Print();
    inline NestedMap<item_T> *ShallowCopy() {
        return this;
    }
    inline std::string Size2String() {
        return "(" + std::to_string(this->MatrixElementSum()) + ")";
    }
    void WriteData(const std::string &);


    data_t *data_;

private:
    void Add(NestedMap<item_T> *);
};

namespace nmap {

template<typename map_T, typename item_T>
void AddMapKeySorted(const map_T &map, T_1D<item_T> &data_1D) {
    for (const auto &pair : map) {
        data_1D.push_back(pair.first);
    }
    std::sort(data_1D.begin(), data_1D.end());
}

} // namespace nmap

/*
 * in-place operation is not allowed
 * in-place destroy data sharing
 */
template<typename item_T>
NestedMap<item_T> *NestedMap<item_T>::Scale(scalar_t argument) {
    NestedMap<item_T> *result = new NestedMap<item_T>(SCALE_OP, nullptr);
    col2count *target_map;
    col2count *temp_map;
    for (auto row_col : (*this->data_)) {
        target_map = new col2count;
        SetMap(result->data_, row_col.first, target_map);
        for (auto col_val : (*GetMap(this->data_, row_col.first))) {
            temp_map = GetMap(this->data_, row_col.first);
            SetMap(target_map, row_col.first,
                    GetMap(temp_map, col_val.first) * argument);
        }
    }
    return result;
}

template<typename item_T>
NestedMap<item_T> *NestedMap<item_T>::Sum(T_1D<NestedMap<item_T> *> *argument) {
    NestedMap<item_T> *result = new NestedMap<item_T>(SUM_OP, nullptr);
    if (argument != nullptr) {
        for (const auto &item : *argument) {
            result->Add(item);
        }
    }
    return result;
}

template<typename item_T>
size_type NestedMap<item_T>::MatrixElementSum() {
    size_type count = 0;
    for (const auto &row2col : (*this->data_)) {
        for (const auto &col2count : (*row2col.second)) {
            count += col2count.second;
        }
    }
    return count;
}

template<typename item_T>
void NestedMap<item_T>::AddValue(item_T row, item_T col, item_T value) {
    if (this->data_->count(row) == 0) {
        SetMap(this->data_, row, new col2count);
    }
    if (GetMap(this->data_, row)->count(col) != 0) {
        value += GetMap(GetMap(this->data_, row), col);
    }
    SetMap(GetMap(this->data_, row), col, value);
}

template<typename item_T>
void NestedMap<item_T>::Print() {
    T_1D<item_T> row_vector;
    nmap::AddMapKeySorted(*this->data_, row_vector);
    std::cout << "=== NestedMap.Print(): begin ===" << std::endl;
    for (const item_T row : row_vector) {
        T_1D<item_T> col_vector;
        col2count *column = GetMap(this->data_, row);
        nmap::AddMapKeySorted(*column, col_vector);
        for (const item_T col : col_vector) {
            std::cout << row << "," << col << ":" << GetMap(column, col)
                    << std::endl;
        }
    }
    std::cout << "=== NestedMap.Print(): end ===" << std::endl;
}

template<typename item_T>
void NestedMap<item_T>::WriteData(const std::string &name) {
    WriteMap2D(*this->data_, name);
}

// private method
template<typename item_T>
void NestedMap<item_T>::Add(NestedMap<item_T> *other) {
    for (auto row_col : (*other->data_)) {
        for (auto col_value : (*row_col.second)) {
            this->AddValue(row_col.first, col_value.first, col_value.second);
        }
    }
}

template<typename item_T>
NestedMap<item_T>::~NestedMap() {
#ifndef NDEBUG
    std::cout << "~NestedMap: " << this << std::endl;
#endif
    DeleteMapValue(*this->data_);
    delete this->data_;
}

template<typename item_T>
NestedMap<item_T>::NestedMap(enum OPERATION operation, BaseOperand_t *owner)
        : BaseOperand<item_T>(operation, owner) {
#ifndef NDEBUG
    std::cout << "NestedMap Constructor: " << this << std::endl;
#endif
    this->data_ = new data_t;

}

} // namespace algebra

#endif /* ADJACENCY_OPERAND_NESTEDMAP_HPP_ */
