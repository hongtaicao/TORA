/*
 * relation.hpp
 *
 *  Created on: 2020-1-12 16:02
 *      Author: Hongtai Cao
 */

#ifndef ADJACENCY_OPERAND_RELATION_HPP_
#define ADJACENCY_OPERAND_RELATION_HPP_

#include "algebra/basetype.hpp"
#include "algebra/operand/baseoperand.hpp"
#include "algebra/operand/nestedmap.hpp"
#include "algebra/utility.hpp"
#include <algorithm>
#include <assert.h>
#include <cmath>
#include <limits>
#include <string>
#include <unordered_set>


namespace algebra {

/*
 * binary search / scanning
 * if the same header is short, then it is better just scanning
 *
 * transpose can be not materialized sometime
 * non-materialized tranpose needs to take care of binary search
 * because it is not sorted correctly
 */

// https://stackoverflow.com/a/9352338/11193802
// template class methods must be in header files
template<typename item_T>
class Relation: public BaseOperand<item_T> {
public:
    typedef typename BaseOperand<item_T>::axis_t axis_t;
    typedef typename BaseOperand<item_T>::BaseOperand_t BaseOperand_t;
    typedef NestedMap<item_T> matrix_t;

    Relation(enum OPERATION, BaseOperand_t *);
    virtual ~Relation();

    // operation
    static Relation<item_T> *Adjacency(T_2D<item_T> *);
    inline Relation<item_T> *Mask(BaseOperand_t *other) {
        return this->MaskSS(other);
    }
    Relation<item_T> *Merge(BaseOperand_t *);
    Relation<item_T> *Minus(BaseOperand_t *other) {
        return this->MinusSS(other);
    }
    static Relation<item_T> *NonEdge(BaseOperand_t *, BaseOperand_t *);
    matrix_t *Reduce(axis_t *);
    Relation<item_T> *Transpose(axis_t *);

    // other operation
    inline size_type MatchCount() {
        return this->data_->size();
    }
    inline T_1D<item_T> *NextAt(size_type cursor) {
        if (cursor < this->data_->size()) {
            return this->GetAt(cursor);
        }
        return nullptr;
    }
    void Print();
    inline Relation<item_T> *ShallowCopy() {
        Relation<item_T> *copy = new Relation<item_T>(ADJACENCY_OP, nullptr);
        copy->data_ = this->data_;
        return copy;
    }
    inline std::string Size2String() {
        size_type row = 0;
        size_type col = 0;
        if (this->data_ != nullptr) {
            row = this->data_->size();
            if (row > 0) {
                col = this->GetAt(0)->size();
            }
        }
        return "(" + std::to_string(row) + ", " + std::to_string(col) + ")";
    }
    void WriteData(const std::string &);

    /*
     * 1. delete this->data_ is handled by ShouldDelete()
     * 2. delete this->data_ is simple
     * 3. however, delete pointer inside this->data_ (content) is tricky
     * when Mask or Minus
     *     c = Mask(a, b) or c = Minus(a, b)
     *     special treatment on a because c share with a
     *     maintain a (Relation *) owner_ to the actual content owner
     * when other operations
     *     they own content and they should delete content
     *     (Relation *) owner_ is nullptr
     * 4 delete when the reference_count_ is < 1
     * 5 whether to delete content / this->data_ is determined by operation
     */
    T_2D<item_T> *data_;

    // following can be used in pipeline
    // MaskBB: (binary_search, binary_search)
    Relation<item_T> *MaskBB(BaseOperand_t *);
    void AddTailOfFrontTarget(const item_T &, std::unordered_set<item_T> &);
    void SetHeadAsFront(const item_T &);
    void SetTailAsFront(const item_T &);
    // MaskSB: (scan, binary_search)
    Relation<item_T> *MaskSB(BaseOperand_t *);
    bool BinarySearchHeadRange(const item_T &);
    bool BinarySearchTail(const item_T &);
    // MaskSS: (scan, scan)
    Relation<item_T> *MaskSS(BaseOperand_t *);
    bool ScanHead(const item_T &);
    // Merge
    bool BinarySearchInRight(const T_1D<item_T> &);
    // MinusSB (scan, binary search)
    Relation<item_T> *MinusSB(BaseOperand_t *);
    bool BinarySearch(const T_1D<item_T> &);
    // MinusSS (scan, scan)
    Relation<item_T> *MinusSS(BaseOperand_t *);
    bool Scan(const T_1D<item_T> &);

    // helper method for algebra
    inline void Initialize() {
        this->head_ = 0;
        this->tail_ = this->data_->size();
    }
    inline bool InRange() {
        return this->head_ < this->data_->size();
    }
    inline bool InRangeAt(size_type index) {
        return index < this->data_->size();
    }
    inline bool IsEmpty() {
        return this->data_->size() == 0;
    }
    inline item_T Back() {
        return this->Get()->back();
    }
    inline item_T BackAt(size_type pointer) {
        return this->GetAt(pointer)->back();
    }
    inline item_T Front() {
        return this->Get()->front();
    }
    inline item_T FrontAt(size_type pointer) {
        return this->GetAt(pointer)->front();
    }
    inline T_1D<item_T> *Get() {
        return this->GetAt(this->head_);
    }
    inline T_1D<item_T> *GetAt(size_type pointer) {
        return Get2D(this->data_, pointer);
    }

    size_type head_, tail_;
};

namespace rlt {

template<typename item_T>
int CompareVector(const T_1D<item_T> &a, const T_1D<item_T> &b) {
    assert(a.size() == b.size());
    for (size_type i = 0; i < a.size() && i < b.size(); i++) {
        if (a[i] < b[i]) {
            return -1;
        } else if (a[i] > b[i]) {
            return 1;
        }
    }
    return 0;
}

// https://stackoverflow.com/a/18783410/11193802
// struct: actual template argument deduction is postponed until known
struct AscendVector {
    template<typename item_1D_T>
    bool operator()(item_1D_T *a, item_1D_T *b) const {
        if (CompareVector(*a, *b) > 0) {
            return false;
        }
        return true;
    }
};

template<typename item_T>
int MergeCompare(const T_1D<item_T> &left_vec, const T_1D<item_T> &right_vec) {
    assert(left_vec.size() == right_vec.size());
    for (size_type i = 1; i < left_vec.size(); i++) {
        if (left_vec[i] < right_vec[i - 1]) {
            return -1;
        } else if (left_vec[i] > right_vec[i - 1]) {
            return 1;
        }
    }
    return 0;
}

} // namesapce rlt

template<typename item_T>
Relation<item_T> *Relation<item_T>::Adjacency(T_2D<item_T> *edgelist) {
    Relation<item_T> *result = new Relation<item_T>(ADJACENCY_OP, nullptr);
    std::sort(edgelist->begin(), edgelist->end(), rlt::AscendVector());
    result->data_ = edgelist;
    return result;
}

template<typename item_T>
Relation<item_T> *Relation<item_T>::MaskBB(BaseOperand_t *other) {
    // binary search / binary search
    Relation<item_T> *result = new Relation<item_T>(MASK_OP, this);
    Relation<item_T> *mask = (Relation<item_T> *) other;
    if (this->IsEmpty() || mask->IsEmpty()) {
        return result;
    }
    std::unordered_set<item_T> tail_set;
    this->Initialize();
    mask->Initialize();
    while (this->InRange() && mask->InRange()) {
        auto diff = this->Front() - mask->Front();
        if (diff < 0) {
            this->SetHeadAsFront(mask->Front());
        } else if (diff > 0) {
            mask->SetHeadAsFront(this->Front());
        } else {
            item_T target = this->Front();
            bool head_changed = (this->head_ == 0)
                    || (target != this->FrontAt(this->head_ - 1));
            if (head_changed) {
                mask->AddTailOfFrontTarget(target, tail_set);
            }
            if (tail_set.count(this->Back()) != 0) {
                result->data_->push_back(this->Get());
            }
            this->head_++;
        }
    }
    return result;
}

template<typename item_T>
Relation<item_T> *Relation<item_T>::MaskSB(BaseOperand_t *other) {
    // scan / binary search
    Relation<item_T> *result = new Relation<item_T>(MASK_OP, this);
    Relation<item_T> *mask = (Relation<item_T> *) other;
    mask->Initialize();
    for (size_type i = 0; this->InRangeAt(i); i++) {
        item_T target = this->FrontAt(i);
        bool same_head = (i > 0) && (target == this->FrontAt(i - 1));
        if (same_head || mask->BinarySearchHeadRange(target)) {
            if (mask->BinarySearchTail(this->BackAt(i))) {
                // left operand is hierarchical sorted,
                // the last axis is not sorted
                // therefore BinarySearchTail can't adjust search range
                // this if condition is not efficient
                // because it search over tails that contain duplicates
                result->data_->push_back(this->GetAt(i));
            }
        }
    }
    return result;
}

template<typename item_T>
Relation<item_T> *Relation<item_T>::MaskSS(BaseOperand_t *other) {
    // scan / scan
    Relation<item_T> *result = new Relation<item_T>(MASK_OP, this);
    Relation<item_T> *mask = (Relation<item_T> *) other;
    std::unordered_set<item_T> tail_set;
    this->Initialize();
    mask->Initialize();
    while (this->InRange()) {
        item_T target = this->Front();
        bool head_changed = (this->head_ == 0)
                || (target != this->FrontAt(this->head_ - 1));
        if (head_changed) {
            // need to clear tail
            tail_set.clear();
            if ((mask->InRange()) && (mask->ScanHead(target))) {
                mask->AddTailOfFrontTarget(target, tail_set);
                if (tail_set.count(this->Back()) != 0) {
                    result->data_->push_back(this->Get());
                }
            }
        } else {
            if (tail_set.count(this->Back()) != 0) {
                result->data_->push_back(this->Get());
            }
        }
        this->head_++;
    }
    return result;
}

template<typename item_T>
Relation<item_T> *Relation<item_T>::Merge(BaseOperand_t *other) {
    // scan / binary search
    Relation<item_T> *result = new Relation<item_T>(MERGE_OP, nullptr);
    Relation<item_T> *right = (Relation<item_T> *) other;
    for (const auto &left_vec : (*this->data_)) {
        // find range
        right->Initialize();
        if (right->BinarySearchInRight(*left_vec)) {
            while ((right->InRange())
                    && (!rlt::MergeCompare(*left_vec, *right->Get()))) {
                T_1D<item_T> *vector = new T_1D<item_T>(*left_vec);
                vector->push_back(right->Back());
                result->data_->push_back(vector);
                right->head_++;
            }
        }
    }
    return result;
}

template<typename item_T>
Relation<item_T> *Relation<item_T>::MinusSB(BaseOperand_t *other) {
    // scan / binary search
    Relation<item_T> *result = new Relation<item_T>(MINUS_OP, this);
    Relation<item_T> *right = (Relation<item_T> *) other;
    right->Initialize();
    for (const auto &it : (*this->data_)) {
        if (!right->BinarySearch(*it)) {
            result->data_->push_back(it);
        }
    }
    return result;
}

template<typename item_T>
Relation<item_T> *Relation<item_T>::MinusSS(BaseOperand_t *other) {
    // scan / scan
    Relation<item_T> *result = new Relation<item_T>(MINUS_OP, this);
    Relation<item_T> *right = (Relation<item_T> *) other;
    right->Initialize();
    for (const auto &it : (*this->data_)) {
        if (!right->Scan(*it)) {
            result->data_->push_back(it);
        }
    }
    return result;
}

template<typename item_T>
Relation<item_T> *Relation<item_T>::NonEdge(BaseOperand_t *adjacency,
        BaseOperand_t *ut) {
    Relation<item_T> *result = new Relation<item_T>(NONEDGE_OP, nullptr);
    result->data_ = ((Relation<item_T> *) adjacency)->data_;
    return result;
}

template<typename item_T>
typename Relation<item_T>::matrix_t *Relation<item_T>::Reduce(axis_t *axis) {
    matrix_t *result = new matrix_t(REDUCE_OP, nullptr);
    // early return
    if ((this->operation_ != NONEDGE_OP) && (this->data_->size() < 1)) {
        return result;
    }
    // reduce axis
    auto head = 0;
    auto tail = this->GetAt(0)->size() - 1;
    if (axis != nullptr) {
        head = axis->front();
        tail = axis->back();
    }
    for (const auto &vector : (*this->data_)) {
        result->AddValue(Get1D(vector, head), Get1D(vector, tail), 1);
    }
    return result;
}

template<typename item_T>
Relation<item_T> *Relation<item_T>::Transpose(axis_t *axis) {
    Relation<item_T> *result = new Relation<item_T>(TRANSPOSE_OP, nullptr);
    for (auto vector : (*this->data_)) {
        T_1D<item_T> *vec_t = new T_1D<item_T>();
        for (size_type i = 0; i < axis->size(); i++) {
            vec_t->push_back(Get1D(vector, Get1D(axis, i)));
        }
        result->data_->push_back(vec_t);
    }
    std::sort(result->data_->begin(), result->data_->end(),
            rlt::AscendVector());
    return result;
}

template<typename item_T>
void Relation<item_T>::Print() {
    std::cout << "=== Relation.Print(): begin ===" << std::endl;
    size_type counter = 1;
    for (const auto &sequence : (*this->data_)) {
        std::cout << counter << ": ";
        Print1D(*sequence);
        counter++;
    }
    std::cout << "=== Relation.Print(): end ===" << std::endl;
}

template<typename item_T>
void Relation<item_T>::WriteData(const std::string &name) {
    Write2D(*this->data_, name);
}

// private method
// MaskBB
template<typename item_T>
void Relation<item_T>::AddTailOfFrontTarget(const item_T &target,
        std::unordered_set<item_T> &tail) {
    tail.clear();
    while (this->InRange() && (this->Front() == target)) {
        tail.insert(this->Back());
        this->head_++;
    }
}

/*
 * assume front is sorted
 * binary search for the target value such that
 * pointer == this->data_->size()
 * or
 * this->data_->at(pointer)->front() >= target
 */
template<typename item_T>
void Relation<item_T>::SetHeadAsFront(const item_T &target) {
    auto middle = this->data_->size();
    auto tail = this->data_->size();
    // search for head
    while (this->head_ < tail) {
        middle = this->head_ + (tail - this->head_) / 2;
        if (this->FrontAt(middle) < target) {
            this->head_ = middle + 1;
        } else {
            tail = middle;
        }
    }
}

/*
 * assume data is not empty
 * assume front is sorted
 * assume target exists
 * binary search for the target value such that
 * this->data_->at(pointer - 1)->front() > target
 * and
 * this->data_->at(pointer)->front() > target
 */
template<typename item_T>
void Relation<item_T>::SetTailAsFront(const item_T &target) {
    auto head = this->head_;
    auto middle = this->head_;
    this->tail_ = this->data_->size();
    // search for tail
    while (head < this->tail_) {
        middle = head + (this->tail_ - head) / 2;
        if (this->FrontAt(middle) <= target) {
            head = middle + 1;
        } else {
            this->tail_ = middle;
        }
    }
}

// MaskSB
/*
 * mask: sorted on its first column
 * return true: mask[head, tail)[0] == value
 * return false: mask[head] > value && mask[head - 1] < value
 * edge cases: head == 0 or head == mask.size()
 */
template<typename item_T>
bool Relation<item_T>::BinarySearchHeadRange(const item_T &target) {
    auto middle = this->head_;
    auto temp = this->data_->size();
    // search for head
    while (this->head_ < temp) {
        middle = this->head_ + (temp - this->head_) / 2;
        if (this->FrontAt(middle) < target) {
            this->head_ = middle + 1;
        } else {
            temp = middle;
        }
    }
    if ((!this->InRange()) || (this->Front() != target)) {
        return false;
    }
    // search for tail
    temp = this->head_;
    this->tail_ = this->data_->size();
    while (temp < this->tail_) {
        middle = temp + (this->tail_ - temp) / 2;
        if (this->FrontAt(middle) <= target) {
            temp = middle + 1;
        } else {
            this->tail_ = middle;
        }
    }
    return true;
}

/*
 * binary search value in mask[head, tail)[-1]
 * mask has exactly 2 columns
 * mask is hierarchical sorted on 1st column, then 2nd column
 */
template<typename item_T>
bool Relation<item_T>::BinarySearchTail(const item_T &target) {
    if (this->head_ >= this->tail_) {
        return false;
    }
    assert(
            (this->tail_ >= 1)
                    || this->Front() == this->FrontAt(this->tail_ - 1));
    assert(
            (!this->InRangeAt(this->tail_))
                    || (this->Front() != this->FrontAt(this->tail_)));
    auto head = this->head_;
    auto tail = this->tail_;
    auto middle = this->head_;
    // search for head
    while (head < tail) {
        middle = head + (tail - head) / 2;
        if (this->BackAt(middle) < target) {
            head = middle + 1;
        } else {
            tail = middle;
        }
    }
    if ((this->InRangeAt(head)) && (this->BackAt(head) == target)) {
        return true;
    }
    return false;
}

// MaskSS
template<typename item_T>
bool Relation<item_T>::ScanHead(const item_T &target) {
    while (this->InRange() && this->Front() < target) {
        this->head_++;
    }
    if (this->InRange() && (this->Front() == target)) {
        return true;
    }
    return false;
}

// Merge
template<typename item_T>
bool Relation<item_T>::BinarySearchInRight(const T_1D<item_T> &left_vec) {
    auto middle = this->data_->size();
    auto tail = middle;
    // binary search for head
    while (this->head_ < tail) {
        middle = this->head_ + (tail - this->head_) / 2;
        if (rlt::MergeCompare(left_vec, *this->GetAt(middle)) > 0) {
            this->head_ = middle + 1;
        } else {
            tail = middle;
        }
    }
    if ((this->InRange()) && (!rlt::MergeCompare(left_vec, *this->Get()))) {
        return true;
    }
    // ensure right[head] is the smallest >= left_vec
    return false;
}

// MinusSB
template<typename item_T>
bool Relation<item_T>::BinarySearch(const T_1D<item_T> &vector) {
    size_type middle = this->head_;
    size_type tail = this->data_->size();
    int find = 0;
    while (this->head_ < tail) {
        middle = this->head_ + (tail - this->head_) / 2;
        find = rlt::CompareVector(*this->GetAt(middle), vector);
        if (find == 0) {
            this->head_ = middle;
            return true;
        } else if (find < 0) {
            this->head_ = middle + 1;
        } else {
            tail = middle;
        }
    }
    return false;
}

// MinusSS
template<typename item_T>
bool Relation<item_T>::Scan(const T_1D<item_T> &vector) {
    while (this->InRange() && rlt::CompareVector(*this->Get(), vector) < 0) {
        this->head_++;
    }
    if (this->InRange() && rlt::CompareVector(*this->Get(), vector) == 0) {
        return true;
    }
    return false;
}

template<typename item_T>
Relation<item_T>::~Relation() {
#ifndef NDEBUG
    std::cout << "~Relation: " << this << " OP: " << this->operation_
            << std::endl;
#endif
    switch (this->operation_) {
    case MERGE_OP:
    case TRANSPOSE_OP: {
        // in general these two types create their own copy
        DeleteContent(*this->data_);
        delete this->data_;
        break;
    }
    case MINUS_OP:
    case MASK_OP: {
        // these two types hold reference to others
        delete this->data_;
        break;
    }
    case ADJACENCY_OP:
    case NONEDGE_OP: {
        break;
    }
    default: {
        assert(false);
        break;
    }
    }
}

/*
 * owner = nullptr if itself owns data
 */
template<typename item_T>
Relation<item_T>::Relation(enum OPERATION operation, BaseOperand_t *owner)
        : BaseOperand<item_T>(operation, owner), data_(nullptr), head_(0),
          tail_(0) {
#ifndef NDEBUG
    std::cout << "Relation Constructor: " << this << " OP: "
            << static_cast<OPERATION>(operation) << std::endl;
#endif
    switch (operation) {
    case MASK_OP:
    case MERGE_OP:
    case MINUS_OP:
    case TRANSPOSE_OP: {
        // these result types create
        this->data_ = new T_2D<item_T>();
        break;
    }
    case ADJACENCY_OP:
    case NONEDGE_OP: {
        // these two results reference external data
        break;
    }
    default: {
        assert(false);
        break;
    }
    }
}

} //namespace algebra

#endif /* ADJACENCY_OPERAND_RELATION_HPP_ */
