/*
 * framework.hpp
 *
 *  Created on: 2020-3-22 2:32
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_FRAMEWORK_HPP_
#define ALGEBRA_FRAMEWORK_HPP_

#include "algebra/argparser.hpp"

namespace algebra {

int CommandMode(int argc, char *argv[]);

} // namespace algebra

#endif /* ALGEBRA_FRAMEWORK_HPP_ */
