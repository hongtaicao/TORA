/*
 * application.hpp
 *
 *  Created on: 2020-7-18 20:19
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_APPLICATION_HPP_
#define ALGEBRA_APPLICATION_HPP_

#include <regex>
#include <string>
#include <unordered_map>

#include "algebra/argparser.hpp"
#include "algebra/expression/basenode.hpp"
#include "algebra/expression/initialize.hpp"
#include "algebra/expression/leaf.hpp"
#include "algebra/expression/motifnode/motifnode.hpp"
#include "algebra/io/writer.hpp"
#include "algebra/utility/access.hpp"

namespace algebra {

/*
 * expression within the same application share node_index
 * each holds at most one adjacency and its subgraph expressions
 * each adjacency maps to one or more subgraph expressions depending on the
 * adjacency expression generation setting. ArgParser.Adj and ArgParser.Br
 * therefore subgraph is a one dimensional BaseNode container
 */
class Application {
public:
    typedef std::unordered_map<std::string, BaseNode *> node_index_t;

    Application()
            : adjacency_setting(0), adjacency(nullptr) {
    }
    ~Application() {
        /*
         * index_ hold all the unique BaseNode *
         * adjacency_ and subgraph_ only hold a subset BaseNode * of above
         */
        PRINT("~Application() " << this << " adjacency=" << this->adjacency);
        PRINTLINE(" subgraph=" << this->Subgraph());
        algebra::DeleteMapValue(this->node_index);
    }

    static bool Compare(const Application *, const Application *);

    int EvaluateLeaf(const ArgParser &);
    inline bool IsMergeN() const {
        return this->IsLeftMergeN() || this->IsRightMergeN();
    }
    inline bool IsLeftMergeN() const {
        // matches substring of (N
        return this->Match(std::regex("\\(N,"));
    }
    inline bool IsRightMergeN() const {
        // matches substring of (\w,N) or (\w+,N,
        return this->Match(std::regex("\\([\\w]+,N[\\)|,]"));
    }
    inline BaseNode *Subgraph() const {
        return this->subgraph_1D.front();
    }
    inline void Subgraph(BaseNode *subgraph) {
        this->subgraph_1D.push_back(subgraph);
    }

    size_type adjacency_setting;
    MotifBaseNode *adjacency; // adjacency
    std::string match_order; // subgraph match_order. useful for adjacency
    Leaf leaf; // leaf node in computation graph
    node_index_t node_index; // node in computation graph

private:
    inline bool Match(const std::regex &e) const {
        // matches substring of "N,"
        // matches substring of (\w,N)
        if (std::regex_search(this->Subgraph()->Expression(), e)) {
            return true;
        }
        return false;
    }
    T_1D<BaseNode *> subgraph_1D; // subgraph, contained owned by node_index
};

} // namespace algebra

#endif /* ALGEBRA_APPLICATION_HPP_ */
