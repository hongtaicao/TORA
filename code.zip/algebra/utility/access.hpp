/*
 * access.hpp
 *
 *  Created on: 2020-2-3 16:01
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_UTILITY_ACCESS_HPP_
#define ALGEBRA_UTILITY_ACCESS_HPP_

#include <algorithm>
#include <unordered_map>

#include "algebra/basetype.hpp"

namespace algebra {

// template<class T> equivalent
template<typename T>
void DeleteContent(T &container) {
    for (auto &it : container) {
        delete it;
    }
}

template<typename T>
void DeleteMapValue(T &map) {
    for (auto &it : map) {
        delete it.second;
    }
}

template<typename container_T, typename index_T>
inline typename container_T::value_type Get(container_T *a, index_T i) {
    return (*a)[i];
}

template<typename container_T, typename index_T>
inline auto Get(container_T *a, index_T i, index_T j) {
    return (*(*a)[i])[j];
}

template<typename key_T, typename value_T>
inline value_T &GetMap(std::unordered_map<key_T, value_T> *a,
        const key_T &key) {
    return (*a)[key];
}

template<typename map_T, typename key_T, typename value_T>
inline void SetMap(map_T *map, const key_T &key, const value_T &value) {
    (*map)[key] = value;
}

template<typename map_T, typename container_T>
void SortMapKey(const map_T &map, container_T &keylist) {
    for (const auto &pair : map) {
        keylist.push_back(pair.first);
    }
    std::sort(keylist.begin(), keylist.end());
}

template<typename set_T, typename container_T>
void SortSetItem(const set_T &set, container_T &item_1D) {
    for (const auto &item : set) {
        item_1D.push_back(item);
    }
    std::sort(item_1D.begin(), item_1D.end());
}

}

#endif /* ALGEBRA_UTILITY_ACCESS_HPP_ */
