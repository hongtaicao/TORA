/*
 * payload.hpp
 *
 * used for pass information between components
 *
 *  Created on: 2021-3-21 5:26
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_UTILITY_PAYLOAD_HPP_
#define ALGEBRA_UTILITY_PAYLOAD_HPP_

#include <string>
#include <unordered_map>
#include <vector>

#include "algebra/basetype.hpp"

namespace algebra {

class Payload {
public:
    // time cost
    double Cost(const std::string &) const;
    inline void Cost(const std::string &key, double value) {
        this->double_map_[key] = value;
    }
    inline const std::string &Expression() const {
        return this->expression_;
    }
    inline void Expression(const std::string &expression) {
        this->expression_ = expression;
    }
    // vertex match order
    inline const std::vector<query_size_t> &MatchOrder() const {
        return this->match_order_;
    }
    template<typename container_T>
    inline void MatchOrder(const container_T &order) {
        this->match_order_.assign(order.begin(), order.end());
    }

private:
    std::string expression_;
    std::unordered_map<std::string, double> double_map_;
    std::vector<query_size_t> match_order_;
};

} // namespace algebra

#endif /* ALGEBRA_UTILITY_PAYLOAD_HPP_ */
