/*
 * tostring.hpp
 *
 *  Created on: 2020-8-25 22:48
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_UTILITY_TOSTRING_HPP_
#define ALGEBRA_UTILITY_TOSTRING_HPP_

#include <algorithm>
#include <string>
#include <vector>

#include "algebra/utility/access.hpp"

namespace algebra {

template<typename container_T>
std::string OrderedStringJoin(const container_T &item_1D,
        const std::string &sep) {
    std::string expression = "";
    if (item_1D.size() == 0) {
        return expression;
    }
    for (auto &item : item_1D) {
        expression.append(sep);
        expression.append(item);
    }
    return expression.substr(1);
}

template<typename container_T>
std::string OrderedToString(const container_T &item_1D,
        const std::string &sep) {
    std::vector<std::string> string_1D;
    for (auto &item : item_1D) {
        string_1D.push_back(std::to_string(item));
    }
    return OrderedStringJoin(string_1D, sep);
}

template<typename container_T>
std::string OrderedToString(const container_T &item_1D) {
    return OrderedToString(item_1D, ",");
}

template<typename set_T>
std::string SetToString(const set_T &set) {
    std::vector<typename set_T::value_type> sorted_1D;
    SortSetItem(set, sorted_1D);
    return OrderedToString(sorted_1D, ",");
}

template<typename set_T>
std::string SetStringJoin(const set_T &set) {
    std::vector<typename set_T::value_type> sorted_1D;
    SortSetItem(set, sorted_1D);
    return OrderedStringJoin(sorted_1D, ",");
}

} // namespace algebra

#endif /* ALGEBRA_UTILITY_TOSTRING_HPP_ */
