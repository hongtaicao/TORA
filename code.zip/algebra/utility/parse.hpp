/*
 * parse.hpp
 *
 *  Created on: 2020-9-13 3:56
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_UTILITY_PARSE_HPP_
#define ALGEBRA_UTILITY_PARSE_HPP_

#include <string>
#include <vector>

#include "algebra/basetype.hpp"

namespace algebra {

size_type GetPairedBracketEnd(const std::string &, size_type, size_type);

inline std::string GetSubstr(const std::string &expression, size_type start,
        size_type end) {
    return expression.substr(start, end - start);
}

void ParseMaskAxis(std::vector<std::string> &, std::vector<std::string> &,
        const std::string &, size_type, size_type);

template<typename container_T>
void ParseAxis(container_T *axis, const std::string &expression) {
    // expression [], [1,2], [1,2,3], ...
    if (expression.size() > 2) {
        size_type head = 1;
        size_type i = 1;
        for (; i < expression.size() - 1; i++) {
            if (expression[i] == ',') {
                axis->push_back(
                        std::atoi(expression.substr(head, i - head).c_str()));
                head = i + 1;
            }
        }
        axis->push_back(std::atoi(expression.substr(head, i - head).c_str()));
    }
}

} // namespace algebra

#endif /* ALGEBRA_UTILITY_PARSE_HPP_ */
