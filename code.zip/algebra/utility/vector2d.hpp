/*
 * vertex2d.hpp
 *
 *  Created on: 2020-8-19 18:22
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_UTILITY_VECTOR2D_HPP_
#define ALGEBRA_UTILITY_VECTOR2D_HPP_

#include <algorithm>
#include <ostream>
#include <vector>

#include "algebra/graph/graph.hpp"
#include "algebra/graph/graphmatcher.hpp"
#include "algebra/utility/access.hpp"
#include "algebra/utility/compare.hpp"
#include "algebra/utility/tostring.hpp"

namespace algebra {

template<typename item_T>
class Vector2D {
public:
    typedef std::vector<item_T> vector_1D_t;
    typedef std::vector<vector_1D_t *> vector_2D_t;
    Vector2D() {
    }
    ~Vector2D() {
        DeleteContent(this->vector_2D_);
    }
    Vector2D(const Vector2D<item_T> &other) {
        for (const auto &item : other.vector_2D_) {
            this->vector_2D_.push_back(new vector_1D_t(*item));
        }
    }
    Vector2D<item_T> &operator=(const Vector2D<item_T> &) = delete;

    inline const vector_1D_t *At(const size_type index) const {
        return this->vector_2D_[index];
    }
    inline void CopyClearPartial() {
        this->CopyPartial();
        this->partial_.clear();
    }
    inline void CopyPartial() {
        this->vector_2D_.push_back(new vector_1D_t(this->partial_));
    }
    inline const vector_2D_t &Data() const {
        return this->vector_2D_;
    }
    inline size_type EntrySize() const {
        if (this->Size() == 0) {
            return 0;
        }
        return this->vector_2D_[0]->size();
    }
    template<typename size_T>
    inline const vector_1D_t *operator[](size_T index) const {
        return this->vector_2D_[index];
    }
    inline void PartialPopBack() {
        this->partial_.pop_back();
    }
    inline void PartialPushBack(const item_T item) {
        this->partial_.push_back(item);
    }
    inline size_type PartialSize() const {
        return this->partial_.size();
    }
    inline void PopBack() {
        this->vector_2D_.pop_back();
    }
    inline void PushBack(vector_1D_t *item_1D) {
        this->vector_2D_.push_back(item_1D);
    }
    inline size_type Size() const {
        return this->vector_2D_.size();
    }
    void Sort();
    void Write(std::ostream &) const;

private:
    vector_1D_t partial_;
    vector_2D_t vector_2D_;
};

template<typename item_T>
void Vector2D<item_T>::Write(std::ostream &out) const {
    for (auto &item : this->vector_2D_) {
        out << std::endl << algebra::OrderedToString(*item);
    }
    out << std::endl;
}

template<typename item_T>
void Vector2D<item_T>::Sort() {
    std::sort(this->vector_2D_.begin(), this->vector_2D_.end(),
            algebra::Compare1DAscend<vector_1D_t>);
}

}

#endif /* ALGEBRA_UTILITY_VECTOR2D_HPP_ */
