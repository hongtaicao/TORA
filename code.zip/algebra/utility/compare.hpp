/*
 * compare.hpp
 *
 *  Created on: 2020-7-20 18:40
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_UTILITY_COMPARE_HPP_
#define ALGEBRA_UTILITY_COMPARE_HPP_

#include "algebra/basetype.hpp"
#include "algebra/utility/access.hpp"

namespace algebra {

template<typename container_T>
bool Compare1DAscend(container_T *a, container_T *b) {
    if (a->size() == b->size()) {
        for (algebra::size_type i = 0; i < a->size(); i++) {
            auto left = algebra::Get(a, i);
            auto right = algebra::Get(b, i);
            if (left != right) {
                return left < right;
            }
        }
        // all item_T are the same
        return true;
    }
    return a->size() < b->size();
}

template<typename container_T>
bool Compare1DHeadAscend(container_T *a, container_T *b) {
    if (a->size() == b->size()) {
        if (a->size() > 0) {
            return a->front() < b->front();
        }
        // both size 0
        return true;
    }
    return a->size() < b->size();
}

template<typename container_T>
bool Equal1D(container_T *a, container_T *b) {
    if (a->size() == b->size()) {
        for (algebra::size_type i = 0; i < a->size(); i++) {
            if (algebra::Get(a, i) != algebra::Get(b, i)) {
                return false;
            }
        }
        return true;
    }
    return false;
}

} // namespace algebra

#endif /* ALGEBRA_UTILITY_COMPARE_HPP_ */
