/*
 * payload.cpp
 *
 *  Created on: 2021-3-21 5:28
 *      Author: Hongtai Cao
 */

#include <iostream>
#include <string>

#include "algebra/io/writer.hpp"
#include "algebra/utility/payload.hpp"

namespace algebra {

double Payload::Cost(const std::string &key) const {
    if (this->double_map_.count(key) == 0) {
        std::cout << "ArgParser::Cost() key not found [" << key << "]";
        std::cout << std::endl << "available candidate:";
        PrintMap(this->double_map_);
        throw;
    }
    return this->double_map_.at(key);
}

} // namespace algebra
