/*
 * parse.cpp
 *
 *  Created on: 2020-9-13 3:58
 *      Author: Hongtai Cao
 */

#include <assert.h>
#include <iostream>
#include <string>
#include <vector>

#include "algebra/basetype.hpp"
#include "algebra/utility/parse.hpp"

namespace algebra {

size_type GetPairedBracketEnd(const std::string &expression, size_type start,
        size_type stop) {
    size_type round = 0;
    size_type square = 0;
    for (; start < stop; start++) {
        const char match = expression[start];
        if (match == '(') {
            round++;
        } else if (match == ')') {
            round--;
        } else if (match == '[') {
            square++;
        } else if (match == ']') {
            square--;
        } else if (match == ',') {
            if ((round == 0) and (square == 0)) {
                break;
            }
        }
    }
    assert((round == 0) and (square == 0));
    // start is a comma or start is the next of the end of string
    return start;
}

void ParseMaskAxis(std::vector<std::string> &axis_str_1D,
        std::vector<std::string> &mask_str_1D, const std::string &expression,
        size_type start, size_type stop) {
    // find the first mask
    size_type comma = GetPairedBracketEnd(expression, start, stop);
    std::string axis = GetSubstr(expression, start, comma);
    // find the first transpose axis
    start = comma + 1;
    comma = GetPairedBracketEnd(expression, start, stop);
    std::string mask = GetSubstr(expression, start, comma);
    // loop for the remaining
    do {
        axis_str_1D.push_back(axis);
        mask_str_1D.push_back(mask);
        start = comma + 1;
        comma = GetPairedBracketEnd(expression, start, stop);
        axis = GetSubstr(expression, start, comma);
        if (axis.size() == 0) {
            break;
        }
        // this can throw out_of_range when axis is empty
        start = comma + 1;
        comma = GetPairedBracketEnd(expression, start, stop);
        mask = GetSubstr(expression, start, comma);
    } while (axis.size() > 0);
#ifndef NDEBUG
    for (size_type i = 0; i < mask_str_1D.size(); i++) {
        std::cout << " " << axis_str_1D[i] << " " << mask_str_1D[i];
    }
    std::cout << std::endl;
#endif
}

} // namespace algebra
