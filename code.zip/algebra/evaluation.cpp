/*
 * evaluation.cpp
 *
 *  Created on: 2020-4-6
 *      Author: Hongtai Cao
 */

#include <assert.h>
#include <string>
#include <vector>

#include "algebra/argparser.hpp"
#include "algebra/basetype.hpp"
#include "algebra/construction.hpp"
#include "algebra/evaluation.hpp"
#include "algebra/io/logger.hpp"
#include "algebra/io/writer.hpp"
#include "algebra/utility/access.hpp"
#include "algebra/utility/misc.hpp"

namespace algebra {
// public method
void Evaluation::EvaluateAdjacency() {
    size_type best_cursor = this->logger_detail_.Cursor();
    // builder
    Construction *builder = new Construction(this->argparser_);
    // time expression generation cost
    const timepoint_t &start = GetTimepoint();
    this->graph_ = new graph_t(this->argparser_.Query());
    builder->BuildAdjacency(*this->graph_);
    this->expression_cost_ = GetTimeCost(start);
    builder->SortApplication();
#ifndef NDEBUG
    builder->PrintExpression();
#endif
    if ((not (this->argparser_.IsBranchBound()
            or this->argparser_.IsExpression()))
            and (this->argparser_.Target() >= 0)) {
        // heuristic expression: evaluate a single target
        double cost = 0;
        this->ExecuteSingleAdjacency(builder,
                (size_type) this->argparser_.Target(), cost);
    } else {
        // evaluate multiple target
        this->ExecuteAdjacency(builder, best_cursor);
    }
    this->WriteLogger(best_cursor);
    delete builder;
}

void Evaluation::EvaluateSubgraphMatching() {
    size_type best_cursor = this->logger_detail_.Cursor();
    Construction *builder = new Construction(this->argparser_);
    // time expression generation cost
    const timepoint_t &start = GetTimepoint();
    this->graph_ = new graph_t(this->argparser_.Query());
    builder->BuildSubgraph(*this->graph_);
    this->expression_cost_ = GetTimeCost(start);
    builder->SortApplication();
#ifndef NDEBUG
    builder->PrintExpression();
#endif
    if (this->argparser_.Target() < 0) {
        // evaluate multiple target
        this->ExecuteInducedSubgraphMatching(builder, best_cursor);
    } else {
        // evaluate a single target
        double cost = 0;
        size_type target = (size_type) this->argparser_.Target();
        this->ExecuteSingleInducedSubgraphMatching(builder, target, cost);
        builder->GetApplication(target)->Subgraph()->EvaluateDone();
    }
    this->WriteLogger(best_cursor);
    delete builder;
}

void Evaluation::EvaluateExpression() {
    size_type index = 0;
    size_type best_cursor = this->logger_detail_.Cursor();
    Construction *builder = new Construction(this->argparser_);
    const timepoint_t &start_parse = GetTimepoint();
    builder->BuildExpression(this->argparser_.payload.Expression());
    this->expression_cost_ = GetTimeCost(start_parse); // no query read
    // evaluate leaf
    double total_cost = this->EvaluateLeaf(builder, index);
    // evaluate equation
    BaseNode *node = builder->GetApplication(index)->Subgraph();
    const timepoint_t &start_evaluate = GetTimepoint();
    storage_t *match = node->Evaluate();
    double cost = GetTimeCost(start_evaluate);
    total_cost += cost;
    size_type match_count = match->MatchCount();
    execution::ReportSubgraph(this->logger_detail_, this->argparser_, cost,
            total_cost, match_count, builder->GetApplication(0)->match_order,
            node->Expression());
    size_type sum = match->ElementSum();
    execution::ReportAdjacency(this->logger_detail_, cost, total_cost, sum,
            ConfigName(AdjacencyAlgorithm(this->argparser_.Adj(index))),
            ConfigName(BranchAlgorithm(this->argparser_.Br(index))),
            node->Expression());
    node->EvaluateDone();
    this->WriteLogger(best_cursor);
    delete builder;
}

// private method
// evaluate given index
double Evaluation::EvaluateConstruct(Construction *builder,
        const size_type index) {
    // record expression cost
    execution::ReportConstruction(this->logger_detail_, this->argparser_,
            this->expression_cost_, index, builder->ApplicationCount(),
            builder->GetApplication(index)->Subgraph()->Expression());
    return this->expression_cost_;
}

double Evaluation::EvaluateLeaf(Construction *builder, const size_type index) {
    // evaluate dependency
    double total_cost = this->EvaluateConstruct(builder, index);
    // evaluate leaf
    const timepoint_t &start = GetTimepoint();
    int case_code = builder->GetApplication(index)->EvaluateLeaf(
            this->argparser_);
    double cost = GetTimeCost(start);
    execution::ReportLeaf(this->logger_detail_, this->argparser_, cost,
            case_code);
    return total_cost + cost;
}

size_type Evaluation::ExecuteSingleInducedSubgraphMatching(
        Construction *builder, const size_type index, double &total_cost) {
    // evaluate leaf
    total_cost = this->EvaluateLeaf(builder, index);
    // evaluate equation
    BaseNode *subgraph_node = builder->GetApplication(index)->Subgraph();
    PRINT("EvaluateInducedSubgraphMatching index=" << index << " ");
    PRINTLINE(subgraph_node->Expression());
    /*
     * IsTransform: add additional columns to subgraph matching result
     */
    std::vector<double> cost_cumulated(1, 0.0);
    if (this->argparser_.IsTransform()) {
        // sample random sub_nodes and compute them
        for (size_type size = 3; size < subgraph_node->VertexSize(); size++) {
            BaseNode *sub_node = subgraph_node->Node(size);
            const timepoint_t &start = GetTimepoint();
            storage_t *graph = sub_node->Evaluate();
            double cost = GetTimeCost(start);
            cost_cumulated.push_back(cost_cumulated.back() + cost);
            total_cost += cost;
            execution::ReportSubnode(this->logger_detail_, cost, total_cost,
                    size, graph->MatchCount(), sub_node->Expression());
        }
    }
    const timepoint_t &start = GetTimepoint();
    storage_t *match = subgraph_node->Evaluate();
    double cost = GetTimeCost(start);
    size_type match_count = match->MatchCount();
    total_cost += cost;
    execution::ReportSubgraph(this->logger_detail_, this->argparser_, cost,
            total_cost, match_count,
            builder->GetApplication(index)->match_order,
            subgraph_node->Expression());
    /*
     * subgraph result can be later used for motif adjacency
     * should not call subgraph_node->EvaluateDone()
     * because it will be called in motif adjacency Evaluate()
     *
     * subgraph_node->EvaluateDone() should be called if no adjacency needed
     */
    if (this->argparser_.IsTransform()) {
        // compute the time saved percent
        std::vector<double> cost_saved;
        // should start from 1 because at(0) is 0
        for (size_type i = 1; i < cost_cumulated.size(); i++) {
            cost_saved.push_back(cost_cumulated[i] / total_cost);
        }
        execution::ReportSavePercent(this->logger_detail_, cost_saved);
    }
    return match_count;
}

size_type Evaluation::ExecuteSingleAdjacency(Construction *builder,
        const size_type index, double &total_cost) {
    // evaluate dependency
    this->ExecuteSingleInducedSubgraphMatching(builder, index, total_cost);
    // evaluate adjacency
    MotifBaseNode *query_node = builder->GetApplication(index)->adjacency;
    const timepoint_t &start = GetTimepoint();
    storage_t *adjacency = query_node->Evaluate();
    double cost = GetTimeCost(start);
    size_type sum;
    if (adjacency != nullptr) {
        // MotifNode
        sum = adjacency->ElementSum();
    } else {
        // other cases
        sum = query_node->Sum();
    }
    total_cost += cost;
    size_type setting = builder->GetApplication(index)->adjacency_setting;
    execution::ReportAdjacency(this->logger_detail_, cost, total_cost, sum,
            ConfigName(AdjacencyAlgorithm(this->argparser_.Adj(setting))),
            ConfigName(BranchAlgorithm(this->argparser_.Br(setting))),
            query_node->Expression());
    query_node->EvaluateDone();
    return sum;
}

// process target and find index to evaluate
size_type Evaluation::ExecuteInducedSubgraphMatching(Construction *builder,
        size_type &best_cursor) {
    double lowest_cost = -1;
    double total_cost = 0;
    size_type previous_count = 0;
    best_cursor = this->logger_detail_.Cursor();
    for (size_type index = 0; index < builder->ApplicationCount(); index++) {
        if (execution::ShouldSkip(this->argparser_.Target(), builder, index)) {
            continue;
        }
        size_type count = this->ExecuteSingleInducedSubgraphMatching(builder,
                index, total_cost);
        // compare result
        if (index == 0) {
            previous_count = count;
        } else {
            assert(previous_count == count);
        }
        // find lowest_cost
        if ((lowest_cost < 0) or (lowest_cost > total_cost)) {
            lowest_cost = total_cost;
            best_cursor = this->logger_detail_.Cursor() - 1;
        }
        /*
         * no adjacency needed
         * should call subgraph_node->EvaluateDone()
         */
        builder->GetApplication(index)->Subgraph()->EvaluateDone();
    }
    return previous_count;
}

size_type Evaluation::ExecuteAdjacency(Construction *builder,
        size_type &best_cursor) {
    bool is_heurist = not (this->argparser_.IsBranchBound()
            or this->argparser_.IsEvaluate());
    int target = this->argparser_.Target();
    double lowest_cost = -1;
    double total_cost = 0;
    size_type previous_count = 0;
    best_cursor = this->logger_detail_.Cursor();
    for (size_type index = 0; index < builder->ApplicationCount(); index++) {
        if (is_heurist and execution::ShouldSkip(target, builder, index)) {
            // heuristic expression: skip bad target
            continue;
        }
        size_type count = this->ExecuteSingleAdjacency(builder, index,
                total_cost);
        // compare result
        if (index == 0) {
            previous_count = count;
        } else {
            std::cout << GetCurrentTime() << " MotifAdjacencyCount Match="
                    << BOOL_STRING(previous_count == count) << " Index "
                    << index << "/" << builder->ApplicationCount() << " Count "
                    << count << std::endl;
            assert(previous_count == count);
        }
        // find lowest_cost
        if ((lowest_cost < 0) or (lowest_cost > total_cost)) {
            lowest_cost = total_cost;
            best_cursor = this->logger_detail_.Cursor() - 1;
        }
    }
    return previous_count;
}

Evaluation::Evaluation(ArgParser &parser)
        : argparser_(parser), logger_best_("best"), logger_detail_("detail") {
    // read query graph time
    // added: EvaluateAdjacency EvaluateSubgraphMatching
    // not added: EvaluateExpression
    this->expression_cost_ = 0;
    this->graph_ = nullptr;
    // open log file
    this->logger_best_.Start();
    this->logger_detail_.Start();
}

namespace execution {

void ReportAdjacency(Logger &logger, const double timecost,
        const double totalcost, const size_type sum,
        const std::string &adjacency_algorithm,
        const std::string &branch_algorithm, const std::string &expression) {
    logger.AddResult("cost_adjacency(s)", std::to_string(timecost));
    logger.AddResult("cost_adjacency_total(s)", std::to_string(totalcost));
    logger.AddResult("adjacency_MatrixElementSum", std::to_string(sum));
    logger.AddResult("adjacency_AdjacencyAlgorithm", adjacency_algorithm);
    logger.AddResult("adjacency_BranchAlgorithm", branch_algorithm);
    logger.AddResult("adjacency_Expression", expression);
    std::cout << GetCurrentTime() << " TimeCost " << timecost
            << " (s) TotalCost " << totalcost << " (s) ElementSum " << sum
            << " " << adjacency_algorithm << " " << branch_algorithm << " "
            << expression << std::endl;
}

void ReportConstruction(Logger &logger, const ArgParser &argparser,
        const double expression_cost, const size_type index,
        const size_type count, const std::string &subgraph_expression) {
    const std::string &time_stamp = GetCurrentTime();
    logger.AddResult("time", time_stamp);
    logger.AddResult("command", argparser.Command());
    logger.AddResult("data", argparser.DataFile());
    logger.AddResult("query", argparser.Query());
    logger.AddResult("cost_Expression(s)", std::to_string(expression_cost));
    logger.AddResult("construct_ExpressionCount", std::to_string(count));
    logger.AddResult("construct_ExpressionIndex", std::to_string(index));
    std::cout << time_stamp << " TimeCost " << expression_cost
            << " (s) Expression " << index << "/" << count << " "
            << argparser.Query() << " " << subgraph_expression << std::endl;
}

void ReportLeaf(Logger &logger, const ArgParser &argparser,
        const double timecost, const int case_code) {
    logger.AddResult("cost_leaf(s)", std::to_string(timecost));
    logger.AddResult("leaf_algorithm",
            ConfigName(LeafAlgorithm(argparser.Leaf())));
    logger.AddResult("filter_enable", BOOL_STRING(argparser.LeafFilter()));
    logger.AddResult("leaf_format",
            ConfigName(LeafFormat(argparser.LeafFormat())));
    logger.AddResult("leaf_case", std::to_string(case_code));
    std::cout << GetCurrentTime() << " TimeCost " << timecost << " (s) "
            << ConfigName(LeafAlgorithm(argparser.Leaf())) << " filter_enable="
            << BOOL_STRING(argparser.LeafFilter()) << " "
            << ConfigName(LeafFormat(argparser.LeafFormat())) << " case "
            << case_code << std::endl;
}

void ReportSavePercent(Logger &logger, const std::vector<double> &cost_saved) {
    std::cout << GetCurrentTime() << " TimeCostSaved";
    for (size_type i = 0; i < cost_saved.size(); i++) {
        size_type vertex_size = 3 + i;
        // optional columns start with ~
        logger.AddResult("~" + std::to_string(vertex_size) + "_cost_saved_%",
                std::to_string(cost_saved[i]));
        std::cout << " " << vertex_size << "=" << cost_saved[i];
    }
    std::cout << std::endl;
}

void ReportSubgraph(Logger &logger, const ArgParser &argparser,
        const double timecost, const double totalcost,
        const size_type match_count, const std::string &order,
        const std::string &expr) {
    const std::string algorithm = ConfigName(OperatorAlgorithm(argparser.Op()));
    double subgraph_oe = totalcost;
    if (argparser.IsBranchBound()) {
        subgraph_oe += argparser.payload.Cost("branchbound");
    }
    logger.AddResult("cost_subgraph(s)", std::to_string(timecost));
    logger.AddResult("cost_subgraph_total(s)", std::to_string(totalcost));
    logger.AddResult("cost_subgraph_oe(s)", std::to_string(subgraph_oe));
    logger.AddResult("subgraph_Expression", expr);
    logger.AddResult("subgraph_MatchCount", std::to_string(match_count));
    logger.AddResult("subgraph_MatchOrder", order);
    logger.AddResult("subgraph_OperatorAlgorithm", algorithm);
    std::cout << GetCurrentTime() << " TimeCost " << timecost
            << " (s) TotalCost " << totalcost << " (s) MatchCount "
            << match_count;
    if (argparser.IsBranchBound()) {
        std::cout << " TotalCost_OE " << subgraph_oe << " (s)";
    }
    std::cout << " " << argparser.Query() << " MatchOrder [" << order << "] "
            << algorithm << std::endl;
}

void ReportSubnode(Logger &logger, const double timecost,
        const double totalcost, const size_type vertex_size,
        const size_type match_count, const std::string &expr) {
    const std::string prefix = "~" + std::to_string(vertex_size) + "_";
    // optional columns start with ~
    logger.AddResult(prefix + "cost_subnode(s)", std::to_string(timecost));
    logger.AddResult(prefix + "cost_subnode_total(s)",
            std::to_string(totalcost));
    logger.AddResult(prefix + "subnode_VertexSize",
            std::to_string(vertex_size));
    logger.AddResult(prefix + "subnode_MatchCount",
            std::to_string(match_count));
    logger.AddResult(prefix + "subnode_Expression", expr);
    std::cout << GetCurrentTime() << " TimeCost " << timecost
            << " (s) TotalCost " << totalcost << " (s) Subnode VertexSize "
            << vertex_size << " MatchCount " << match_count << " " << expr
            << std::endl;
}

bool IsMergeN(int target, const Construction *builder, const size_type index) {
    // target = -1 enable this function
    if (target == -1) {
        if (builder->GetApplication(index)->IsMergeN()) {
            std::cout << "skip IsMergeN[" << index << "] "
                    << builder->GetApplication(index)->Subgraph()->Expression()
                    << std::endl;
            return true;
        }
    }
    return false;
}

bool IsLeftMergeN(int target, const Construction *builder,
        const size_type index) {
    // target = -2 enable this function
    if (target == -2) {
        if (builder->GetApplication(index)->IsLeftMergeN()) {
            std::cout << "skip IsLeftMergeN[" << index << "] "
                    << builder->GetApplication(index)->Subgraph()->Expression()
                    << std::endl;
            return true;
        }
    }
    return false;
}

bool NotMatchTarget(int target, size_type index) {
    // target >= 0 enable the skip logic
    if ((target >= 0) && ((size_type) target != index)) {
        PRINTLINE("Evaluation::NotMatchTarget() skip index=" << index);
        return true;
    }
    return false;
}

bool ShouldSkip(int target, const Construction *builder,
        const size_type index) {
    if (NotMatchTarget(target, index)) {
        return true;
    }
    if (IsMergeN(target, builder, index)) {
        return true;
    }
    if (IsLeftMergeN(target, builder, index)) {
        return true;
    }
    return false;
}

} // namespace execution

} // namespace algebra
