/*
 * application.cpp
 *
 *  Created on: 2020-7-18 20:24
 *      Author: Hongtai Cao
 */

#include <assert.h>
#include <iostream>

#include "algebra/application.hpp"
#include "algebra/argparser.hpp"
#include "algebra/basetype.hpp"
#include "algebra/expression/basenode.hpp"

namespace algebra {

int Application::EvaluateLeaf(const ArgParser &argparser) {
    if (argparser.Leaf() == LEAF_ADJACENCY_EVALUATE) {
        // read adjacency file and evaluate
        assert((this->node_index.count("A") > 0));
        // (1, X, X, 0, X), (1, X, X, 1, X)
        this->node_index["A"]->AssignCache(new adjacency_t(argparser), true);
    }
    return this->leaf.Build(argparser);
}

/*
 * https://stackoverflow.com/a/31305772/11193802
 * function definition, static means
 * function is scoped only to this file and can't be called from other places
 */
bool Application::Compare(const Application *a, const Application *b) {
    bool b_join_N = b->IsMergeN();
    // put non-join-N first
    if (a->IsMergeN()) {
        if (not b_join_N) {
            // only a_join_N
            return false;
        }
    } else if (b_join_N) {
        // only b_join_N
        return true;
    }
    // sort by subgraph equation
    return a->Subgraph()->Expression() < b->Subgraph()->Expression();
}

} // namespace algebra
