/*
 * logger.cpp
 *
 *  Created on: 2020-2-21 7:53
 *      Author: Hongtai Cao
 */

#include <assert.h>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

#include "algebra/basetype.hpp"
#include "algebra/io/logger.hpp"
#include "algebra/utility/access.hpp"

namespace algebra {

void Logger::CopyFrom(const Logger &source, const size_type cursor) {
    for (const auto &pair : source.column2list_) {
        this->AddResult(pair.first, pair.second[cursor]);
    }
}

void Logger::WriteContent(const index2column_t &index2column) {
    // verify all columns are the same length
    size_type max_row = 0;
    if (!this->column2list_.empty()) {
        max_row = this->column2list_.begin()->second.size();
    }
#ifndef NDEBUG
    for (const auto &pair : this->column2list_) {
        assert(max_row == pair.second.size());
    }
#endif
    // write result row by row
    for (size_type row = 0; row < max_row; row++) {
        // write first column
        column_t column = index2column.at(0);
        this->outfile_ << '"' << this->column2list_.at(column).at(row) << '"';
        // write remaining row
        for (size_type i = 1; i < index2column.size(); i++) {
            column = index2column.at(i);
            this->outfile_ << ",";
            this->outfile_ << '"' << this->column2list_.at(column).at(row)
                    << '"';
        }
        // write line end
        this->outfile_ << std::endl;
    }
}

void Logger::WriteHeader(const index2column_t &index2column) {
    if (index2column.empty()) {
        return;
    }
    // write first column
    this->outfile_ << '"' << index2column.at(0) << '"';
    // write remaining column
    for (size_type i = 1; i < index2column.size(); i++) {
        this->outfile_ << "," << '"' << index2column.at(i) << '"';
    }
    // write line end
    this->outfile_ << std::endl;
}

void Logger::WriteFile() {
    // build a map: column index -> column name
    index2column_t index2column;
    std::vector<std::string> name_list;
    algebra::SortMapKey(this->column2list_, name_list);
    for (const auto &name : name_list) {
        auto column = index2column.size();
        index2column[column] = name;
    }
    this->WriteHeader(index2column);
    this->WriteContent(index2column);
    // clean data
    this->column2list_.clear();
}

Logger::~Logger() {
    this->outfile_.close();
    std::cout << _ALGEBRA_VERSION_ << " stop logger: " << this->file_name_
            << std::endl;
}

} // namespace algebra
