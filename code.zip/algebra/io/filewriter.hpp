/*
 * filewriter.hpp
 *
 *  Created on: 2020-9-23 23:01
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_IO_FILEWRITER_HPP_
#define ALGEBRA_IO_FILEWRITER_HPP_

#include <fstream>
#include <string>
#include <vector>

namespace algebra {

class BinaryWriter {
public:
    BinaryWriter(const std::string &filepath) {
        this->file_.open(filepath, std::ios::out | std::ios::binary);
    }
    ~BinaryWriter() {
        this->file_.close();
    }
    template<typename item_T>
    inline BinaryWriter *Write(item_T &&a) {
        this->file_.write((char *) &a, sizeof(a));
        return this;
    }
    template<typename a_T, typename b_T>
    inline BinaryWriter *Write(a_T &&a, b_T &&b) {
        this->file_.write((char *) &a, sizeof(a));
        this->file_.write((char *) &b, sizeof(b));
        return this;
    }
    inline BinaryWriter *WriteNewline() {
        return this;
    }
    template<typename item_T>
    inline void WriteAll(std::vector<item_T> &data) {
        if (data.size() > 0) {
            this->file_.write((char *) &data[0], data.size() * sizeof(item_T));
        }
    }
private:
    std::ofstream file_;
};

class StreamWriter {
public:
    StreamWriter(const std::string &filepath) {
        this->file_.open(filepath, std::ios::out);
    }
    ~StreamWriter() {
        this->file_.close();
    }
    template<typename item_T>
    inline StreamWriter *Write(item_T &&a) {
        // << is used for text output
        this->file_ << a << " ";
        return this;
    }
    template<typename a_T, typename b_T>
    inline StreamWriter *Write(a_T &&a, b_T &&b) {
        this->file_ << a << " " << b << " ";
        return this;
    }
    inline StreamWriter *WriteNewline() {
        this->file_ << std::endl;
        return this;
    }
private:
    std::ofstream file_;
};

} // namespace algebra

#endif /* ALGEBRA_IO_FILEWRITER_HPP_ */
