/*
 * writer.hpp
 *
 *  Created on: 2020-5-14 14:47
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_IO_WRITER_HPP_
#define ALGEBRA_IO_WRITER_HPP_

#include <fstream>
#include <iostream>
#include <unordered_map>

#include "algebra/basetype.hpp"
#include "algebra/utility/access.hpp"

#ifndef NDEBUG
#define PRINT(x) std::cout << x
#define PRINTLINE(x) std::cout << x << std::endl
#else
#define PRINT(x) ((void)0)
#define PRINTLINE(x) ((void)0)
#endif

namespace algebra {

template<typename sequence_T>
void PrintAxis(size_type leading_space, const sequence_T &sequence) {
    while (leading_space > 0) {
        std::cout << " ";
        leading_space--;
    }
    std::cout << "[";
    for (const auto &item : sequence) {
        std::cout << item << ",";
    }
    std::cout << "]";
}

template<typename item_T>
void Print1D(const T_1D<item_T> &sequence) {
    for (const auto &item : sequence) {
        std::cout << item << " ";
    }
    std::cout << std::endl;
}

template<typename item_T>
void Print2D(const T_2D<item_T> &sequence) {
    for (const auto &item : sequence) {
        std::cout << "    ";
        Print1D(*item);
    }
    std::cout << std::endl;
}

template<typename key_T, typename value_T>
void PrintMap(const std::unordered_map<key_T, value_T> map) {
    T_1D<key_T> keylist;
    SortMapKey(map, keylist);
    for (const auto &key : keylist) {
        std::cout << key << ": " << map.at(key) << std::endl;
    }
}

template<typename item_T>
void Write2D(const T_2D<item_T> &sequence, const std::string &name) {
    std::ofstream outfile(name, std::ios::out);
    if (outfile.is_open()) {
        for (const auto &seq1D : sequence) {
            size_type i = 0;
            for (; i < seq1D->size() - 1; i++) {
                outfile << Get1D(seq1D, i) << ",";
            }
            outfile << Get1D(seq1D, i) << std::endl;
        }
        outfile << std::endl;
        outfile.close();
        std::cout << "write file: " << name << std::endl;
    } else {
        std::cout << "open file failed: " << name << std::endl;
    }
}

template<typename item_T>
void WriteMap2D(
        const std::unordered_map<item_T, std::unordered_map<item_T, item_T> *> &map2D,
        const std::string &name) {
    std::ofstream outfile(name, std::ios::out);
    if (outfile.is_open()) {
        T_1D<item_T> keylist, subkeylist;
        SortMapKey(map2D, keylist);
        for (const auto &key : keylist) {
            outfile << std::to_string(key) << ":";
            subkeylist.clear();
            SortMapKey(map2D, subkeylist);
            auto *submap = map2D.at(key);
            for (const auto &subkey : subkeylist) {
                outfile << " " << subkey << ":" << GetMap(submap, subkey);
            }
            outfile << std::endl;
        }
        outfile << std::endl;
        outfile.close();
        std::cout << "write file: " << name << std::endl;
    } else {
        std::cout << "open file failed: " << name << std::endl;
    }
}

} // namespace algebra

#endif /* ALGEBRA_IO_WRITER_HPP_ */
