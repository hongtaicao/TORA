/*
 * logger.hpp
 *
 *  Created on: 2020-2-20 16:35
 *      Author: Cao
 */

#ifndef ALGEBRA_IO_LOGGER_HPP_
#define ALGEBRA_IO_LOGGER_HPP_

#include <deque>
#include <fstream>
#include <iostream>
#include <string>
#include <unordered_map>

#include "algebra/basetype.hpp"
#include "algebra/utility/misc.hpp"

namespace algebra {

class Logger {
    typedef std::string column_t;
    typedef std::unordered_map<size_type, column_t> index2column_t;
    typedef std::string value_t;
    typedef std::deque<value_t> list_of_value_t;
    typedef std::unordered_map<column_t, list_of_value_t> column2list_t;

public:
    Logger(const std::string &name)
            : name_(name) {
    }
    ~Logger();

    inline void AddResult(const column_t &column, const value_t &value) {
        // store as: column name -> column value
        if (this->column2list_.count(column) == 0) {
            this->column2list_[column] = list_of_value_t();
        }
        this->column2list_[column].push_back(value);
    }
    void CopyFrom(const Logger &source, const size_type cursor);
    inline size_type Cursor() const {
        if (this->column2list_.empty()) {
            return 0;
        }
        return this->column2list_.begin()->second.size();
    }
    inline Logger *SetTime() {
        this->current_time_ = GetCurrentTime();
        return this;
    }
    inline Logger *Start() {
        // close file is in Destructor
        this->file_name_ = _ALGEBRA_VERSION_ + "-";
        if (this->current_time_.size() > 0) {
            this->file_name_ += (this->current_time_ + "-");
        }
        this->file_name_ += (this->name_ + ".csv");
        std::string status;
        if (IsFile(this->file_name_)) {
            status = "[append]";
            this->outfile_.open(this->file_name_,
                    std::ios::out | std::ios::app);
        } else {
            status = "[new]";
            this->outfile_.open(this->file_name_, std::ios::out);
        }
        std::cout << _ALGEBRA_VERSION_ << " start logger: " << status
                << this->file_name_ << std::endl;
        return this;
    }
    void WriteFile();

private:
    void WriteHeader(const index2column_t &);
    void WriteContent(const index2column_t &);

    column2list_t column2list_;

    std::ofstream outfile_;
    std::string current_time_;
    std::string file_name_;

    const std::string name_;
};

} // namespace algebra

#endif /* ALGEBRA_IO_LOGGER_HPP_ */
