/*
 * filereader.hpp
 *
 *  Created on: 2020-5-14 12:46
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_IO_FILEREADER_HPP_
#define ALGEBRA_IO_FILEREADER_HPP_

#include <fstream>
#include <stdio.h>
#include <string>
#include <vector>

namespace algebra {

class BinaryReader {
public:
    BinaryReader(const std::string &filepath) {
        this->file_.open(filepath, std::ios::in | std::ios::binary);
    }
    ~BinaryReader() {
        this->file_.close();
    }
    template<typename item_T>
    inline std::istream &Read(item_T &a) {
        return this->file_.read((char *) &a, sizeof(a));
    }
    template<typename a_T, typename b_T>
    inline bool Read(a_T &a, b_T &b) {
        if (bool(this->Read(a))) {
            return bool(this->Read(b));
        }
        return false;
    }
    template<typename item_T>
    void ReadAll(std::vector<item_T> &container) {
        // https://stackoverflow.com/a/6755132/11193802
        // Determine the file length
        this->file_.seekg(0, std::ios_base::end);
        std::size_t size = this->file_.tellg();
        this->file_.seekg(0, std::ios_base::beg);
        // Set size
        container.resize(size / sizeof(item_T));
        // Load the data
        this->file_.read((char*) &container[0], size);
    }
private:
    std::ifstream file_;
};

class StreamReader {
public:
    StreamReader(const std::string &filepath) {
        this->file_.open(filepath, std::ios::in);
    }
    ~StreamReader() {
        this->file_.close();
    }
    template<typename item_T>
    inline bool Read(item_T &a) {
        // >> is used for text input
        return bool(this->file_ >> a);
    }
    template<typename a_T, typename b_T>
    inline bool Read(a_T &a, b_T &b) {
        return bool(this->file_ >> a >> b);
    }

private:
    std::ifstream file_;
};

class TextReader {
public:
    TextReader(const std::string &filepath) {
        this->fd_ = std::fopen(filepath.c_str(), "r");
    }
    ~TextReader() {
        std::fclose(this->fd_);
    }
    inline bool Read(unsigned short &a) {
        return fscanf(this->fd_, "%hu", &a) == 1;
    }
    inline bool Read(unsigned int &a) {
        return fscanf(this->fd_, "%u", &a) == 1;
    }
    inline bool Read(unsigned short &a, unsigned short &b) {
        return fscanf(this->fd_, "%hu %hu", &a, &b) == 2;
    }
    inline bool Read(unsigned int &a, unsigned int &b) {
        return fscanf(this->fd_, "%u %u", &a, &b) == 2;
    }
    inline bool Read(unsigned int &a, unsigned long &b) {
        return fscanf(this->fd_, "%u %lu", &a, &b) == 2;
    }
    inline bool Read(unsigned long &a, unsigned int &b) {
        return fscanf(this->fd_, "%lu %u", &a, &b) == 2;
    }
    inline bool Read(unsigned int &a, unsigned long long &b) {
        return fscanf(this->fd_, "%u %llu", &a, &b) == 2;
    }
    inline bool Read(unsigned long long &a, unsigned int &b) {
        return fscanf(this->fd_, "%llu %u", &a, &b) == 2;
    }
    inline bool Read(unsigned long &a, unsigned long &b) {
        return fscanf(this->fd_, "%lu %lu", &a, &b) == 2;
    }
    inline bool Read(unsigned long &a, unsigned long long &b) {
        return fscanf(this->fd_, "%lu %llu", &a, &b) == 2;
    }
    inline bool Read(unsigned long long &a, unsigned long &b) {
        return fscanf(this->fd_, "%llu %lu", &a, &b) == 2;
    }
    inline bool Read(unsigned long long &a, unsigned long long &b) {
        return fscanf(this->fd_, "%llu %llu", &a, &b) == 2;
    }

private:
    FILE *fd_;
};

// #define the reader
// compile target using FileIO is smaller than StreamIO
typedef TextReader FileReader;

} // namespace algebra

#endif /* ALGEBRA_IO_FILEREADER_HPP_ */
