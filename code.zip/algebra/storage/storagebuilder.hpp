/*
 * storagebuilder.hpp
 *
 * create storage from pair
 *
 *  Created on: 2020-4-24 4:13
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_STORAGE_STORAGEBUILDER_HPP_
#define ALGEBRA_STORAGE_STORAGEBUILDER_HPP_

#include <unordered_map>
#include <unordered_set>

#include "algebra/storage/storage.hpp"

namespace algebra {

template<typename item_T>
class StorageBuilder {
    typedef std::unordered_set<item_T> value_t;
    typedef std::unordered_map<item_T, value_t> data_t;

public:
    StorageBuilder() {
    }

    StorageBuilder(const StorageBuilder<item_T> &) = delete;
    StorageBuilder<item_T> operator=(const StorageBuilder<item_T> &) = delete;

    // build UT into the given target
    Storage<item_T> *CreateB(Storage<item_T> *) const;
    Storage<item_T> *CreateU(Storage<item_T> *) const;
    Storage<item_T> *CreateUT(Storage<item_T> *) const;

    inline void Erase(const item_T &first, const item_T &second) {
        if (this->map_.count(first) > 0) {
            this->map_[first].erase(second);
        }
    }

    inline bool Has(const item_T &first, const item_T &second) {
        if (this->map_.count(first) == 0) {
            return false;
        }
        return this->map_[first].count(second) > 0;
    }

    inline void Insert(const item_T &first, const item_T &second) {
        if (this->map_.count(first) == 0) {
            this->map_[first] = value_t();
        }
        this->map_[first].insert(second);
    }

    data_t map_;
};

template<typename item_T>
Storage<item_T> *StorageBuilder<item_T>::CreateU(
        Storage<item_T> *target) const {
    for (const auto &pair : this->map_) {
        for (const auto item : pair.second) {
            target->Insert(pair.first, item);
        }
    }
    target->Sorted();
    return target;
}

template<typename item_T>
Storage<item_T> *StorageBuilder<item_T>::CreateUT(
        Storage<item_T> *target) const {
    for (const auto &pair : this->map_) {
        for (const auto &item : pair.second) {
            target->Insert(item, pair.first);
        }
    }
    target->Sorted();
    return target;
}

}

#endif /* ALGEBRA_STORAGE_STORAGEBUILDER_HPP_ */
