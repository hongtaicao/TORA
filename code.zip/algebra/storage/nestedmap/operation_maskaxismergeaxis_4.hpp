/*
 * operation_maskaxismergeaxis_4.hpp
 *
 *  Created on: 2020-10-09 19:20
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_STORAGE_NESTEDMAP_OPERATION_MASKAXISMERGEAXIS_4_HPP_
#define ALGEBRA_STORAGE_NESTEDMAP_OPERATION_MASKAXISMERGEAXIS_4_HPP_

#include "algebra/storage/nestedmap/operation_base.hpp"

namespace nestedmap_operation {

template<typename item_T>
Base<item_T> *MaskMerge0__2by3(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = right;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *right_1 = right->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            for (iterator_T<item_T> *pair_1 = left_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                for (iterator_T<item_T> *pair_2 = right_1->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                    Base<item_T> *right_2 = right_1->Value(pair_2->Key());
                    Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                    for (iterator_T<item_T> *pair_3 = right_2->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                        result_3->Insert(pair_3->Key());
                    }
                    result_2->InsertNonEmpty(pair_2->Key(), result_3);
                }
                result_1->InsertNonEmpty(pair_1->Key(), result_2);
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *Mask1_2Merge0__2by3(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &mask_1D) {
    Base<item_T> *mask_0 = (Base<item_T> *) mask_1D[0];
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = right;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *right_1 = right->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            Base<item_T> *larger_1 = left_1;
            Base<item_T> *smaller_1 = mask_0;
            SetLargerSmaller(larger_1, smaller_1);
            for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                if (larger_1->KeyMatch(pair_1->Key())) {
                    Base<item_T> *mask_0_tail = mask_0->Value(pair_1->Key());
                    Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                    Base<item_T> *larger_2 = mask_0_tail;
                    Base<item_T> *smaller_2 = right_1;
                    SetLargerSmaller(larger_2, smaller_2);
                    for (iterator_T<item_T> *pair_2 = smaller_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                        if (larger_2->KeyMatch(pair_2->Key())) {
                            Base<item_T> *right_2 = right_1->Value(pair_2->Key());
                            Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                            for (iterator_T<item_T> *pair_3 = right_2->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                                result_3->Insert(pair_3->Key());
                            }
                            result_2->InsertNonEmpty(pair_2->Key(), result_3);
                        }
                    }
                    result_1->InsertNonEmpty(pair_1->Key(), result_2);
                }
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *Mask1_3Merge0__2by3(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &mask_1D) {
    Base<item_T> *mask_0 = (Base<item_T> *) mask_1D[0];
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = right;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *right_1 = right->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            Base<item_T> *larger_1 = left_1;
            Base<item_T> *smaller_1 = mask_0;
            SetLargerSmaller(larger_1, smaller_1);
            for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                if (larger_1->KeyMatch(pair_1->Key())) {
                    Base<item_T> *mask_0_tail = mask_0->Value(pair_1->Key());
                    Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                    for (iterator_T<item_T> *pair_2 = right_1->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                        Base<item_T> *right_2 = right_1->Value(pair_2->Key());
                        Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                        Base<item_T> *larger_3 = mask_0_tail;
                        Base<item_T> *smaller_3 = right_2;
                        SetLargerSmaller(larger_3, smaller_3);
                        for (iterator_T<item_T> *pair_3 = smaller_3->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                            if (larger_3->KeyMatch(pair_3->Key())) {
                                result_3->Insert(pair_3->Key());
                            }
                        }
                        result_2->InsertNonEmpty(pair_2->Key(), result_3);
                    }
                    result_1->InsertNonEmpty(pair_1->Key(), result_2);
                }
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *Mask1_2__1_3Merge0__2by3(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &mask_1D) {
    Base<item_T> *mask_0 = (Base<item_T> *) mask_1D[0];
    Base<item_T> *mask_1 = (Base<item_T> *) mask_1D[1];
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = right;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *right_1 = right->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            Base<item_T> *larger_1 = left_1;
            Base<item_T> *smaller_1 = mask_0;
            SetLargerSmaller(larger_1, smaller_1);
            std::vector<Base<item_T> *> candidate_1;
            candidate_1.push_back(larger_1);
            larger_1 = mask_1;
            SetLargerSmaller(larger_1, smaller_1);
            candidate_1.push_back(larger_1);
            for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                if (KeyMatch(pair_1->Key(), candidate_1)) {
                    Base<item_T> *mask_0_tail = mask_0->Value(pair_1->Key());
                    Base<item_T> *mask_1_tail = mask_1->Value(pair_1->Key());
                    Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                    Base<item_T> *larger_2 = mask_0_tail;
                    Base<item_T> *smaller_2 = right_1;
                    SetLargerSmaller(larger_2, smaller_2);
                    for (iterator_T<item_T> *pair_2 = smaller_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                        if (larger_2->KeyMatch(pair_2->Key())) {
                            Base<item_T> *right_2 = right_1->Value(pair_2->Key());
                            Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                            Base<item_T> *larger_3 = mask_1_tail;
                            Base<item_T> *smaller_3 = right_2;
                            SetLargerSmaller(larger_3, smaller_3);
                            for (iterator_T<item_T> *pair_3 = smaller_3->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                                if (larger_3->KeyMatch(pair_3->Key())) {
                                    result_3->Insert(pair_3->Key());
                                }
                            }
                            result_2->InsertNonEmpty(pair_2->Key(), result_3);
                        }
                    }
                    result_1->InsertNonEmpty(pair_1->Key(), result_2);
                }
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *MaskMerge1__2by3(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    for (iterator_T<item_T> *pair_0 = left->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        Base<item_T> *left_1 = left->Value(pair_0->Key());
        Base<item_T> *result_1 = new NestedMapUniform<item_T>();
        Base<item_T> *larger_1 = left_1;
        Base<item_T> *smaller_1 = right;
        SetLargerSmaller(larger_1, smaller_1);
        for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
            if (larger_1->KeyMatch(pair_1->Key())) {
                Base<item_T> *right_1 = right->Value(pair_1->Key());
                Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                for (iterator_T<item_T> *pair_2 = right_1->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                    Base<item_T> *right_2 = right_1->Value(pair_2->Key());
                    Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                    for (iterator_T<item_T> *pair_3 = right_2->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                        result_3->Insert(pair_3->Key());
                    }
                    result_2->InsertNonEmpty(pair_2->Key(), result_3);
                }
                result_1->InsertNonEmpty(pair_1->Key(), result_2);
            }
        }
        result->InsertNonEmpty(pair_0->Key(), result_1);
    }
    return result;
}

template<typename item_T>
Base<item_T> *Mask0_2Merge1__2by3(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &mask_1D) {
    Base<item_T> *mask_0 = (Base<item_T> *) mask_1D[0];
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = mask_0;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *mask_0_tail = mask_0->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            Base<item_T> *larger_1 = left_1;
            Base<item_T> *smaller_1 = right;
            SetLargerSmaller(larger_1, smaller_1);
            for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                if (larger_1->KeyMatch(pair_1->Key())) {
                    Base<item_T> *right_1 = right->Value(pair_1->Key());
                    Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                    Base<item_T> *larger_2 = mask_0_tail;
                    Base<item_T> *smaller_2 = right_1;
                    SetLargerSmaller(larger_2, smaller_2);
                    for (iterator_T<item_T> *pair_2 = smaller_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                        if (larger_2->KeyMatch(pair_2->Key())) {
                            Base<item_T> *right_2 = right_1->Value(pair_2->Key());
                            Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                            for (iterator_T<item_T> *pair_3 = right_2->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                                result_3->Insert(pair_3->Key());
                            }
                            result_2->InsertNonEmpty(pair_2->Key(), result_3);
                        }
                    }
                    result_1->InsertNonEmpty(pair_1->Key(), result_2);
                }
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *Mask0_3Merge1__2by3(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &mask_1D) {
    Base<item_T> *mask_0 = (Base<item_T> *) mask_1D[0];
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = mask_0;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *mask_0_tail = mask_0->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            Base<item_T> *larger_1 = left_1;
            Base<item_T> *smaller_1 = right;
            SetLargerSmaller(larger_1, smaller_1);
            for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                if (larger_1->KeyMatch(pair_1->Key())) {
                    Base<item_T> *right_1 = right->Value(pair_1->Key());
                    Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                    for (iterator_T<item_T> *pair_2 = right_1->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                        Base<item_T> *right_2 = right_1->Value(pair_2->Key());
                        Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                        Base<item_T> *larger_3 = mask_0_tail;
                        Base<item_T> *smaller_3 = right_2;
                        SetLargerSmaller(larger_3, smaller_3);
                        for (iterator_T<item_T> *pair_3 = smaller_3->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                            if (larger_3->KeyMatch(pair_3->Key())) {
                                result_3->Insert(pair_3->Key());
                            }
                        }
                        result_2->InsertNonEmpty(pair_2->Key(), result_3);
                    }
                    result_1->InsertNonEmpty(pair_1->Key(), result_2);
                }
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *Mask0_2__0_3Merge1__2by3(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &mask_1D) {
    Base<item_T> *mask_0 = (Base<item_T> *) mask_1D[0];
    Base<item_T> *mask_1 = (Base<item_T> *) mask_1D[1];
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = mask_0;
    SetLargerSmaller(larger_0, smaller_0);
    std::vector<Base<item_T> *> candidate_0;
    candidate_0.push_back(larger_0);
    larger_0 = mask_1;
    SetLargerSmaller(larger_0, smaller_0);
    candidate_0.push_back(larger_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (KeyMatch(pair_0->Key(), candidate_0)) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *mask_0_tail = mask_0->Value(pair_0->Key());
            Base<item_T> *mask_1_tail = mask_1->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            Base<item_T> *larger_1 = left_1;
            Base<item_T> *smaller_1 = right;
            SetLargerSmaller(larger_1, smaller_1);
            for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                if (larger_1->KeyMatch(pair_1->Key())) {
                    Base<item_T> *right_1 = right->Value(pair_1->Key());
                    Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                    Base<item_T> *larger_2 = mask_0_tail;
                    Base<item_T> *smaller_2 = right_1;
                    SetLargerSmaller(larger_2, smaller_2);
                    for (iterator_T<item_T> *pair_2 = smaller_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                        if (larger_2->KeyMatch(pair_2->Key())) {
                            Base<item_T> *right_2 = right_1->Value(pair_2->Key());
                            Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                            Base<item_T> *larger_3 = mask_1_tail;
                            Base<item_T> *smaller_3 = right_2;
                            SetLargerSmaller(larger_3, smaller_3);
                            for (iterator_T<item_T> *pair_3 = smaller_3->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                                if (larger_3->KeyMatch(pair_3->Key())) {
                                    result_3->Insert(pair_3->Key());
                                }
                            }
                            result_2->InsertNonEmpty(pair_2->Key(), result_3);
                        }
                    }
                    result_1->InsertNonEmpty(pair_1->Key(), result_2);
                }
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *MaskMerge0__3by2(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = right;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *right_1 = right->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            for (iterator_T<item_T> *pair_1 = left_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                Base<item_T> *left_2 = left_1->Value(pair_1->Key());
                Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                for (iterator_T<item_T> *pair_2 = left_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                    Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                    for (iterator_T<item_T> *pair_3 = right_1->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                        result_3->Insert(pair_3->Key());
                    }
                    result_2->InsertNonEmpty(pair_2->Key(), result_3);
                }
                result_1->InsertNonEmpty(pair_1->Key(), result_2);
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *Mask1_3Merge0__3by2(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &mask_1D) {
    Base<item_T> *mask_0 = (Base<item_T> *) mask_1D[0];
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = right;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *right_1 = right->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            Base<item_T> *larger_1 = left_1;
            Base<item_T> *smaller_1 = mask_0;
            SetLargerSmaller(larger_1, smaller_1);
            for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                if (larger_1->KeyMatch(pair_1->Key())) {
                    Base<item_T> *left_2 = left_1->Value(pair_1->Key());
                    Base<item_T> *mask_0_tail = mask_0->Value(pair_1->Key());
                    Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                    for (iterator_T<item_T> *pair_2 = left_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                        Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                        Base<item_T> *larger_3 = mask_0_tail;
                        Base<item_T> *smaller_3 = right_1;
                        SetLargerSmaller(larger_3, smaller_3);
                        for (iterator_T<item_T> *pair_3 = smaller_3->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                            if (larger_3->KeyMatch(pair_3->Key())) {
                                result_3->Insert(pair_3->Key());
                            }
                        }
                        result_2->InsertNonEmpty(pair_2->Key(), result_3);
                    }
                    result_1->InsertNonEmpty(pair_1->Key(), result_2);
                }
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *Mask2_3Merge0__3by2(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &mask_1D) {
    Base<item_T> *mask_0 = (Base<item_T> *) mask_1D[0];
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = right;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *right_1 = right->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            for (iterator_T<item_T> *pair_1 = left_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                Base<item_T> *left_2 = left_1->Value(pair_1->Key());
                Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                Base<item_T> *larger_2 = left_2;
                Base<item_T> *smaller_2 = mask_0;
                SetLargerSmaller(larger_2, smaller_2);
                for (iterator_T<item_T> *pair_2 = smaller_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                    if (larger_2->KeyMatch(pair_2->Key())) {
                        Base<item_T> *mask_0_tail = mask_0->Value(pair_2->Key());
                        Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                        Base<item_T> *larger_3 = mask_0_tail;
                        Base<item_T> *smaller_3 = right_1;
                        SetLargerSmaller(larger_3, smaller_3);
                        for (iterator_T<item_T> *pair_3 = smaller_3->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                            if (larger_3->KeyMatch(pair_3->Key())) {
                                result_3->Insert(pair_3->Key());
                            }
                        }
                        result_2->InsertNonEmpty(pair_2->Key(), result_3);
                    }
                }
                result_1->InsertNonEmpty(pair_1->Key(), result_2);
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *Mask1_3__2_3Merge0__3by2(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &mask_1D) {
    Base<item_T> *mask_0 = (Base<item_T> *) mask_1D[0];
    Base<item_T> *mask_1 = (Base<item_T> *) mask_1D[1];
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = right;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *right_1 = right->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            Base<item_T> *larger_1 = left_1;
            Base<item_T> *smaller_1 = mask_0;
            SetLargerSmaller(larger_1, smaller_1);
            for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                if (larger_1->KeyMatch(pair_1->Key())) {
                    Base<item_T> *left_2 = left_1->Value(pair_1->Key());
                    Base<item_T> *mask_0_tail = mask_0->Value(pair_1->Key());
                    Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                    Base<item_T> *larger_2 = left_2;
                    Base<item_T> *smaller_2 = mask_1;
                    SetLargerSmaller(larger_2, smaller_2);
                    for (iterator_T<item_T> *pair_2 = smaller_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                        if (larger_2->KeyMatch(pair_2->Key())) {
                            Base<item_T> *mask_1_tail = mask_1->Value(pair_2->Key());
                            Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                            Base<item_T> *larger_3 = mask_0_tail;
                            Base<item_T> *smaller_3 = mask_1_tail;
                            SetLargerSmaller(larger_3, smaller_3);
                            std::vector<Base<item_T> *> candidate_3;
                            candidate_3.push_back(larger_3);
                            larger_3 = right_1;
                            SetLargerSmaller(larger_3, smaller_3);
                            candidate_3.push_back(larger_3);
                            for (iterator_T<item_T> *pair_3 = smaller_3->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                                if (KeyMatch(pair_3->Key(), candidate_3)) {
                                    result_3->Insert(pair_3->Key());
                                }
                            }
                            result_2->InsertNonEmpty(pair_2->Key(), result_3);
                        }
                    }
                    result_1->InsertNonEmpty(pair_1->Key(), result_2);
                }
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *MaskMerge1__3by2(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    for (iterator_T<item_T> *pair_0 = left->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        Base<item_T> *left_1 = left->Value(pair_0->Key());
        Base<item_T> *result_1 = new NestedMapUniform<item_T>();
        Base<item_T> *larger_1 = left_1;
        Base<item_T> *smaller_1 = right;
        SetLargerSmaller(larger_1, smaller_1);
        for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
            if (larger_1->KeyMatch(pair_1->Key())) {
                Base<item_T> *left_2 = left_1->Value(pair_1->Key());
                Base<item_T> *right_1 = right->Value(pair_1->Key());
                Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                for (iterator_T<item_T> *pair_2 = left_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                    Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                    for (iterator_T<item_T> *pair_3 = right_1->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                        result_3->Insert(pair_3->Key());
                    }
                    result_2->InsertNonEmpty(pair_2->Key(), result_3);
                }
                result_1->InsertNonEmpty(pair_1->Key(), result_2);
            }
        }
        result->InsertNonEmpty(pair_0->Key(), result_1);
    }
    return result;
}

template<typename item_T>
Base<item_T> *Mask0_3Merge1__3by2(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &mask_1D) {
    Base<item_T> *mask_0 = (Base<item_T> *) mask_1D[0];
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = mask_0;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *mask_0_tail = mask_0->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            Base<item_T> *larger_1 = left_1;
            Base<item_T> *smaller_1 = right;
            SetLargerSmaller(larger_1, smaller_1);
            for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                if (larger_1->KeyMatch(pair_1->Key())) {
                    Base<item_T> *left_2 = left_1->Value(pair_1->Key());
                    Base<item_T> *right_1 = right->Value(pair_1->Key());
                    Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                    for (iterator_T<item_T> *pair_2 = left_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                        Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                        Base<item_T> *larger_3 = mask_0_tail;
                        Base<item_T> *smaller_3 = right_1;
                        SetLargerSmaller(larger_3, smaller_3);
                        for (iterator_T<item_T> *pair_3 = smaller_3->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                            if (larger_3->KeyMatch(pair_3->Key())) {
                                result_3->Insert(pair_3->Key());
                            }
                        }
                        result_2->InsertNonEmpty(pair_2->Key(), result_3);
                    }
                    result_1->InsertNonEmpty(pair_1->Key(), result_2);
                }
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *Mask2_3Merge1__3by2(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &mask_1D) {
    Base<item_T> *mask_0 = (Base<item_T> *) mask_1D[0];
    Base<item_T> *result = new NestedMapUniform<item_T>();
    for (iterator_T<item_T> *pair_0 = left->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        Base<item_T> *left_1 = left->Value(pair_0->Key());
        Base<item_T> *result_1 = new NestedMapUniform<item_T>();
        Base<item_T> *larger_1 = left_1;
        Base<item_T> *smaller_1 = right;
        SetLargerSmaller(larger_1, smaller_1);
        for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
            if (larger_1->KeyMatch(pair_1->Key())) {
                Base<item_T> *left_2 = left_1->Value(pair_1->Key());
                Base<item_T> *right_1 = right->Value(pair_1->Key());
                Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                Base<item_T> *larger_2 = left_2;
                Base<item_T> *smaller_2 = mask_0;
                SetLargerSmaller(larger_2, smaller_2);
                for (iterator_T<item_T> *pair_2 = smaller_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                    if (larger_2->KeyMatch(pair_2->Key())) {
                        Base<item_T> *mask_0_tail = mask_0->Value(pair_2->Key());
                        Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                        Base<item_T> *larger_3 = mask_0_tail;
                        Base<item_T> *smaller_3 = right_1;
                        SetLargerSmaller(larger_3, smaller_3);
                        for (iterator_T<item_T> *pair_3 = smaller_3->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                            if (larger_3->KeyMatch(pair_3->Key())) {
                                result_3->Insert(pair_3->Key());
                            }
                        }
                        result_2->InsertNonEmpty(pair_2->Key(), result_3);
                    }
                }
                result_1->InsertNonEmpty(pair_1->Key(), result_2);
            }
        }
        result->InsertNonEmpty(pair_0->Key(), result_1);
    }
    return result;
}

template<typename item_T>
Base<item_T> *Mask0_3__2_3Merge1__3by2(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &mask_1D) {
    Base<item_T> *mask_0 = (Base<item_T> *) mask_1D[0];
    Base<item_T> *mask_1 = (Base<item_T> *) mask_1D[1];
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = mask_0;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *mask_0_tail = mask_0->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            Base<item_T> *larger_1 = left_1;
            Base<item_T> *smaller_1 = right;
            SetLargerSmaller(larger_1, smaller_1);
            for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                if (larger_1->KeyMatch(pair_1->Key())) {
                    Base<item_T> *left_2 = left_1->Value(pair_1->Key());
                    Base<item_T> *right_1 = right->Value(pair_1->Key());
                    Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                    Base<item_T> *larger_2 = left_2;
                    Base<item_T> *smaller_2 = mask_1;
                    SetLargerSmaller(larger_2, smaller_2);
                    for (iterator_T<item_T> *pair_2 = smaller_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                        if (larger_2->KeyMatch(pair_2->Key())) {
                            Base<item_T> *mask_1_tail = mask_1->Value(pair_2->Key());
                            Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                            Base<item_T> *larger_3 = mask_0_tail;
                            Base<item_T> *smaller_3 = mask_1_tail;
                            SetLargerSmaller(larger_3, smaller_3);
                            std::vector<Base<item_T> *> candidate_3;
                            candidate_3.push_back(larger_3);
                            larger_3 = right_1;
                            SetLargerSmaller(larger_3, smaller_3);
                            candidate_3.push_back(larger_3);
                            for (iterator_T<item_T> *pair_3 = smaller_3->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                                if (KeyMatch(pair_3->Key(), candidate_3)) {
                                    result_3->Insert(pair_3->Key());
                                }
                            }
                            result_2->InsertNonEmpty(pair_2->Key(), result_3);
                        }
                    }
                    result_1->InsertNonEmpty(pair_1->Key(), result_2);
                }
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *MaskMerge2__3by2(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    for (iterator_T<item_T> *pair_0 = left->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        Base<item_T> *left_1 = left->Value(pair_0->Key());
        Base<item_T> *result_1 = new NestedMapUniform<item_T>();
        for (iterator_T<item_T> *pair_1 = left_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
            Base<item_T> *left_2 = left_1->Value(pair_1->Key());
            Base<item_T> *result_2 = new NestedMapUniform<item_T>();
            Base<item_T> *larger_2 = left_2;
            Base<item_T> *smaller_2 = right;
            SetLargerSmaller(larger_2, smaller_2);
            for (iterator_T<item_T> *pair_2 = smaller_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                if (larger_2->KeyMatch(pair_2->Key())) {
                    Base<item_T> *right_1 = right->Value(pair_2->Key());
                    Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                    for (iterator_T<item_T> *pair_3 = right_1->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                        result_3->Insert(pair_3->Key());
                    }
                    result_2->InsertNonEmpty(pair_2->Key(), result_3);
                }
            }
            result_1->InsertNonEmpty(pair_1->Key(), result_2);
        }
        result->InsertNonEmpty(pair_0->Key(), result_1);
    }
    return result;
}

template<typename item_T>
Base<item_T> *Mask0_3Merge2__3by2(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &mask_1D) {
    Base<item_T> *mask_0 = (Base<item_T> *) mask_1D[0];
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = mask_0;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *mask_0_tail = mask_0->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            for (iterator_T<item_T> *pair_1 = left_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                Base<item_T> *left_2 = left_1->Value(pair_1->Key());
                Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                Base<item_T> *larger_2 = left_2;
                Base<item_T> *smaller_2 = right;
                SetLargerSmaller(larger_2, smaller_2);
                for (iterator_T<item_T> *pair_2 = smaller_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                    if (larger_2->KeyMatch(pair_2->Key())) {
                        Base<item_T> *right_1 = right->Value(pair_2->Key());
                        Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                        Base<item_T> *larger_3 = mask_0_tail;
                        Base<item_T> *smaller_3 = right_1;
                        SetLargerSmaller(larger_3, smaller_3);
                        for (iterator_T<item_T> *pair_3 = smaller_3->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                            if (larger_3->KeyMatch(pair_3->Key())) {
                                result_3->Insert(pair_3->Key());
                            }
                        }
                        result_2->InsertNonEmpty(pair_2->Key(), result_3);
                    }
                }
                result_1->InsertNonEmpty(pair_1->Key(), result_2);
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *Mask1_3Merge2__3by2(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &mask_1D) {
    Base<item_T> *mask_0 = (Base<item_T> *) mask_1D[0];
    Base<item_T> *result = new NestedMapUniform<item_T>();
    for (iterator_T<item_T> *pair_0 = left->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        Base<item_T> *left_1 = left->Value(pair_0->Key());
        Base<item_T> *result_1 = new NestedMapUniform<item_T>();
        Base<item_T> *larger_1 = left_1;
        Base<item_T> *smaller_1 = mask_0;
        SetLargerSmaller(larger_1, smaller_1);
        for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
            if (larger_1->KeyMatch(pair_1->Key())) {
                Base<item_T> *left_2 = left_1->Value(pair_1->Key());
                Base<item_T> *mask_0_tail = mask_0->Value(pair_1->Key());
                Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                Base<item_T> *larger_2 = left_2;
                Base<item_T> *smaller_2 = right;
                SetLargerSmaller(larger_2, smaller_2);
                for (iterator_T<item_T> *pair_2 = smaller_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                    if (larger_2->KeyMatch(pair_2->Key())) {
                        Base<item_T> *right_1 = right->Value(pair_2->Key());
                        Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                        Base<item_T> *larger_3 = mask_0_tail;
                        Base<item_T> *smaller_3 = right_1;
                        SetLargerSmaller(larger_3, smaller_3);
                        for (iterator_T<item_T> *pair_3 = smaller_3->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                            if (larger_3->KeyMatch(pair_3->Key())) {
                                result_3->Insert(pair_3->Key());
                            }
                        }
                        result_2->InsertNonEmpty(pair_2->Key(), result_3);
                    }
                }
                result_1->InsertNonEmpty(pair_1->Key(), result_2);
            }
        }
        result->InsertNonEmpty(pair_0->Key(), result_1);
    }
    return result;
}

template<typename item_T>
Base<item_T> *Mask0_3__1_3Merge2__3by2(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &mask_1D) {
    Base<item_T> *mask_0 = (Base<item_T> *) mask_1D[0];
    Base<item_T> *mask_1 = (Base<item_T> *) mask_1D[1];
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = mask_0;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *mask_0_tail = mask_0->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            Base<item_T> *larger_1 = left_1;
            Base<item_T> *smaller_1 = mask_1;
            SetLargerSmaller(larger_1, smaller_1);
            for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                if (larger_1->KeyMatch(pair_1->Key())) {
                    Base<item_T> *left_2 = left_1->Value(pair_1->Key());
                    Base<item_T> *mask_1_tail = mask_1->Value(pair_1->Key());
                    Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                    Base<item_T> *larger_2 = left_2;
                    Base<item_T> *smaller_2 = right;
                    SetLargerSmaller(larger_2, smaller_2);
                    for (iterator_T<item_T> *pair_2 = smaller_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                        if (larger_2->KeyMatch(pair_2->Key())) {
                            Base<item_T> *right_1 = right->Value(pair_2->Key());
                            Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                            Base<item_T> *larger_3 = mask_0_tail;
                            Base<item_T> *smaller_3 = mask_1_tail;
                            SetLargerSmaller(larger_3, smaller_3);
                            std::vector<Base<item_T> *> candidate_3;
                            candidate_3.push_back(larger_3);
                            larger_3 = right_1;
                            SetLargerSmaller(larger_3, smaller_3);
                            candidate_3.push_back(larger_3);
                            for (iterator_T<item_T> *pair_3 = smaller_3->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                                if (KeyMatch(pair_3->Key(), candidate_3)) {
                                    result_3->Insert(pair_3->Key());
                                }
                            }
                            result_2->InsertNonEmpty(pair_2->Key(), result_3);
                        }
                    }
                    result_1->InsertNonEmpty(pair_1->Key(), result_2);
                }
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *MaskMerge0_1__3by3(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = right;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *right_1 = right->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            Base<item_T> *larger_1 = left_1;
            Base<item_T> *smaller_1 = right_1;
            SetLargerSmaller(larger_1, smaller_1);
            for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                if (larger_1->KeyMatch(pair_1->Key())) {
                    Base<item_T> *left_2 = left_1->Value(pair_1->Key());
                    Base<item_T> *right_2 = right_1->Value(pair_1->Key());
                    Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                    for (iterator_T<item_T> *pair_2 = left_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                        Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                        for (iterator_T<item_T> *pair_3 = right_2->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                            result_3->Insert(pair_3->Key());
                        }
                        result_2->InsertNonEmpty(pair_2->Key(), result_3);
                    }
                    result_1->InsertNonEmpty(pair_1->Key(), result_2);
                }
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *Mask2_3Merge0_1__3by3(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &mask_1D) {
    Base<item_T> *mask_0 = (Base<item_T> *) mask_1D[0];
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = right;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *right_1 = right->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            Base<item_T> *larger_1 = left_1;
            Base<item_T> *smaller_1 = right_1;
            SetLargerSmaller(larger_1, smaller_1);
            for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                if (larger_1->KeyMatch(pair_1->Key())) {
                    Base<item_T> *left_2 = left_1->Value(pair_1->Key());
                    Base<item_T> *right_2 = right_1->Value(pair_1->Key());
                    Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                    Base<item_T> *larger_2 = left_2;
                    Base<item_T> *smaller_2 = mask_0;
                    SetLargerSmaller(larger_2, smaller_2);
                    for (iterator_T<item_T> *pair_2 = smaller_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                        if (larger_2->KeyMatch(pair_2->Key())) {
                            Base<item_T> *mask_0_tail = mask_0->Value(pair_2->Key());
                            Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                            Base<item_T> *larger_3 = mask_0_tail;
                            Base<item_T> *smaller_3 = right_2;
                            SetLargerSmaller(larger_3, smaller_3);
                            for (iterator_T<item_T> *pair_3 = smaller_3->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                                if (larger_3->KeyMatch(pair_3->Key())) {
                                    result_3->Insert(pair_3->Key());
                                }
                            }
                            result_2->InsertNonEmpty(pair_2->Key(), result_3);
                        }
                    }
                    result_1->InsertNonEmpty(pair_1->Key(), result_2);
                }
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *MaskMerge0_2__3by3(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = right;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *right_1 = right->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            for (iterator_T<item_T> *pair_1 = left_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                Base<item_T> *left_2 = left_1->Value(pair_1->Key());
                Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                Base<item_T> *larger_2 = left_2;
                Base<item_T> *smaller_2 = right_1;
                SetLargerSmaller(larger_2, smaller_2);
                for (iterator_T<item_T> *pair_2 = smaller_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                    if (larger_2->KeyMatch(pair_2->Key())) {
                        Base<item_T> *right_2 = right_1->Value(pair_2->Key());
                        Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                        for (iterator_T<item_T> *pair_3 = right_2->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                            result_3->Insert(pair_3->Key());
                        }
                        result_2->InsertNonEmpty(pair_2->Key(), result_3);
                    }
                }
                result_1->InsertNonEmpty(pair_1->Key(), result_2);
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *Mask1_3Merge0_2__3by3(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &mask_1D) {
    Base<item_T> *mask_0 = (Base<item_T> *) mask_1D[0];
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = right;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *right_1 = right->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            Base<item_T> *larger_1 = left_1;
            Base<item_T> *smaller_1 = mask_0;
            SetLargerSmaller(larger_1, smaller_1);
            for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                if (larger_1->KeyMatch(pair_1->Key())) {
                    Base<item_T> *left_2 = left_1->Value(pair_1->Key());
                    Base<item_T> *mask_0_tail = mask_0->Value(pair_1->Key());
                    Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                    Base<item_T> *larger_2 = left_2;
                    Base<item_T> *smaller_2 = right_1;
                    SetLargerSmaller(larger_2, smaller_2);
                    for (iterator_T<item_T> *pair_2 = smaller_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                        if (larger_2->KeyMatch(pair_2->Key())) {
                            Base<item_T> *right_2 = right_1->Value(pair_2->Key());
                            Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                            Base<item_T> *larger_3 = mask_0_tail;
                            Base<item_T> *smaller_3 = right_2;
                            SetLargerSmaller(larger_3, smaller_3);
                            for (iterator_T<item_T> *pair_3 = smaller_3->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                                if (larger_3->KeyMatch(pair_3->Key())) {
                                    result_3->Insert(pair_3->Key());
                                }
                            }
                            result_2->InsertNonEmpty(pair_2->Key(), result_3);
                        }
                    }
                    result_1->InsertNonEmpty(pair_1->Key(), result_2);
                }
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *MaskMerge1_2__3by3(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    for (iterator_T<item_T> *pair_0 = left->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        Base<item_T> *left_1 = left->Value(pair_0->Key());
        Base<item_T> *result_1 = new NestedMapUniform<item_T>();
        Base<item_T> *larger_1 = left_1;
        Base<item_T> *smaller_1 = right;
        SetLargerSmaller(larger_1, smaller_1);
        for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
            if (larger_1->KeyMatch(pair_1->Key())) {
                Base<item_T> *left_2 = left_1->Value(pair_1->Key());
                Base<item_T> *right_1 = right->Value(pair_1->Key());
                Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                Base<item_T> *larger_2 = left_2;
                Base<item_T> *smaller_2 = right_1;
                SetLargerSmaller(larger_2, smaller_2);
                for (iterator_T<item_T> *pair_2 = smaller_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                    if (larger_2->KeyMatch(pair_2->Key())) {
                        Base<item_T> *right_2 = right_1->Value(pair_2->Key());
                        Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                        for (iterator_T<item_T> *pair_3 = right_2->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                            result_3->Insert(pair_3->Key());
                        }
                        result_2->InsertNonEmpty(pair_2->Key(), result_3);
                    }
                }
                result_1->InsertNonEmpty(pair_1->Key(), result_2);
            }
        }
        result->InsertNonEmpty(pair_0->Key(), result_1);
    }
    return result;
}

template<typename item_T>
Base<item_T> *Mask0_3Merge1_2__3by3(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &mask_1D) {
    Base<item_T> *mask_0 = (Base<item_T> *) mask_1D[0];
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = mask_0;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *mask_0_tail = mask_0->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            Base<item_T> *larger_1 = left_1;
            Base<item_T> *smaller_1 = right;
            SetLargerSmaller(larger_1, smaller_1);
            for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                if (larger_1->KeyMatch(pair_1->Key())) {
                    Base<item_T> *left_2 = left_1->Value(pair_1->Key());
                    Base<item_T> *right_1 = right->Value(pair_1->Key());
                    Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                    Base<item_T> *larger_2 = left_2;
                    Base<item_T> *smaller_2 = right_1;
                    SetLargerSmaller(larger_2, smaller_2);
                    for (iterator_T<item_T> *pair_2 = smaller_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                        if (larger_2->KeyMatch(pair_2->Key())) {
                            Base<item_T> *right_2 = right_1->Value(pair_2->Key());
                            Base<item_T> *result_3 = new NestedMapUniform<item_T>();
                            Base<item_T> *larger_3 = mask_0_tail;
                            Base<item_T> *smaller_3 = right_2;
                            SetLargerSmaller(larger_3, smaller_3);
                            for (iterator_T<item_T> *pair_3 = smaller_3->CreateIterator(); nestedmap::InRange(pair_3); pair_3->Advance()) {
                                if (larger_3->KeyMatch(pair_3->Key())) {
                                    result_3->Insert(pair_3->Key());
                                }
                            }
                            result_2->InsertNonEmpty(pair_2->Key(), result_3);
                        }
                    }
                    result_1->InsertNonEmpty(pair_1->Key(), result_2);
                }
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

} // namespace nesetedmap_operation

#endif /* ALGEBRA_STORAGE_NESTEDMAP_OPERATION_MASKAXISMERGEAXIS_4_HPP_ */
