/*
 * iterator.hpp
 *
 *  Created on: 2020-4-22 16:54
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_STORAGE_NESTEDMAP_ITERATOR_HPP_
#define ALGEBRA_STORAGE_NESTEDMAP_ITERATOR_HPP_

#include <unordered_map>

namespace nestedmap {

template<typename item_T>
class Base;

template<typename key_T, typename value_T>
class Iterator {
public:
    typedef std::unordered_map<key_T, value_T> data_t;
    virtual ~Iterator() {
    }
    /*
     * instance does not have polymorphism hence does not allow pure function
     *
     * pure virtual function allows only pointer declaration
     * to enable polymorphism
     */
    virtual void Advance() = 0;
    virtual bool InRange() const = 0;
    virtual key_T Key() const = 0;
    virtual value_T Value() = 0;
};

template<typename item_T>
inline bool InRange(Iterator<item_T, Base<item_T> *> *iterator) {
    if (iterator->InRange()) {
        return true;
    }
    // when iterator out of range
    delete iterator;
    return false;
}

}

#endif /* ALGEBRA_STORAGE_NESTEDMAP_ITERATOR_HPP_ */
