/*
 * operation_maskaxismergeaxis_3.hpp
 *
 *  Created on: 2020-10-09 19:20
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_STORAGE_NESTEDMAP_OPERATION_MASKAXISMERGEAXIS_3_HPP_
#define ALGEBRA_STORAGE_NESTEDMAP_OPERATION_MASKAXISMERGEAXIS_3_HPP_

#include "algebra/storage/nestedmap/operation_base.hpp"

namespace nestedmap_operation {

template<typename item_T>
Base<item_T> *MaskMerge0__2by2(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = right;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *right_1 = right->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            for (iterator_T<item_T> *pair_1 = left_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                for (iterator_T<item_T> *pair_2 = right_1->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                    result_2->Insert(pair_2->Key());
                }
                result_1->InsertNonEmpty(pair_1->Key(), result_2);
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *Mask1_2Merge0__2by2(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &mask_1D) {
    Base<item_T> *mask_0 = (Base<item_T> *) mask_1D[0];
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = right;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *right_1 = right->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            Base<item_T> *larger_1 = left_1;
            Base<item_T> *smaller_1 = mask_0;
            SetLargerSmaller(larger_1, smaller_1);
            for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                if (larger_1->KeyMatch(pair_1->Key())) {
                    Base<item_T> *mask_0_tail = mask_0->Value(pair_1->Key());
                    Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                    Base<item_T> *larger_2 = mask_0_tail;
                    Base<item_T> *smaller_2 = right_1;
                    SetLargerSmaller(larger_2, smaller_2);
                    for (iterator_T<item_T> *pair_2 = smaller_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                        if (larger_2->KeyMatch(pair_2->Key())) {
                            result_2->Insert(pair_2->Key());
                        }
                    }
                    result_1->InsertNonEmpty(pair_1->Key(), result_2);
                }
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *MaskMerge1__2by2(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    for (iterator_T<item_T> *pair_0 = left->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        Base<item_T> *left_1 = left->Value(pair_0->Key());
        Base<item_T> *result_1 = new NestedMapUniform<item_T>();
        Base<item_T> *larger_1 = left_1;
        Base<item_T> *smaller_1 = right;
        SetLargerSmaller(larger_1, smaller_1);
        for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
            if (larger_1->KeyMatch(pair_1->Key())) {
                Base<item_T> *right_1 = right->Value(pair_1->Key());
                Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                for (iterator_T<item_T> *pair_2 = right_1->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                    result_2->Insert(pair_2->Key());
                }
                result_1->InsertNonEmpty(pair_1->Key(), result_2);
            }
        }
        result->InsertNonEmpty(pair_0->Key(), result_1);
    }
    return result;
}

template<typename item_T>
Base<item_T> *Mask0_2Merge1__2by2(Base<item_T> *left, Base<item_T> *right, storage_1D_T<item_T> &mask_1D) {
    Base<item_T> *mask_0 = (Base<item_T> *) mask_1D[0];
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger_0 = left;
    Base<item_T> *smaller_0 = mask_0;
    SetLargerSmaller(larger_0, smaller_0);
    for (iterator_T<item_T> *pair_0 = smaller_0->CreateIterator(); nestedmap::InRange(pair_0); pair_0->Advance()) {
        if (larger_0->KeyMatch(pair_0->Key())) {
            Base<item_T> *left_1 = left->Value(pair_0->Key());
            Base<item_T> *mask_0_tail = mask_0->Value(pair_0->Key());
            Base<item_T> *result_1 = new NestedMapUniform<item_T>();
            Base<item_T> *larger_1 = left_1;
            Base<item_T> *smaller_1 = right;
            SetLargerSmaller(larger_1, smaller_1);
            for (iterator_T<item_T> *pair_1 = smaller_1->CreateIterator(); nestedmap::InRange(pair_1); pair_1->Advance()) {
                if (larger_1->KeyMatch(pair_1->Key())) {
                    Base<item_T> *right_1 = right->Value(pair_1->Key());
                    Base<item_T> *result_2 = new NestedMapUniform<item_T>();
                    Base<item_T> *larger_2 = mask_0_tail;
                    Base<item_T> *smaller_2 = right_1;
                    SetLargerSmaller(larger_2, smaller_2);
                    for (iterator_T<item_T> *pair_2 = smaller_2->CreateIterator(); nestedmap::InRange(pair_2); pair_2->Advance()) {
                        if (larger_2->KeyMatch(pair_2->Key())) {
                            result_2->Insert(pair_2->Key());
                        }
                    }
                    result_1->InsertNonEmpty(pair_1->Key(), result_2);
                }
            }
            result->InsertNonEmpty(pair_0->Key(), result_1);
        }
    }
    return result;
}

} // namespace nesetedmap_operation

#endif /* ALGEBRA_STORAGE_NESTEDMAP_OPERATION_MASKAXISMERGEAXIS_3_HPP_ */
