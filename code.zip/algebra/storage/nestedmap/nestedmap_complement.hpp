/*
 * nestedmap_complement.hpp
 *
 *  Created on: 2020-4-21 16:26
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_STORAGE_NESTEDMAP_NESTEDMAP_COMPLEMENT_HPP_
#define ALGEBRA_STORAGE_NESTEDMAP_NESTEDMAP_COMPLEMENT_HPP_

#include <assert.h>
#include <iostream>
#include <string>
#include <unordered_map>

#include "algebra/argparser.hpp"
#include "algebra/io/filereader.hpp"
#include "algebra/storage/nestedmap/base.hpp"
#include "algebra/storage/nestedmap/io.hpp"
#include "algebra/storage/nestedmap/iterator.hpp"
#include "algebra/storage/nestedmap/nestedmap.hpp"
#include "algebra/storage/storagebuilder.hpp"

namespace nestedmap {

/*
 * used as the last (second) level of N
 */
template<typename key_T, typename value_T>
class InnerComplementIterator: public Iterator<key_T, value_T> {
    typedef typename Iterator<key_T, value_T>::data_t data_t;

public:
    InnerComplementIterator(data_t &data, size_type vertex_count)
            : data_(data), vertex_count_(vertex_count) {
        this->vertex_ = 0;
        while (this->IsNotCandidate()) {
            this->vertex_++;
        }
    }
    virtual ~InnerComplementIterator() override {
    }
    inline void Advance() override {
        do {
            this->vertex_++;
        } while (this->IsNotCandidate());
    }
    virtual bool InRange() const override {
        return (this->vertex_ < this->vertex_count_);
    }
    inline key_T Key() const override {
        return this->vertex_;
    }
    inline value_T Value() override {
        // value of the last (second) level nestedmap is always nullptr
        return nullptr;
    }

private:
    inline bool IsNotCandidate() {
        // candidate: key not in data_
        if (this->data_.count(this->vertex_) > 0) {
            // not a candidate, return true
            return true;
        }
        return false;
    }

    data_t &data_;
    key_T vertex_;
    size_type vertex_count_;
};

/*
 * used as the first level of N
 */
template<typename key_T, typename value_T>
class ComplementIterator: public Iterator<key_T, value_T> {
    typedef typename Iterator<key_T, value_T>::data_t data_t;
    typedef typename data_t::iterator iterator;

public:
    ComplementIterator(data_t &data)
            : Iterator<key_T, value_T>() {
        this->iterator_ = data.begin();
        this->end_ = data.end();
        while (this->IsNotCandidate()) {
            this->iterator_++;
        }
    }
    virtual ~ComplementIterator() override {
    }
    inline void Advance() override {
        do {
            this->iterator_++;
        } while (this->IsNotCandidate());
    }
    virtual bool InRange() const override {
        return this->iterator_ != this->end_;
    }
    inline key_T Key() const override {
        return this->iterator_->first;
    }
    inline value_T Value() override {
        return this->iterator_->second;
    }

private:
    inline bool IsNotCandidate() {
        // only works for the first level nestedmap
        if (this->InRange()) {
            return !nestedmap::InRange(
                    this->iterator_->second->CreateIterator());
        }
        return false;
    }

    iterator iterator_;
    iterator end_;
};

/*
 * used as the last (second) level of N
 */
template<typename item_T>
class InnerComplement: public Base<item_T> {
public:
    typedef typename Base<item_T>::iterator_t iterator_t;

    InnerComplement(size_type vertex_count)
            : vertex_count_(vertex_count) {
    }
    virtual ~InnerComplement() override {
    }

    inline Base<item_T> *CreateInner(size_type) override {
        std::cout << "InnerComplement::CreateInner(size_type) should never call"
                << std::endl;
        throw;
    }
    inline iterator_t *CreateIterator() override {
        return new InnerComplementIterator<item_T, Base<item_T> *>(this->map_,
                this->vertex_count_);
    }
    Base<item_T> *DeepCopy() override;
    inline bool KeyMatch(const item_T &key) const override {
        return this->KeyExist(key) == false;
    }
    inline size_type LoopSize() const override {
        return this->vertex_count_ - this->DataSize();
    }
    inline void SetVertexCount(size_type vertex_count) {
        this->vertex_count_ = vertex_count;
    }
    inline Base<item_T> *Value(const item_T &) override {
        return nullptr;
    }
    inline size_type VertexCount() const override {
        return this->vertex_count_;
    }

private:
    size_type vertex_count_;
};

template<typename item_T>
Base<item_T> *InnerComplement<item_T>::DeepCopy() {
    InnerComplement<item_T> *result = new InnerComplement<item_T>(
            this->vertex_count_);
    for (auto &pair : this->map_) {
        result->Insert(pair.first);
    }
    return result;
}

/*
 * complement has 2 levels
 * 1st level is NestedMap, 2nd level is InnerComplement
 * this has a special iterator whose state depends on the inner iterator
 */
template<typename item_T>
class Complement: public Base<item_T> {
    typedef typename Base<item_T>::iterator_t iterator_t;

public:
    Complement()
            : vertex_count_(0) {
    }
    // ctor for read file
    Complement(const algebra::ArgParser &);
    // ctor for adjacency
    Complement(Storage<item_T> *, Storage<item_T> *);
    // ctor for building block
    Complement(Base<item_T> *, Base<item_T> *, Base<item_T> *);
    virtual ~Complement() override {
    }

    inline Base<item_T> *CreateInner(size_type vertex_count) override {
        return new InnerComplement<item_T>(vertex_count);
    }
    inline iterator_t *CreateIterator() override {
        return new ComplementIterator<item_T, Base<item_T> *>(this->map_);
    }
    Base<item_T> *DeepCopy() override;
    inline bool KeyMatch(const item_T &key) const override {
        return this->KeyExist(key);
    }
    inline size_type LoopSize() const override {
        return this->DataSize();
    }
    inline Base<item_T> *Value(const item_T &key) override {
        // this is nestedmap, each level value is Operation<item_T> *
        // get the Operation<item_T> * under the key
        assert(this->KeyExist(key));
        return this->map_[key];
    }
    inline size_type VertexCount() const override {
        return this->vertex_count_;
    }

    // additional construction method
    void AddEdgeFast(Base<item_T> *);
    void AddSelfLoop(size_type);
    void AddUFast(algebra::StorageBuilder<item_T> *);
    void InitializeWithSelfLoop(size_type);
    inline void InsertFast(item_T from_vertex, item_T to_vertex) {
        this->Value(from_vertex)->Insert(to_vertex);
    }

private:
    size_type vertex_count_;
};

namespace complement {

template<typename item_T>
void FindMaxVertex(Base<item_T> *source, item_T &max_vertex) {
    for (auto *it = source->CreateIterator(); nestedmap::InRange(it);
            it->Advance()) {
        if (it->Key() > max_vertex) {
            max_vertex = it->Key();
        }
    }
}

} // namespace complement

template<typename item_T>
void Complement<item_T>::AddEdgeFast(Base<item_T> *nestedmap) {
    // assume SelfLoop already added. this does not check existence
    for (iterator_t *first_pair = nestedmap->CreateIterator();
            nestedmap::InRange(first_pair); first_pair->Advance()) {
        for (iterator_t *second_pair = first_pair->Value()->CreateIterator();
                nestedmap::InRange(second_pair); second_pair->Advance()) {
            this->Value(first_pair->Key())->Insert(second_pair->Key());
        }
    }
}

template<typename item_T>
void Complement<item_T>::AddUFast(algebra::StorageBuilder<item_T> *builder) {
    for (const auto &pair : builder->map_) {
        for (const auto item : pair.second) {
            this->InsertFast(pair.first, item);
        }
    }
}

template<typename item_T>
void Complement<item_T>::AddSelfLoop(size_type vertex_count) {
    // class additional construction method
    this->vertex_count_ = vertex_count;
    for (item_T vertex = 0; vertex < vertex_count; vertex++) {
        if (this->KeyExist(vertex)) {
            auto *child_map = (InnerComplement<item_T> *) this->Value(vertex);
            child_map->SetVertexCount(vertex_count);
            child_map->Insert(vertex);
        } else {
            Base<item_T> *child_map = new InnerComplement<item_T>(vertex_count);
            child_map->Insert(vertex);
            this->Insert(vertex, child_map);
        }
    }
}

template<typename item_T>
void Complement<item_T>::InitializeWithSelfLoop(size_type vertex_count) {
    for (item_T vertex = 0; vertex < vertex_count; vertex++) {
        Base<item_T> *child_map = new InnerComplement<item_T>(vertex_count);
        child_map->Insert(vertex);
        this->Insert(vertex, child_map);
    }
}

template<typename item_T>
Base<item_T> *Complement<item_T>::DeepCopy() {
    Complement<item_T> *result = new Complement<item_T>;
    for (auto &pair : this->map_) {
        result->Insert(pair.first, pair.second->DeepCopy());
    }
    result->vertex_count_ = this->vertex_count_;
    return result;
}

template<typename item_T>
Complement<item_T>::Complement(const algebra::ArgParser &argparser) {
    ReadStorageData(argparser, argparser.DataFile("N"), this,
            this->vertex_count_);
    if ((argparser.LeafFormat() == algebra::LEAF_BINARY_PAIRLIST)
            or (argparser.LeafFormat() == algebra::LEAF_TEXT_PAIRLIST)
            or (argparser.LeafFormat() == algebra::LEAF_TEXT_PAIRLIST_ADJACENCY)) {
        for (auto &pair : this->map_) {
            ((InnerComplement<item_T> *) pair.second)->SetVertexCount(
                    this->vertex_count_);
        }
    }
}

template<typename item_T>
Complement<item_T>::Complement(Storage<item_T> *adj_, Storage<item_T> *ut_) {
    Adjacency<item_T> *adj = (Adjacency<item_T> *) adj_;
    NestedMapUniform<item_T> *ut = (NestedMapUniform<item_T> *) ut_;
    // should first add self loop
    this->vertex_count_ = adj->VertexCount();
    this->InitializeWithSelfLoop(adj->VertexCount());
    this->AddEdgeFast(adj);
    this->AddEdgeFast(ut);
}

template<typename item_T>
Complement<item_T>::Complement(Base<item_T> *b, Base<item_T> *u,
        Base<item_T> *ut) {
    item_T max_vertex = 0;
    complement::FindMaxVertex(b, max_vertex);
    complement::FindMaxVertex(u, max_vertex);
    complement::FindMaxVertex(ut, max_vertex);
    this->vertex_count_ = max_vertex + 1;
    this->InitializeWithSelfLoop(this->vertex_count_);
    this->AddEdgeFast(b);
    this->AddEdgeFast(u);
    this->AddEdgeFast(ut);
}

} // namespace nestedmap

#endif /* ALGEBRA_STORAGE_NESTEDMAP_NESTEDMAP_COMPLEMENT_HPP_ */
