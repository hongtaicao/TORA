/*
 * operation_maskaxismergeaxis.hpp
 *
 *  Created on: 2020-10-2 18:02
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_STORAGE_NESTEDMAP_OPERATION_MASKAXISMERGEAXIS_HPP_
#define ALGEBRA_STORAGE_NESTEDMAP_OPERATION_MASKAXISMERGEAXIS_HPP_

#include <algorithm>
#include <iostream>
#include <string>
#include <unordered_map>

#include "algebra/storage/nestedmap/operation_base.hpp"
#include "algebra/utility/access.hpp"
#include "algebra/utility/parse.hpp"
#include "algebra/utility/tostring.hpp"

namespace nestedmap {
template<typename item_T>
class NestedMapUniform;
}

namespace nestedmap_operation {

// https://www.learncpp.com/cpp-tutorial/78-function-pointers/
template<typename item_T>
using maskaxismergeaxis_function_T = Base<item_T> *(*)(Base<item_T> *, Base<item_T> *, storage_1D_T<item_T> &);

typedef std::unordered_map<std::string,
        maskaxismergeaxis_function_T<algebra::data_size_t>> f_map_t;

f_map_t InitializeMaskAxisMergeAxisMap();

// static declare and define (initialize). visible only in current file.
// extern declare but not define
extern f_map_t MASKAXISMERGEAXIS_MAP;
extern const std::string ATTRIBUTE_SEP;
extern const std::string AXIS_SEP;

template<typename item_T>
std::string Axis1DToString(axis_1D_T<item_T> &axis_1D) {
    std::string key = "";
    for (auto &axis : axis_1D) {
        key += (AXIS_SEP + algebra::OrderedToString(*axis, ATTRIBUTE_SEP));
    }
    return algebra::GetSubstr(key, 2, key.size());
}

template<typename item_T>
std::string MaskAxis1DToString(MaskAxis1D_T<item_T> &maskaxis_1D) {
    std::string key = "";
    if (maskaxis_1D.size() > 0) {
        key = algebra::OrderedToString(*maskaxis_1D[0]->axis_, ATTRIBUTE_SEP);
    }
    for (size_type i = 1; i < maskaxis_1D.size(); i++) {
        key += (AXIS_SEP
                + algebra::OrderedToString(*maskaxis_1D[i]->axis_,
                        ATTRIBUTE_SEP));
    }
    return key;
}

template<typename item_T>
Base<item_T> *cMaskAxisMergeAxis(Base<item_T> *left, axis_T<item_T> &merge_axis,
        Base<item_T> *right, axis_1D_T<item_T> &axis_1D,
        storage_1D_T<item_T> &mask_1D) {
#ifdef SKIP_REORDER
    std::string mask_axis = Axis1DToString<item_T>(axis_1D);
#else
    // reorder axis and mask by axis
    MaskAxis1D_T<item_T> maskaxis_1D;
    for (size_type i = 0; i < axis_1D.size(); i++) {
        maskaxis_1D.push_back(new MaskAxis<item_T>(mask_1D[i], axis_1D[i]));
    }
    std::sort(maskaxis_1D.begin(), maskaxis_1D.end(),
            MaskAxis<item_T>::Compare);
    std::string mask_axis = MaskAxis1DToString(maskaxis_1D);
    // update mask_1D
    mask_1D.clear();
    for (auto &maskaxis : maskaxis_1D) {
        mask_1D.push_back(maskaxis->mask_);
    }
    algebra::DeleteContent(maskaxis_1D);
#endif
    // find function name
    std::string key = "Mask" + mask_axis + "Merge"
            + algebra::OrderedToString(merge_axis, ATTRIBUTE_SEP) + AXIS_SEP
            + std::to_string(left->ColumnSize()) + "by"
            + std::to_string(right->ColumnSize());
    if (MASKAXISMERGEAXIS_MAP.count(key) > 0) {
        return MASKAXISMERGEAXIS_MAP[key](left, right, mask_1D);
    }
    std::cout << "operation_maskaxismergeaxis.hpp:"
            << " nestedmap_operation::cMaskAxisMergeAxis()"
            << " not supported: " << key << std::endl;
    return new NestedMapUniform<item_T>();
}

} // namespace nesetedmap_operation

#endif /* ALGEBRA_STORAGE_NESTEDMAP_OPERATION_MASKAXISMERGEAXIS_HPP_ */
