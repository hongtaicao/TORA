/*
 * axismask.hpp
 *
 *  Created on: 2020-9-18 15:17
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_STORAGE_NESTEDMAP_AXISMASK_HPP_
#define ALGEBRA_STORAGE_NESTEDMAP_AXISMASK_HPP_

#include <unordered_map>
#include <vector>

#include "algebra/basetype.hpp"
#include "algebra/storage/nestedmap/iterator.hpp"
#include "algebra/storage/storage.hpp"
#include "algebra/utility/access.hpp"

namespace nestedmap {
// forward declaration
template<typename item_T>
class Base;

template<typename item_T>
class NestedMapUniform;
}

namespace nestedmap_operation {

typedef algebra::size_type size_type;

template<typename item_T>
using Base = nestedmap::Base<item_T>;

template<typename key_T, typename value_T>
class MaskIterator: public nestedmap::Iterator<key_T, value_T> {
public:
    typedef std::vector<value_T> value_1D_t;

    /*
     * ctor type 1
     * this->operation_: need deletion
     * this->operation_1D_: is nullptr
     */
    MaskIterator(key_T key)
            : operation_1D_(nullptr) {
        this->operation_ = new nestedmap::NestedMapUniform<key_T>();
        this->operation_->Insert(key);
        this->iterator_ = this->operation_->CreateIterator();
        this->Initialize();
    }
    /*
     * ctor type 2
     * this->operation_: don't delete
     * this->operation_1D_: need deletion
     */
    MaskIterator(Base<key_T> *operation, value_1D_t *pool)
            : nestedmap::Iterator<key_T, value_T>(), operation_1D_(pool) {
        this->operation_ = operation;
        this->iterator_ = this->operation_->CreateIterator();
        this->Initialize();
    }
    virtual ~MaskIterator() override;
    void Advance() override;
    inline bool InRange() const override {
        return this->iterator_->InRange();
    }
    inline key_T Key() const override {
        return this->iterator_->Key();
    }
    inline value_T Value() override {
        std::cout << "MaskIterator.Value(): should never call" << std::endl;
        throw;
    }

private:
    bool IsInvalid();
    void Initialize();

    nestedmap::Iterator<key_T, value_T> *iterator_;
    Base<key_T> *operation_;
    value_1D_t *operation_1D_;
};

template<typename key_T, typename value_T>
MaskIterator<key_T, value_T>::~MaskIterator() {
    delete this->iterator_;
    if (this->operation_1D_ == nullptr) {
        // constructor type 1
        delete this->operation_;
    } else {
        // constructor type 2
        delete this->operation_1D_;
    }
}

template<typename key_T, typename value_T>
void MaskIterator<key_T, value_T>::Advance() {
    do {
        this->iterator_->Advance();
    } while (this->IsInvalid());
}

template<typename key_T, typename value_T>
bool MaskIterator<key_T, value_T>::IsInvalid() {
    if (this->InRange() and (this->operation_1D_ != nullptr)) {
        for (auto &item : (*this->operation_1D_)) {
            if (not item->KeyMatch(this->Key())) {
                // find a missing key: invalid
                return true;
            }
        }
    }
    return false;
}

template<typename key_T, typename value_T>
void MaskIterator<key_T, value_T>::Initialize() {
    while (this->IsInvalid()) {
        this->Advance();
    }
}

template<class value_T>
class AxisMask {
private:
    template<class key_T>
    class Item;

    typedef MaskIterator<value_T, Base<value_T> *> mask_iterator_t;
    typedef typename mask_iterator_t::value_1D_t value_1D_t;
    typedef typename algebra::Storage<value_T>::axis_2D_t axis_2D_t;
    typedef typename algebra::Storage<value_T>::storage_1D_t storage_1D_t;
    typedef algebra::T_1D<Item<value_T> *> item_1D_t;
    typedef std::unordered_map<size_type, item_1D_t *> axis2item_1D_t;
    // internal memory management
    typedef std::unordered_map<size_type, Item<value_T> *> axis2item_t;
    typedef std::vector<axis2item_t *> axis2item_t_1D_t;
public:
    /*
     * mask_1D: list of B, N, U, UT used, each appears at most once
     * axis_1D: axis list for B, N, U, UT in the same order of mask_1D
     * build axis to mask head and axis to mask tail
     * item ensures that tail changes accordingly to head value
     */
    AxisMask(storage_1D_t &, axis_2D_t &);
    ~AxisMask();

    typename Base<value_T>::iterator_t *CreateIterator(size_type);
    inline void EraseKeyAt(size_type axis) {
        this->axis2key_.erase(axis);
    }
    inline bool HasAxis(size_type axis) {
        return (this->axis2head_.count(axis) > 0)
                or (this->axis2tail_.count(axis) > 0);
    }
    // KeyMatch
    inline bool HasKeyAt(value_T, size_type);
    void SetKeyAt(value_T, size_type);
    // LoopSize
    inline size_type SizeAt(size_type);

private:
    inline void CreateAxis(axis2item_1D_t &map, size_type axis) {
        // new axis2head_
        if (map.count(axis) == 0) {
            map[axis] = new item_1D_t;
        }
    }
    Base<value_T> *FindSmallest(value_1D_t *, axis2item_1D_t &, size_type,
            bool);
    bool HasKey(value_T, size_type, axis2item_1D_t &, const bool);
    size_type Size(item_1D_t *, const bool);

    axis2item_1D_t axis2head_;
    axis2item_1D_t axis2tail_;
    // used for internal memory management
    axis2item_t_1D_t axis2item_t_1D_;
    // used for set key
    std::unordered_map<size_type, value_T> axis2key_;
};

template<typename value_T>
AxisMask<value_T>::AxisMask(storage_1D_t &mask_1D, axis_2D_t &axis_2D) {
    for (size_type i = 0; i < mask_1D.size(); i++) {
        Base<value_T> *op = (Base<value_T> *) mask_1D[i];
        axis2item_t *axis2item = new axis2item_t;
        for (const auto &axis : (*axis_2D[i])) {
            auto head = axis->front();
            if (axis2item->count(head) == 0) {
                // share mask operand if head axis are the same
                (*axis2item)[head] = new Item<value_T>(op);
            }
            // initialize internal state
            this->CreateAxis(this->axis2head_, head);
            this->CreateAxis(this->axis2tail_, axis->back());
            Item<value_T> *item = (*axis2item)[head];
            this->axis2head_[head]->push_back(item);
            this->axis2tail_[axis->back()]->push_back(item);
        }
        this->axis2item_t_1D_.push_back(axis2item);
    }
}

template<typename value_T>
AxisMask<value_T>::~AxisMask() {
    for (auto &map : this->axis2item_t_1D_) {
        algebra::DeleteMapValue(*map);
        delete map;
    }
}

template<typename value_T>
typename Base<value_T>::iterator_t *AxisMask<value_T>::CreateIterator(
        size_type axis) {
    // key is set for this axis
    if (this->axis2key_.count(axis) > 0) {
        return new mask_iterator_t(this->axis2key_[axis]);
    }
    // key is not set for this axis
    value_1D_t *pool = new value_1D_t;
    Base<value_T> *head = this->FindSmallest(pool, this->axis2head_, axis,
            true);
    Base<value_T> *tail = this->FindSmallest(pool, this->axis2tail_, axis,
            false);
    if (head == nullptr) {
        return new mask_iterator_t(tail, pool);
    } else if (tail == nullptr) {
        return new mask_iterator_t(head, pool);
    }
    if (head->LoopSize() < tail->LoopSize()) {
        pool->push_back(tail);
        return new mask_iterator_t(head, pool);
    } else {
        pool->push_back(head);
        return new mask_iterator_t(tail, pool);
    }
}

template<typename value_T>
Base<value_T> *AxisMask<value_T>::FindSmallest(value_1D_t *pool,
        axis2item_1D_t &map, size_type axis, bool is_head) {
    if (map.count(axis) == 0) {
        return nullptr;
    }
    item_1D_t *item_1D = map[axis];
    Item<value_T> *smallest = algebra::Get(item_1D, 0);
    for (size_type i = 1; i < item_1D->size(); i++) {
        if (algebra::Get(item_1D, i)->Size(is_head) < smallest->Size(is_head)) {
            pool->push_back(smallest->Get(is_head));
            smallest = algebra::Get(item_1D, i);
        } else {
            pool->push_back(algebra::Get(item_1D, i)->Get(is_head));
        }
    }
    return smallest->Get(is_head);
}

template<typename value_T>
inline bool AxisMask<value_T>::HasKeyAt(value_T key, size_type axis) {
    if (this->axis2key_.count(axis) > 0) {
        return this->axis2key_[axis] == key;
    }
    // check both head and tail
    if (this->HasKey(key, axis, this->axis2head_, true)
            and this->HasKey(key, axis, this->axis2tail_, false)) {
        return true;
    }
    return false;
}

template<typename value_T>
bool AxisMask<value_T>::HasKey(value_T key, size_type axis, axis2item_1D_t &map,
        const bool is_head) {
    if (map.count(axis) > 0) {
        for (auto &item : (*map[axis])) {
            if (not item->HasKey(key, is_head)) {
                return false;
            }
        }
    }
    return true;
}

template<typename value_T>
void AxisMask<value_T>::SetKeyAt(value_T key, size_type axis) {
    this->axis2key_[axis] = key;
    if (this->axis2head_.count(axis) > 0) {
        for (auto &item : (*this->axis2head_[axis])) {
            item->SetKey(key);
        }
    }
}

template<typename value_T>
inline size_type AxisMask<value_T>::SizeAt(size_type axis) {
    if (this->axis2key_.count(axis) > 0) {
        return 1;
    }
    if (this->axis2head_.count(axis) > 0) {
        if (this->axis2tail_.count(axis)) {
            return std::min(this->Size(this->axis2head_[axis], true),
                    this->Size(this->axis2tail_[axis], false));
        }
        return this->Size(this->axis2head_[axis], true);
    } else if (this->axis2tail_.count(axis)) {
        return this->Size(this->axis2tail_[axis], false);
    }
    std::cout << "AxisMask<value_T>::SizeAt():" << " invalid input axis="
            << axis << std::endl;
    throw;
}

template<typename value_T>
size_type AxisMask<value_T>::Size(item_1D_t *item_1D, const bool is_head) {
    size_type min_size = 0;
    if (item_1D->size() > 0) {
        min_size = algebra::Get(item_1D, 0)->Size(is_head);
    }
    for (size_type i = 1; i < item_1D->size(); i++) {
        min_size = std::min(min_size, algebra::Get(item_1D, i)->Size(is_head));
    }
    return min_size;
}

// AxisMask inner class
template<typename value_T>
template<typename key_T>
class AxisMask<value_T>::Item {
    // when head is fixed to a certain value, tail changes accordingly
public:
    Item(Base<key_T> *operation)
            : operation_(operation), tail_(nullptr) {
    }
    inline Base<key_T> *Get(const bool is_head) {
        if (is_head) {
            return this->operation_;
        }
        return this->tail_;
    }
    inline bool HasKey(const key_T &key, const bool is_head) {
        if (is_head) {
            return this->operation_->KeyMatch(key);
        }
        return this->tail_->KeyMatch(key);
    }
    inline void SetKey(const key_T &key) {
        this->tail_ = operation_->Value(key);
    }
    inline size_type Size(const bool is_head) {
        if (is_head) {
            return this->operation_->LoopSize();
        }
        return this->tail_->LoopSize();
    }
    Base<key_T> *operation_;
    Base<key_T> *tail_;
};

} // namespace nestedmap_operation

#endif /* ALGEBRA_STORAGE_NESTEDMAP_AXISMASK_HPP_ */
