/*
 * base.hpp
 *
 *  Created on: 2020-4-18 9:32
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_STORAGE_NESTEDMAP_BASE_HPP_
#define ALGEBRA_STORAGE_NESTEDMAP_BASE_HPP_

#include <algorithm>
#include <assert.h>
#include <deque>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

#include "algebra/argparser.hpp"
#include "algebra/basetype.hpp"
#include "algebra/io/filewriter.hpp"
#include "algebra/storage/convert/table2d.hpp"
#include "algebra/storage/nestedmap/io.hpp"
#include "algebra/storage/nestedmap/iterator.hpp"
#include "algebra/storage/nestedmap/operation.hpp"
#include "algebra/storage/nestedmap/operation_base.hpp"
#include "algebra/storage/nestedmap/operation_maskaxismergeaxis.hpp"
#include "algebra/storage/storage.hpp"
#include "algebra/utility/access.hpp"

namespace nestedmap {

typedef algebra::size_type size_type;

template<typename item_T>
using Storage = algebra::Storage<item_T>;

// forward declaration
// pointer to this types can be used. instance is incomplete type
template<typename item_T>
class NestedMapUniform;

template<typename item_T>
class Base: public Storage<item_T> {
    typedef typename Storage<item_T>::axis_t axis_t;
    // value must be a pointer of Operation<item_T> * to enable polymorphism
    typedef std::unordered_map<item_T, Base<item_T> *> map_t;

public:
    // this iterator is customized iterator
    typedef Iterator<item_T, Base<item_T> *> iterator_t;
    typedef typename Storage<item_T>::axis_1D_t axis_1D_t;
    typedef typename Storage<item_T>::axis_2D_t axis_2D_t;
    typedef typename Storage<item_T>::storage_1D_t storage_1D_t;
    typedef typename Storage<item_T>::storage_2D_t storage_2D_t;

    Base() {
    }
    virtual ~Base() override {
        algebra::DeleteMapValue(this->map_);
    }

    // override base class method
    inline Base<item_T> *Mask(Storage<item_T> *other) override {
        if (algebra::EmptyResult(this, other)) {
            return new NestedMapUniform<item_T>();
        }
        return nestedmap_operation::Mask(this, (Base<item_T> *) other);
    }
    inline Base<item_T> *MaskAxisMerge(Storage<item_T> *right,
            axis_2D_t &axis_2D, storage_1D_t &mask_1D) override {
        if (algebra::EmptyResult(this, right)
                or algebra::EmptyResult1D(mask_1D)) {
            return new NestedMapUniform<item_T>();
        }
        return nestedmap_operation::MaskAxisMerge(this, (Base<item_T> *) right,
                axis_2D, mask_1D);
    }
    inline Base<item_T> *MaskAxisMergeAxis(axis_t &merge_axis,
            Storage<item_T> *right, axis_2D_t &axis_2D, storage_1D_t &mask_1D)
                    override {
        if (algebra::EmptyResult(this, right)
                or algebra::EmptyResult1D(mask_1D)) {
            return new NestedMapUniform<item_T>();
        }
        return nestedmap_operation::MaskAxisMergeAxis(this, merge_axis,
                (Base<item_T> *) right, axis_2D, mask_1D);
    }
    inline Base<item_T> *cMaskAxisMergeAxis(axis_t &merge_axis,
            Storage<item_T> *right, axis_1D_t &axis_1D, storage_1D_t &mask_1D)
                    override {
        if (algebra::EmptyResult(this, right)
                or algebra::EmptyResult1D(mask_1D)) {
            return new NestedMapUniform<item_T>();
        }
        return nestedmap_operation::cMaskAxisMergeAxis(this, merge_axis,
                (Base<item_T> *) right, axis_1D, mask_1D);
    }
    inline Base<item_T> *Mask_Merge__by(Storage<item_T> *right,
            storage_1D_t &mask_1D, const std::string &key) override {
        if (algebra::EmptyResult(this, right)
                or algebra::EmptyResult1D(mask_1D)) {
            return new NestedMapUniform<item_T>();
        }
        if (nestedmap_operation::MASKAXISMERGEAXIS_MAP.count(key) > 0) {
            return nestedmap_operation::MASKAXISMERGEAXIS_MAP[key](this,
                    (Base<item_T> *) right, mask_1D);
        }
        std::cout << "base.hpp: nestedmap::Mask_Merge__by() not supported: "
                << key << std::endl;
        return new NestedMapUniform<item_T>();
    }
    inline Base<item_T> *MaskMerge(Storage<item_T> *right,
            Storage<item_T> *mask) override {
        if (algebra::EmptyResult(this, right, mask)) {
            return new NestedMapUniform<item_T>();
        }
        return nestedmap_operation::MaskMerge(this, (Base<item_T> *) right,
                (Base<item_T> *) mask);
    }
    inline Base<item_T> *Merge(Storage<item_T> *right) override {
        if (algebra::EmptyResult(this, right)) {
            return new NestedMapUniform<item_T>();
        }
        return nestedmap_operation::Merge(this, (Base<item_T> *) right);
    }
    inline Base<item_T> *Minus(Storage<item_T> *right) override {
        return nestedmap_operation::Minus(this, (Base<item_T> *) right);
    }
    inline Base<item_T> *Pipeline(axis_1D_t &merge_axis_1D,
            storage_1D_t &merge_1D, axis_2D_t &mask_axis_2D,
            storage_2D_t &mask_2D) override {
        if (algebra::EmptyResult1D(merge_1D)
                or algebra::EmptyResult2D(mask_2D)) {
            return new NestedMapUniform<item_T>();
        }
        return nestedmap_operation::Pipeline(this, merge_axis_1D, merge_1D,
                mask_axis_2D, mask_2D);
    }
    inline Base<item_T> *Reduce(axis_t *axis) override {
        return nestedmap_operation::Reduce(this, axis);
    }
    inline Base<item_T> *Scale(algebra::scalar_t scalar) override {
        return nestedmap_operation::Scale(this, scalar);
    }
    inline Base<item_T> *Transpose(axis_t *axis) override {
        if (algebra::EmptyResult(this)) {
            return new NestedMapUniform<item_T>();
        }
        return nestedmap_operation::Transpose(this, axis);
    }

    // construction method
    inline void Insert(const item_T &from_vertex, const item_T &to_vertex)
            override {
        if (this->KeyExist(from_vertex)) {
            this->Value(from_vertex)->Insert(to_vertex);
        } else {
            Base<item_T> *child_map = this->CreateInner(this->VertexCount());
            child_map->Insert(to_vertex);
            this->Insert(from_vertex, child_map);
        }
    }
    void Sorted() override {
    }
    inline void WriteData(const algebra::ArgParser &argparser,
            const std::string &name) override {
        WriteStorageData(argparser, argparser.DataFile(name), this);
    }

    // property function
    size_type ColumnSize() override; // number of levels
    size_type ElementSum() override;
    size_type RowSize() override; // sum of LoopSize() over the last level

    // conversion
    inline void To_2D(convert::Table2D<item_T> &table2D) override {
        typename convert::Table2D<item_T>::item_1D_t partial;
        this->To_2D(table2D, partial);
    }

    // method used by derived class
    // data read method
    virtual iterator_t *CreateIterator() = 0;
    inline size_type DataSize() const {
        return this->map_.size();
    }
    inline void DeleteErase(const item_T &key) {
        delete this->map_[key];
        this->map_.erase(key);
    }
    inline item_T Key() {
        iterator_t *iter = this->CreateIterator();
        item_T key = iter->Key();
        delete iter;
        return key;
    }
    inline bool KeyExist(const item_T &key) const {
        return this->map_.count(key) > 0;
    }
    virtual bool KeyMatch(const item_T &key) const = 0;
    // number of vertices in this level, the loop size
    virtual size_type LoopSize() const = 0;
    virtual Base<item_T> *Value(const item_T &) = 0;
    virtual size_type VertexCount() const = 0;

    // data write method
    inline void AddToKey(const item_T &count) {
        item_T key = 0;
        if (this->LoopSize() > 0) {
            key = this->Key();
            this->map_.erase(key);
        }
        this->Insert(key + count);
    }
    inline void AddToKey(const item_T &head, const item_T &tail,
            const item_T &count) {
        if (!this->KeyExist(head)) {
            this->Insert(head, new NestedMapUniform<item_T>());
        }
        if (!this->Value(head)->KeyExist(tail)) {
            this->Value(head)->Insert(tail, new NestedMapUniform<item_T>());
        }
        this->Value(head)->Value(tail)->AddToKey(count);
    }
    virtual Base<item_T> *CreateInner(size_type) = 0;
    virtual Base<item_T> *DeepCopy() = 0;
    inline void Insert(const item_T &key) {
        this->Insert(key, nullptr);
    }
    inline void Insert(const item_T &key, Base<item_T> *value) {
        this->map_[key] = value;
    }
    inline void InsertNonEmpty(const item_T &key, Base<item_T> *child_map) {
        if (child_map->LoopSize() > 0) {
            this->Insert(key, child_map);
        } else {
            delete child_map;
        }
    }
    void PushBack(std::deque<item_T> &); // used by transpose

    map_t map_;

private:
    void To_2D(convert::Table2D<item_T> &,
            typename convert::Table2D<item_T>::item_1D_t &);
};

// data write
template<typename item_T>
void Base<item_T>::PushBack(std::deque<item_T> &record) {
    item_T front = record.front();
    record.pop_front();
    if (record.size() == 0) {
        // end of recursion
        assert(!this->KeyExist(front));
        this->Insert(front);
    } else if (this->KeyExist(front)) {
        this->Value(front)->PushBack(record);
    } else {
        Base<item_T> *result = new NestedMapUniform<item_T>();
        result->PushBack(record);
        this->Insert(front, result);
    }
}

// report function
// property
template<typename item_T>
size_type Base<item_T>::ColumnSize() {
    for (iterator_t *pair = this->CreateIterator(); nestedmap::InRange(pair);
            pair->Advance()) {
        if (pair->Value() == nullptr) {
            delete pair;
            return 1;
        } else {
            size_type column_size = 1 + pair->Value()->ColumnSize();
            delete pair;
            return column_size;
        }
    }
    return 0;
}

template<typename item_T>
size_type Base<item_T>::ElementSum() {
    // requirement: 3 column nestedmap
    // (from_vertex, to_vertex, count)
    if (not ((this->RowSize() == 0) || (this->ColumnSize() == 3))) {
        std::cout
                << "WARNING: ElementSum() called on a non-3 dimensional storage"
                << std::endl;
    }
    size_type sum = 0;
    if (this->ColumnSize() < 3) {
        return sum;
    }
    for (iterator_t *first_pair = this->CreateIterator();
            nestedmap::InRange(first_pair); first_pair->Advance()) {
        for (iterator_t *second_pair = first_pair->Value()->CreateIterator();
                nestedmap::InRange(second_pair); second_pair->Advance()) {
            sum += second_pair->Value()->Key();
        }
    }
    return sum;
}

template<typename item_T>
size_type Base<item_T>::RowSize() {
    size_type rowsize = 0;
    for (iterator_t *pair = this->CreateIterator(); nestedmap::InRange(pair);
            pair->Advance()) {
        if (pair->Value() == nullptr) {
            delete pair;
            return this->LoopSize();
        } else {
            rowsize += pair->Value()->RowSize();
        }
    }
    return rowsize;
}

template<typename item_T>
void Base<item_T>::To_2D(convert::Table2D<item_T> &table2D,
        typename convert::Table2D<item_T>::item_1D_t &partial) {
    std::vector<item_T> sorted_key;
    sorted_key.reserve(this->LoopSize());
    for (iterator_t *pair = this->CreateIterator(); nestedmap::InRange(pair);
            pair->Advance()) {
        sorted_key.push_back(pair->Key());
    }
    std::sort(sorted_key.begin(), sorted_key.end());
    for (const item_T key : sorted_key) {
        partial.push_back(key);
        Base<item_T> *value = this->Value(key);
        if (value == nullptr) {
            // partial is a complete record
            table2D.PushBack(
                    new typename convert::Table2D<item_T>::item_1D_t(partial));
        } else {
            value->To_2D(table2D, partial);
        }
        partial.pop_back();
    }
}

} // namespace nestedmap

#endif /* ALGEBRA_STORAGE_NESTEDMAP_BASE_HPP_ */
