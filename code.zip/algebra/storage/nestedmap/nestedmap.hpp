/*
 * nestedmap.hpp
 *
 *  Created on: 2020-4-21 16:26
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_STORAGE_NESTEDMAP_NESTEDMAP_HPP_
#define ALGEBRA_STORAGE_NESTEDMAP_NESTEDMAP_HPP_

#include <string>

#include "algebra/argparser.hpp"
#include "algebra/io/filereader.hpp"
#include "algebra/io/filewriter.hpp"
#include "algebra/storage/nestedmap/base.hpp"
#include "algebra/storage/nestedmap/io.hpp"
#include "algebra/storage/nestedmap/iterator.hpp"

namespace nestedmap {

template<typename key_T, typename value_T>
class NestedMapIterator: public Iterator<key_T, value_T> {
    typedef typename Iterator<key_T, value_T>::data_t data_t;
    typedef typename data_t::iterator iterator;

public:
    NestedMapIterator(data_t &data)
            : Iterator<key_T, value_T>() {
        this->iterator_ = data.begin();
        this->end_ = data.end();
    }
    virtual ~NestedMapIterator() override {
    }
    inline void Advance() override {
        this->iterator_++;
    }
    virtual bool InRange() const override {
        return this->iterator_ != this->end_;
    }
    inline key_T Key() const override {
        return this->iterator_->first;
    }
    inline value_T Value() override {
        return this->iterator_->second;
    }

private:
    iterator iterator_;
    iterator end_;
};

// base class for nestedmap
template<typename item_T>
class NestedMapUniform: public Base<item_T> {
    typedef typename Base<item_T>::iterator_t iterator_t;
public:
    NestedMapUniform() {
    }
    virtual ~NestedMapUniform() override {
    }

    inline Base<item_T> *CreateInner(size_type) override {
        return new NestedMapUniform<item_T>();
    }
    inline iterator_t *CreateIterator() override {
        return new NestedMapIterator<item_T, Base<item_T> *>(this->map_);
    }
    Base<item_T> *DeepCopy() override;
    inline bool KeyMatch(const item_T &key) const override {
        return this->KeyExist(key);
    }
    inline size_type LoopSize() const override {
        return this->DataSize();
    }
    inline Base<item_T> *Value(const item_T &key) override {
        // this is nestedmap, each level value is Operation<item_T> *
        // get the Operation<item_T> * under the key
        assert(this->KeyExist(key));
        return this->map_[key];
    }
    virtual inline size_type VertexCount() const override {
        return 0;
    }

    // additional construction method
    inline void Erase(const item_T &from_vertex, const item_T &to_vertex) {
        this->Value(from_vertex)->map_.erase(to_vertex);
    }
    void Filter() {
        // https://stackoverflow.com/a/4600592/11193802
        auto it = this->map_.begin();
        while (it != this->map_.end()) {
            if (it->second->LoopSize() == 0) {
                delete it->second;
                it = this->map_.erase(it);
            } else {
                it++;
            }
        }
    }
    inline bool Has(const item_T &from_vertex, const item_T &to_vertex) {
        return (this->KeyExist(from_vertex)
                and this->Value(from_vertex)->KeyExist(to_vertex));
    }
};

template<typename item_T>
Base<item_T> *NestedMapUniform<item_T>::DeepCopy() {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    for (iterator_t *pair = this->CreateIterator(); nestedmap::InRange(pair);
            pair->Advance()) {
        if (pair->Value() == nullptr) {
            result->Insert(pair->Key());
        } else {
            result->Insert(pair->Key(), pair->Value()->DeepCopy());
        }
    }
    return result;
}

template<typename item_T>
class EdgeStore: public NestedMapUniform<item_T> {
public:
    EdgeStore()
            : NestedMapUniform<item_T>() {
        // build externally using InsertPair(a, b)
    }
    EdgeStore(const algebra::ArgParser &argparser, const std::string &name)
            : NestedMapUniform<item_T>() {
        // build leaf using pre-processed file
        size_type vertex_count;
        ReadStorageData(argparser, argparser.DataFile(name), this,
                vertex_count);
    }
};

template<typename item_T>
class Adjacency: public NestedMapUniform<item_T> {
public:
    Adjacency(const std::string &filepath)
            : NestedMapUniform<item_T>() {
        // read adjacency file
        algebra::FileReader reader(filepath);
        nestedmap_io::ReadPairListAdjacency(this, reader, this->vertex_count_);
    }
    Adjacency(const algebra::ArgParser &argparser)
            : NestedMapUniform<item_T>() {
        // read adjacency file
        ReadStorageData(argparser, argparser.DataFile("A"), this,
                this->vertex_count_);
    }
    inline size_type VertexCount() const override {
        return this->vertex_count_;
    }

private:
    size_type vertex_count_;
};

template<typename item_T>
class StorageSum: public NestedMapUniform<item_T> {
    typedef typename Base<item_T>::iterator_t iterator_t;
public:
    typedef typename Base<item_T>::storage_1D_t storage_1D_t;

    StorageSum(storage_1D_t &storage_1D)
            : NestedMapUniform<item_T>() {
        // each item is a NestedMap
        for (auto &item : storage_1D) {
            for (iterator_t *first_pair =
                    ((NestedMapUniform<item_T> *) item)->CreateIterator();
                    nestedmap::InRange(first_pair); first_pair->Advance()) {
                for (iterator_t *second_pair =
                        first_pair->Value()->CreateIterator();
                        nestedmap::InRange(second_pair);
                        second_pair->Advance()) {
                    this->AddToKey(first_pair->Key(), second_pair->Key(),
                            second_pair->Value()->Key());
                }
            }
        }
    }
};

}

#endif /* ALGEBRA_STORAGE_NESTEDMAP_NESTEDMAP_HPP_ */
