/*
 * operation_base.hpp
 *
 *  Created on: 2020-10-2 17:22
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_STORAGE_NESTEDMAP_OPERATION_BASE_HPP_
#define ALGEBRA_STORAGE_NESTEDMAP_OPERATION_BASE_HPP_

#include <vector>

#include "algebra/basetype.hpp"
#include "algebra/storage/nestedmap/iterator.hpp"
#include "algebra/storage/storage.hpp"
#include "algebra/utility/access.hpp"

// forward declaration
namespace nestedmap {
template<typename item_T>
class Base;

template<typename item_T>
class NestedMapUniform;
} // namespace nesetedmap

namespace nestedmap_operation {

typedef algebra::size_type size_type;

template<typename item_T>
using axis_T = typename algebra::Storage<item_T>::axis_t;
template<typename item_T>
using axis_1D_T = typename algebra::Storage<item_T>::axis_1D_t;
template<typename item_T>
using axis_2D_T = typename algebra::Storage<item_T>::axis_2D_t;
template<typename item_T>
using Base = nestedmap::Base<item_T>;
template<typename item_T>
using base_1D_T = std::vector<Base<item_T> *>;
template<typename item_T>
using base_2D_T = std::vector<base_1D_T<item_T> *>;
template<typename item_T>
using iterator_T = nestedmap::Iterator<item_T, Base<item_T> *>;
template<typename item_T>
using NestedMapUniform = nestedmap::NestedMapUniform<item_T>;
template<typename item_T>
using storage_1D_T = typename algebra::Storage<item_T>::storage_1D_t;
template<typename item_T>
using storage_2D_T = algebra::T_1D<storage_1D_T<item_T> *>;

template<typename item_T>
class MaskAxis {
public:
    MaskAxis(algebra::Storage<item_T> *mask, axis_T<item_T> *axis)
            : mask_((Base<item_T> *) mask), axis_(axis) {
    }
    static bool Compare(MaskAxis<item_T> *, MaskAxis<item_T> *);

    Base<item_T> * const mask_;
    axis_T<item_T> * const axis_;
};

template<typename item_T>
bool MaskAxis<item_T>::Compare(MaskAxis<item_T> *a, MaskAxis<item_T> *b) {
    item_T a_0 = algebra::Get(a->axis_, 0);
    item_T b_0 = algebra::Get(b->axis_, 0);
    if (a_0 == b_0) {
        return algebra::Get(a->axis_, 1) < algebra::Get(b->axis_, 1);
    }
    return a_0 < b_0;
}

template<typename item_T>
using MaskAxis1D_T = std::vector<MaskAxis<item_T> *>;

template<typename item_T>
bool KeyMatch(item_T key, std::vector<Base<item_T> *> &candidate) {
    for (auto *item : candidate) {
        if (not item->KeyMatch(key)) {
            return false;
        }
    }
    return true;
}

template<typename item_T>
inline void SetLargerSmaller(Base<item_T>* &larger, Base<item_T>* &smaller) {
    if (larger->LoopSize() < smaller->LoopSize()) {
        std::swap(larger, smaller);
    }
}

} // namespace nesetedmap_operation

#endif /* ALGEBRA_STORAGE_NESTEDMAP_OPERATION_BASE_HPP_ */
