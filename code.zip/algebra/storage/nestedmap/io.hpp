/*
 * io.hpp
 *
 *  Created on: 2020-9-20 18:33
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_STORAGE_NESTEDMAP_IO_HPP_
#define ALGEBRA_STORAGE_NESTEDMAP_IO_HPP_

#include <string>
#include <vector>

#include "algebra/argparser.hpp"
#include "algebra/basetype.hpp"
#include "algebra/io/filereader.hpp"
#include "algebra/io/filewriter.hpp"
#include "algebra/utility/access.hpp"

namespace nestedmap {

template<typename item_T>
class Base;

namespace nestedmap_io {

typedef algebra::size_type size_type;

template<typename item_T>
void ReadBinaryBlock(Base<item_T> *storage, std::vector<item_T> &data) {
    /*
     * binary format
     * data[0] = vertex_count
     * data[1] = key
     * data[2] = next_key_position
     * data[3...next_key_position-1] = neighbor_list
     */
    size_type vertex_count = data[0];
    size_type key_index = 1;
    while (key_index < data.size()) {
        Base<item_T> *neighbor = storage->CreateInner(vertex_count);
        storage->Insert(data[key_index], neighbor);
        key_index++;
        size_type next_index = data[key_index];
        for (key_index++; key_index < next_index; key_index++) {
            neighbor->Insert(data[key_index]);
        }
    }
}

template<typename item_T, typename writer_T>
void ReadNeighborList(Base<item_T> *storage, writer_T &reader,
        size_type &vertex_count) {
    size_type neighborlist_count, neighbor_size;
    item_T from_vertex, to_vertex;
    reader.Read(vertex_count, neighborlist_count);
    while (reader.Read(from_vertex, neighbor_size)) {
        Base<item_T> *neighbor = storage->CreateInner(vertex_count);
        for (; neighbor_size > 0; neighbor_size--) {
            reader.Read(to_vertex);
            neighbor->Insert(to_vertex);
        }
        storage->Insert(from_vertex, neighbor);
    }
}

template<typename item_T, typename writer_T>
void ReadPairList(Base<item_T> *storage, writer_T &reader,
        size_type &vertex_count) {
    // LEAF_BINARY_PAIRLIST / LEAF_TEXT_PAIRLIST
    /*
     * vertex_count pairlist_count;
     * from_vertex  to_vertex
     * from_vertex  to_vertex
     * from_vertex  to_vertex
     */
    size_type pairlist_count;
    item_T from_vertex, to_vertex;
    reader.Read(vertex_count, pairlist_count);
    while (reader.Read(from_vertex, to_vertex)) {
        storage->Insert(from_vertex, to_vertex);
    }
}

template<typename item_T, typename writer_T>
void ReadPairListAdjacency(Base<item_T> *storage, writer_T &reader,
        size_type &vertex_count) {
    // LEAF_TEXT_PAIRLIST_ADJACENCY
    /*
     * from_vertex  to_vertex
     * from_vertex  to_vertex
     * from_vertex  to_vertex
     */
    item_T from_vertex, to_vertex, max_vertex = 0;
    while (reader.Read(from_vertex, to_vertex)) {
        storage->Insert(from_vertex, to_vertex);
        max_vertex = std::max(std::max(from_vertex, to_vertex), max_vertex);
    }
    if (storage->DataSize() == 0) {
        vertex_count = 0;
    } else {
        vertex_count = max_vertex + 1;
    }
}

template<typename item_T, typename writer_T>
void WriteNeighborList(Base<item_T> *storage, writer_T &writer) {
    /*
     * vertex_count neighborlist_count
     * from_vertex  neighbor_size to_vertex1 to_vertex2 to_vertex3 ...
     */
    writer.Write(storage->VertexCount())->Write(storage->DataSize());
    std::vector<item_T> outer;
    algebra::SortMapKey(storage->map_, outer);
    for (auto &outer_key : outer) {
        Base<item_T> *outer_value = storage->map_[outer_key];
        writer.Write(outer_key)->Write(outer_value->DataSize());
        std::vector<item_T> inner;
        algebra::SortMapKey(outer_value->map_, inner);
        for (auto &inner_key : inner) {
            writer.Write(inner_key);
        }
    }
}

template<typename item_T, typename writer_T>
inline void WritePairListAdjacency(Base<item_T> *storage, writer_T &writer) {
    /*
     * from_vertex  to_vertex
     * from_vertex  to_vertex
     * from_vertex  to_vertex
     */
    std::vector<item_T> outer;
    algebra::SortMapKey(storage->map_, outer);
    for (auto &outer_key : outer) {
        std::vector<item_T> inner;
        algebra::SortMapKey(storage->map_[outer_key]->map_, inner);
        for (auto &inner_key : inner) {
            writer.Write(outer_key)->Write(inner_key);
        }
    }
}

template<typename item_T, typename writer_T>
void WritePairList(Base<item_T> *storage, writer_T &writer) {
    /*
     * vertex_count pairlist_count
     * from_vertex  to_vertex
     * from_vertex  to_vertex
     * from_vertex  to_vertex
     */
    size_type pairlist_count = 0;
    for (auto &outer : storage->map_) {
        pairlist_count += outer.second->map_.size();
    }
    writer.Write(storage->VertexCount())->Write(pairlist_count);
    WritePairListAdjacency(storage, writer);
}

} // namespace nestedmap_io

template<typename item_T>
void ReadStorageData(const algebra::ArgParser &argparser,
        const std::string &filepath, Base<item_T> *storage,
        algebra::size_type &vertex_count) {
    // customized format
    if (argparser.LeafFormat() == algebra::LEAF_BINARY_BLOCK) {
        std::vector<item_T> data;
        algebra::BinaryReader reader(filepath);
        reader.ReadAll(data);
        vertex_count = data[0];
        nestedmap_io::ReadBinaryBlock(storage, data);
    } else if (argparser.LeafFormat() == algebra::LEAF_BINARY_NEIGHBORLIST) {
        algebra::BinaryReader reader(filepath);
        nestedmap_io::ReadNeighborList(storage, reader, vertex_count);
    } else if (argparser.LeafFormat() == algebra::LEAF_BINARY_PAIRLIST) {
        algebra::BinaryReader reader(filepath);
        nestedmap_io::ReadPairList(storage, reader, vertex_count);
    } else if (argparser.LeafFormat() == algebra::LEAF_TEXT_NEIGHBORLIST) {
        // LEAF_TEXT_NEIGHBORLIST
        algebra::FileReader reader(filepath);
        nestedmap_io::ReadNeighborList(storage, reader, vertex_count);
    } else if (argparser.LeafFormat() == algebra::LEAF_TEXT_PAIRLIST) {
        // LEAF_TEXT_PAIRLIST
        algebra::FileReader reader(filepath);
        nestedmap_io::ReadPairList(storage, reader, vertex_count);
    } else {
        // LEAF_TEXT_PAIRLIST_ADJACENCY
        algebra::FileReader reader(filepath);
        nestedmap_io::ReadPairListAdjacency(storage, reader, vertex_count);
    }
}

template<typename item_T>
void WriteStorageData(const algebra::ArgParser &argparser,
        const std::string &filepath, Base<item_T> *storage) {
    if (argparser.LeafFormat() == algebra::LEAF_BINARY_BLOCK) {
        /*
         * block binary format
         * data[0] = vertex_count
         * data[1] = key
         * data[2] = next_key_position
         * data[3...next_key_position-1] = neighbor_list
         */
        std::vector<item_T> data;
        data.push_back(storage->VertexCount());
        std::vector<item_T> outer;
        algebra::SortMapKey(storage->map_, outer);
        for (auto &outer_key : outer) {
            Base<item_T> *outer_value = storage->map_[outer_key];
            data.push_back(outer_key);
            data.push_back(data.size() + outer_value->DataSize() + 1);
            std::vector<item_T> inner;
            algebra::SortMapKey(outer_value->map_, inner);
            for (auto inner_key : inner) {
                data.push_back(inner_key);
            }
        }
        algebra::BinaryWriter writer(filepath);
        writer.WriteAll(data);
    } else if (argparser.LeafFormat() == algebra::LEAF_BINARY_NEIGHBORLIST) {
        algebra::BinaryWriter writer(filepath);
        nestedmap_io::WriteNeighborList(storage, writer);
    } else if (argparser.LeafFormat() == algebra::LEAF_BINARY_PAIRLIST) {
        algebra::BinaryWriter writer(filepath);
        nestedmap_io::WritePairList(storage, writer);
    } else if (argparser.LeafFormat() == algebra::LEAF_TEXT_NEIGHBORLIST) {
        algebra::StreamWriter writer(filepath);
        nestedmap_io::WriteNeighborList(storage, writer);
    } else if (argparser.LeafFormat() == algebra::LEAF_TEXT_PAIRLIST) {
        algebra::StreamWriter writer(filepath);
        nestedmap_io::WritePairList(storage, writer);
    } else {
        algebra::StreamWriter writer(filepath);
        nestedmap_io::WritePairListAdjacency(storage, writer);
    }
}

} // namespace nestedmap

#endif /* ALGEBRA_STORAGE_NESTEDMAP_IO_HPP_ */
