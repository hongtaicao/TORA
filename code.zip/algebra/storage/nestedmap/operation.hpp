/*
 * operation.hpp
 *
 *  Created on: 2020-9-18 11:16
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_STORAGE_NESTEDMAP_OPERATION_HPP_
#define ALGEBRA_STORAGE_NESTEDMAP_OPERATION_HPP_

#include <deque>
#include <vector>

#include "algebra/storage/nestedmap/axismask.hpp"
#include "algebra/storage/nestedmap/operation_base.hpp"
#include "algebra/utility/access.hpp"

namespace nestedmap_operation {

// operation method
// Mask
template<typename item_T>
Base<item_T> *Mask(Base<item_T> *, Base<item_T> *);
template<typename item_T>
Base<item_T> *MaskRecursion(Base<item_T> *, Base<item_T> *, size_type);
template<typename item_T>
Base<item_T> *MaskTail(Base<item_T> *, Base<item_T> *);

// MaskMerge(left, right, mask_tail)
template<typename item_T>
Base<item_T> *MaskMerge(Base<item_T> *, Base<item_T> *, Base<item_T> *);
template<typename item_T>
Base<item_T> *MaskMergeRecursion(Base<item_T> *, Base<item_T> *, Base<item_T> *,
        size_type);
template<typename item_T>
Base<item_T> *MaskMergeAlign(Base<item_T> *, Base<item_T> *, Base<item_T> *);

// MaskAxisMerge
template<typename item_T>
inline Base<item_T> *MaskAxisMerge(Base<item_T> *, Base<item_T> *,
        axis_2D_T<item_T> &, storage_1D_T<item_T> &);
template<typename item_T>
Base<item_T> *MaskAxisMergeRecursion(Base<item_T> *, Base<item_T> *,
        AxisMask<item_T> &, size_type, size_type);
template<typename item_T>
Base<item_T> *MaskAxisMergeAlign(Base<item_T> *, Base<item_T> *,
        AxisMask<item_T> &, size_type);
template<typename item_T>
inline void MaskAxisMergeAlignInner(Base<item_T> *, Base<item_T> *,
        Base<item_T> *, AxisMask<item_T> &, size_type, item_T);
template<typename item_T>
Base<item_T> *MaskAxisTail(Base<item_T> *, AxisMask<item_T> &, size_type);
template<typename item_T>
inline void MaskAxisTailInner(Base<item_T> *, Base<item_T> *, item_T,
        AxisMask<item_T> &, size_type);

// MaskAxisMergeAxis
template<typename item_T>
inline Base<item_T> *MaskAxisMergeAxis(Base<item_T> *, axis_T<item_T> &,
        Base<item_T> *, axis_2D_T<item_T> &, storage_1D_T<item_T> &);
template<typename item_T>
Base<item_T> *MaskAxisMergeAxisRecursion(Base<item_T> *, axis_T<item_T> &,
        size_type, Base<item_T> *, AxisMask<item_T> &, size_type);
template<typename item_T>
Base<item_T> *MaskAxisMergeAxisAlign(Base<item_T> *, axis_T<item_T> &,
        size_type, Base<item_T> *, AxisMask<item_T> &, size_type);
template<typename item_T>
inline void MaskAxisMergeAxisAlignInner(Base<item_T> *, Base<item_T> *,
        axis_T<item_T> &, size_type, Base<item_T> *, AxisMask<item_T> &,
        size_type, item_T);
template<typename item_T>
Base<item_T> *MaskAxisTailConcat(Base<item_T> *, Base<item_T> *,
        AxisMask<item_T> &, size_type);
template<typename item_T>
inline void MaskAxisTailConcatInner(Base<item_T> *, Base<item_T> *, item_T,
        Base<item_T> *, AxisMask<item_T> &, size_type);

// Merge
template<typename item_T>
Base<item_T> *Merge(Base<item_T> *, Base<item_T> *);
template<typename item_T>
Base<item_T> *MergeAlign(Base<item_T> *, Base<item_T> *);
template<typename item_T>
Base<item_T> *MergeRecursion(Base<item_T> *, Base<item_T> *, size_type);

// Minus
template<typename item_T>
Base<item_T> *Minus(Base<item_T> *, Base<item_T> *);
template<typename item_T>
Base<item_T> *MinusRecursion(Base<item_T> *, Base<item_T> *, size_type);

// Pipeline
template<typename item_T>
Base<item_T> *Pipeline(Base<item_T> *, axis_2D_T<item_T> &,
        storage_1D_T<item_T> &, axis_2D_T<item_T> &, storage_1D_T<item_T> &);
template<typename item_T>
bool PipelineMatchAll(axis_1D_T<item_T> *, base_1D_T<item_T> *, item_T *);
template<typename item_T>
Base<item_T> *PipelineRecursion(axis_1D_T<item_T> &, base_1D_T<item_T> &,
        axis_2D_T<item_T> &, base_2D_T<item_T> &, item_T *, size_type);

// Reduce
template<typename item_T>
Base<item_T> *Reduce(Base<item_T> *, axis_T<item_T> *);
template<typename item_T>
Base<item_T> *ReduceRecursion(Base<item_T> *, Base<item_T> *, item_T, item_T,
        int, int);

// Scale
template<typename item_T>
inline Base<item_T> *Scale(Base<item_T> *, algebra::scalar_t);
template<typename item_T>
Base<item_T> *ScaleRecursion(Base<item_T> *, algebra::scalar_t, size_type);

// Transpose
template<typename item_T>
inline Base<item_T> *Transpose(Base<item_T> *, axis_T<item_T> *);
template<typename item_T>
Base<item_T> *TransposeRecursion(Base<item_T> *, Base<item_T> *,
        std::vector<item_T> &, axis_T<item_T> *);

// operation implementation
template<typename item_T>
Base<item_T> *Mask(Base<item_T> *op, Base<item_T> *mask) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger = op;
    Base<item_T> *smaller = mask;
    SetLargerSmaller(larger, smaller);
    size_type remaining_axis = op->ColumnSize() - 1;
    for (iterator_T<item_T> *mask_pair = smaller->CreateIterator();
            nestedmap::InRange(mask_pair); mask_pair->Advance()) {
        if (larger->KeyMatch(mask_pair->Key())) {
            Base<item_T> *child_map = MaskRecursion(op->Value(mask_pair->Key()),
                    mask->Value(mask_pair->Key()), remaining_axis);
            result->InsertNonEmpty(mask_pair->Key(), child_map);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *MaskRecursion(Base<item_T> *op, Base<item_T> *mask_tail,
        size_type remaining_axis) {
    if (remaining_axis == 1) {
        // one axis left in remaining, which is the key
        // value of remaining is empty
        return MaskTail(op, mask_tail);
    }
    // remaining is still nestedmap
    Base<item_T> *result = new NestedMapUniform<item_T>();
    remaining_axis--;
    for (iterator_T<item_T> *pair = op->CreateIterator();
            nestedmap::InRange(pair); pair->Advance()) {
        Base<item_T> *child_map = MaskRecursion(pair->Value(), mask_tail,
                remaining_axis);
        result->InsertNonEmpty(pair->Key(), child_map);
    }
    return result;
}

template<typename item_T>
Base<item_T> *MaskTail(Base<item_T> *small, Base<item_T> *large) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    SetLargerSmaller(large, small);
    for (iterator_T<item_T> *pair = small->CreateIterator();
            nestedmap::InRange(pair); pair->Advance()) {
        if (large->KeyMatch(pair->Key())) {
            result->Insert(pair->Key());
        }
    }
    return result;
}

/*
 * support operation
 * (A,B) Merge (B,C) Mask (A,C) = (A,B,C), prefix=A
 * (A,B,C,D) Merge (C,D,E) Mask (A,E) = (A,B,C,D,E), prefix=A,B
 * not support
 * (A,B,C) Merge (C,D,E) Mask (A,E)
 *
 * number of columns to Merge = right.ColumnSize - 1
 */
template<typename item_T>
Base<item_T> *MaskMerge(Base<item_T> *left, Base<item_T> *right,
        Base<item_T> *mask) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger = left;
    Base<item_T> *smaller = mask;
    size_type prefix = left->ColumnSize() - right->ColumnSize();
    SetLargerSmaller(larger, smaller);
    for (iterator_T<item_T> *mask_pair = smaller->CreateIterator();
            nestedmap::InRange(mask_pair); mask_pair->Advance()) {
        if (larger->KeyMatch(mask_pair->Key())) {
            // check mask[0] == left[0]
            // recursive check left[1] and right[0]
            Base<item_T> *child_map = MaskMergeRecursion(
                    left->Value(mask_pair->Key()), right,
                    mask->Value(mask_pair->Key()), prefix);
            result->InsertNonEmpty(mask_pair->Key(), child_map);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *MaskMergeRecursion(Base<item_T> *left, Base<item_T> *right,
        Base<item_T> *mask_tail, size_type prefix) {
    if (prefix == 0) {
        return MaskMergeAlign(left, right, mask_tail);
    }
    prefix--;
    Base<item_T> *result = new NestedMapUniform<item_T>();
    for (iterator_T<item_T> *pair = left->CreateIterator();
            nestedmap::InRange(pair); pair->Advance()) {
        Base<item_T> *child_map = MaskMergeRecursion(pair->Value(), right,
                mask_tail, prefix);
        result->InsertNonEmpty(pair->Key(), child_map);
    }
    return result;
}

template<typename item_T>
Base<item_T> *MaskMergeAlign(Base<item_T> *left, Base<item_T> *right,
        Base<item_T> *mask_tail) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger = left;
    Base<item_T> *smaller = right;
    SetLargerSmaller(larger, smaller);
    for (iterator_T<item_T> *merge_pair = smaller->CreateIterator();
            nestedmap::InRange(merge_pair); merge_pair->Advance()) {
        if (larger->KeyMatch(merge_pair->Key())) {
            // current axis can Merge
            Base<item_T> *left_data = left->Value(merge_pair->Key());
            Base<item_T> *right_data = right->Value(merge_pair->Key());
            Base<item_T> *child_map = nullptr;
            if (left_data == nullptr) {
                // end of recursion
                child_map = MaskTail(right_data, mask_tail);
            } else {
                // recursion to MaskMergeRight on the next axis
                child_map = MaskMergeAlign(left_data, right_data, mask_tail);
            }
            result->InsertNonEmpty(merge_pair->Key(), child_map);
        }
    }
    return result;
}

// MaskAxisMerge
template<typename item_T>
inline Base<item_T> *MaskAxisMerge(Base<item_T> *left, Base<item_T> *right,
        axis_2D_T<item_T> &axis_2D, storage_1D_T<item_T> &mask_1D) {
    AxisMask<item_T> axismask(mask_1D, axis_2D);
    size_type prefix = left->ColumnSize() - right->ColumnSize() + 1;
    Base<item_T> *result = MaskAxisMergeRecursion(left, right, axismask, 0,
            prefix);
    return result;
}

template<typename item_T>
Base<item_T> *MaskAxisMergeRecursion(Base<item_T> *left, Base<item_T> *right,
        AxisMask<item_T> &axismask, size_type axis, size_type prefix) {
    if (prefix == 0) {
        return MaskAxisMergeAlign(left, right, axismask, axis);
    }
    prefix--;
    Base<item_T> *result = new NestedMapUniform<item_T>();
    size_type next_axis = axis + 1;
    if (axismask.HasAxis(axis)) {
        // has mask on this dimension
        if (left->LoopSize() < axismask.SizeAt(axis)) {
            // loop over this (left)
            for (iterator_T<item_T> *pair = left->CreateIterator();
                    nestedmap::InRange(pair); pair->Advance()) {
                if (axismask.HasKeyAt(pair->Key(), axis)) {
                    axismask.SetKeyAt(pair->Key(), axis);
                    Base<item_T> *child_map = MaskAxisMergeRecursion(
                            pair->Value(), right, axismask, next_axis, prefix);
                    result->InsertNonEmpty(pair->Key(), child_map);
                    axismask.EraseKeyAt(axis);
                }
            }
        } else {
            // loop over axismask
            for (iterator_T<item_T> *pair = axismask.CreateIterator(axis);
                    nestedmap::InRange(pair); pair->Advance()) {
                if (left->KeyMatch(pair->Key())) {
                    axismask.SetKeyAt(pair->Key(), axis);
                    Base<item_T> *child_map = MaskAxisMergeRecursion(
                            left->Value(pair->Key()), right, axismask,
                            next_axis, prefix);
                    result->InsertNonEmpty(pair->Key(), child_map);
                    axismask.EraseKeyAt(axis);
                }
            }
        }
    } else {
        // no mask on dimension axis
        // process the next axis
        for (iterator_T<item_T> *pair = left->CreateIterator();
                nestedmap::InRange(pair); pair->Advance()) {
            Base<item_T> *child_map = MaskAxisMergeRecursion(pair->Value(),
                    right, axismask, next_axis, prefix);
            result->InsertNonEmpty(pair->Key(), child_map);
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *MaskAxisMergeAlign(Base<item_T> *left, Base<item_T> *right,
        AxisMask<item_T> &axismask, size_type axis) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger = left;
    Base<item_T> *smaller = right;
    SetLargerSmaller(larger, smaller);
    size_type next_axis = axis + 1;
    if (axismask.HasAxis(axis)) {
        // has mask on this dimension
        if (smaller->LoopSize() < axismask.SizeAt(axis)) {
            // loop over this
            for (iterator_T<item_T> *pair = smaller->CreateIterator();
                    nestedmap::InRange(pair); pair->Advance()) {
                if (larger->KeyMatch(pair->Key())
                        and axismask.HasKeyAt(pair->Key(), axis)) {
                    axismask.SetKeyAt(pair->Key(), axis);
                    MaskAxisMergeAlignInner(result, left, right, axismask,
                            next_axis, pair->Key());
                    axismask.EraseKeyAt(axis);
                }
            }
        } else {
            // loop over axismask
            for (iterator_T<item_T> *pair = axismask.CreateIterator(axis);
                    nestedmap::InRange(pair); pair->Advance()) {
                if (left->KeyMatch(pair->Key())
                        and right->KeyMatch(pair->Key())) {
                    axismask.SetKeyAt(pair->Key(), axis);
                    MaskAxisMergeAlignInner(result, left, right, axismask,
                            next_axis, pair->Key());
                    axismask.EraseKeyAt(axis);
                }
            }
        }
    } else {
        // no mask on dimension axis
        // process the next_axis
        for (iterator_T<item_T> *pair = smaller->CreateIterator();
                nestedmap::InRange(pair); pair->Advance()) {
            if (larger->KeyMatch(pair->Key())) {
                MaskAxisMergeAlignInner(result, left, right, axismask,
                        next_axis, pair->Key());
            }
        }
    }
    return result;
}

template<typename item_T>
inline void MaskAxisMergeAlignInner(Base<item_T> *result, Base<item_T> *left,
        Base<item_T> *right, AxisMask<item_T> &axismask, size_type axis,
        item_T key) {
    // current axis can Merge
    Base<item_T> *left_data = left->Value(key);
    Base<item_T> *right_data = right->Value(key);
    Base<item_T> *child_map = nullptr;
    if (left_data == nullptr) {
        // end of recursion
        child_map = MaskAxisTail(right_data, axismask, axis);
    } else {
        // recursion to MaskMergeRight on the next axis
        child_map = MaskAxisMergeAlign(left_data, right, axismask, axis);
    }
    result->InsertNonEmpty(key, child_map);
}

template<typename item_T>
Base<item_T> *MaskAxisTail(Base<item_T> *op, AxisMask<item_T> &axismask,
        size_type axis) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    size_type next_axis = axis + 1;
    if (axismask.HasAxis(axis)) {
        // need mask
        // loop over smaller one
        if (op->LoopSize() < axismask.SizeAt(axis)) {
            for (iterator_T<item_T> *pair = op->CreateIterator();
                    nestedmap::InRange(pair); pair->Advance()) {
                if (axismask.HasKeyAt(pair->Key(), axis)) {
                    axismask.SetKeyAt(pair->Key(), axis);
                    MaskAxisTailInner(result, op, pair->Key(), axismask,
                            next_axis);
                    axismask.EraseKeyAt(axis);
                }
            }
        } else {
            for (iterator_T<item_T> *pair = axismask.CreateIterator(axis);
                    nestedmap::InRange(pair); pair->Advance()) {
                if (op->KeyMatch(pair->Key())) {
                    axismask.SetKeyAt(pair->Key(), axis);
                    MaskAxisTailInner(result, op, pair->Key(), axismask,
                            next_axis);
                    axismask.EraseKeyAt(axis);
                }
            }
        }
    } else {
        // no need mask. loop only
        for (iterator_T<item_T> *pair = op->CreateIterator();
                nestedmap::InRange(pair); pair->Advance()) {
            MaskAxisTailInner(result, op, pair->Key(), axismask, next_axis);
        }
    }
    return result;
}

template<typename item_T>
inline void MaskAxisTailInner(Base<item_T> *result, Base<item_T> *right,
        item_T key, AxisMask<item_T> &axismask, size_type axis) {
    Base<item_T> *right_data = right->Value(key);
    if (right_data == nullptr) {
        result->Insert(key);
    } else {
        Base<item_T> *child_map = MaskAxisTail(right_data, axismask, axis);
        result->InsertNonEmpty(key, child_map);
    }
}

/*
 * (A,B,C,D,E) MergeAxis [0],(A,F) -> (A,B,C,D,E,F)
 * (A,B,C,D,E) MergeAxis [0,2,3],(A,C,D,F) -> (A,B,C,D,E,F)
 * (A,B,C,D,E) MergeAxis [2],(C,F,G) -> (A,B,C,D,E,F,G)
 */
template<typename item_T>
inline Base<item_T> *MaskAxisMergeAxis(Base<item_T> *left,
        axis_T<item_T> &merge_axis, Base<item_T> *right,
        axis_2D_T<item_T> &axis_2D, storage_1D_T<item_T> &mask_1D) {
    AxisMask<item_T> axismask(mask_1D, axis_2D);
    return MaskAxisMergeAxisRecursion(left, merge_axis, 0, right, axismask, 0);
}

template<typename item_T>
Base<item_T> *MaskAxisMergeAxisRecursion(Base<item_T> *left,
        axis_T<item_T> &merge_axis, size_type offset, Base<item_T> *right,
        AxisMask<item_T> &axismask, size_type axis) {
    if (offset < merge_axis.size()) {
        if (merge_axis[offset] == axis) {
            // merge on this axis
            return MaskAxisMergeAxisAlign(left, merge_axis, offset, right,
                    axismask, axis);
        }
        // no merge on this axis
        Base<item_T> *result = new NestedMapUniform<item_T>();
        size_type next_axis = axis + 1;
        if (axismask.HasAxis(axis)) {
            // has mask on this dimension
            if (left->LoopSize() < axismask.SizeAt(axis)) {
                // loop over this (left)
                for (iterator_T<item_T> *pair = left->CreateIterator();
                        nestedmap::InRange(pair); pair->Advance()) {
                    if (axismask.HasKeyAt(pair->Key(), axis)) {
                        axismask.SetKeyAt(pair->Key(), axis);
                        Base<item_T> *child_map = MaskAxisMergeAxisRecursion(
                                pair->Value(), merge_axis, offset, right,
                                axismask, next_axis);
                        result->InsertNonEmpty(pair->Key(), child_map);
                        axismask.EraseKeyAt(axis);
                    }
                }
            } else {
                // loop over axismask
                for (iterator_T<item_T> *pair = axismask.CreateIterator(axis);
                        nestedmap::InRange(pair); pair->Advance()) {
                    if (left->KeyMatch(pair->Key())) {
                        axismask.SetKeyAt(pair->Key(), axis);
                        Base<item_T> *child_map = MaskAxisMergeAxisRecursion(
                                left->Value(pair->Key()), merge_axis, offset,
                                right, axismask, next_axis);
                        result->InsertNonEmpty(pair->Key(), child_map);
                        axismask.EraseKeyAt(axis);
                    }
                }
            }
        } else {
            // no mask on dimension axis
            // process the next axis
            for (iterator_T<item_T> *pair = left->CreateIterator();
                    nestedmap::InRange(pair); pair->Advance()) {
                Base<item_T> *child_map = MaskAxisMergeAxisRecursion(
                        pair->Value(), merge_axis, offset, right, axismask,
                        next_axis);
                result->InsertNonEmpty(pair->Key(), child_map);
            }
        }
        return result;
    }
    // no merge in future
    // left is not empty
    return MaskAxisTailConcat(left, right, axismask, axis);
}

template<typename item_T>
Base<item_T> *MaskAxisMergeAxisAlign(Base<item_T> *left,
        axis_T<item_T> &merge_axis, size_type offset, Base<item_T> *right,
        AxisMask<item_T> &axismask, size_type axis) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger = left;
    Base<item_T> *smaller = right;
    SetLargerSmaller(larger, smaller);
    offset += 1;
    axis += 1;
    // no mask on dimension axis
    // process the next_axis
    for (iterator_T<item_T> *pair = smaller->CreateIterator();
            nestedmap::InRange(pair); pair->Advance()) {
        if (larger->KeyMatch(pair->Key())) {
            MaskAxisMergeAxisAlignInner(result, left, merge_axis, offset, right,
                    axismask, axis, pair->Key());
        }
    }
    return result;
}

template<typename item_T>
inline void MaskAxisMergeAxisAlignInner(Base<item_T> *result,
        Base<item_T> *left, axis_T<item_T> &merge_axis, size_type offset,
        Base<item_T> *right, AxisMask<item_T> &axismask, size_type axis,
        item_T key) {
    // current axis can Merge
    Base<item_T> *left_data = left->Value(key);
    Base<item_T> *right_data = right->Value(key);
    Base<item_T> *child_map = nullptr;
    if (left_data == nullptr) {
        // end of recursion
        child_map = MaskAxisTail(right_data, axismask, axis);
    } else {
        // recursion to MaskMergeRight on the next axis
        child_map = MaskAxisMergeAxisRecursion(left_data, merge_axis, offset,
                right_data, axismask, axis);
    }
    result->InsertNonEmpty(key, child_map);
}

template<typename item_T>
Base<item_T> *MaskAxisTailConcat(Base<item_T> *left, Base<item_T> *right,
        AxisMask<item_T> &axismask, size_type axis) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    size_type next_axis = axis + 1;
    if (axismask.HasAxis(axis)) {
        // need mask
        // loop over smaller one
        if (left->LoopSize() < axismask.SizeAt(axis)) {
            for (iterator_T<item_T> *pair = left->CreateIterator();
                    nestedmap::InRange(pair); pair->Advance()) {
                if (axismask.HasKeyAt(pair->Key(), axis)) {
                    axismask.SetKeyAt(pair->Key(), axis);
                    MaskAxisTailConcatInner(result, left, pair->Key(), right,
                            axismask, next_axis);
                    axismask.EraseKeyAt(axis);
                }
            }
        } else {
            for (iterator_T<item_T> *pair = axismask.CreateIterator(axis);
                    nestedmap::InRange(pair); pair->Advance()) {
                if (left->KeyMatch(pair->Key())) {
                    axismask.SetKeyAt(pair->Key(), axis);
                    MaskAxisTailConcatInner(result, left, pair->Key(), right,
                            axismask, next_axis);
                    axismask.EraseKeyAt(axis);
                }
            }
        }
    } else {
        // no need mask. loop only
        for (iterator_T<item_T> *pair = left->CreateIterator();
                nestedmap::InRange(pair); pair->Advance()) {
            MaskAxisTailConcatInner(result, left, pair->Key(), right, axismask,
                    next_axis);
        }
    }
    return result;
}

template<typename item_T>
inline void MaskAxisTailConcatInner(Base<item_T> *result, Base<item_T> *left,
        item_T key, Base<item_T> *right, AxisMask<item_T> &axismask,
        size_type axis) {
    Base<item_T> *left_data = left->Value(key);
    if (left_data == nullptr) {
        Base<item_T> *child_map = MaskAxisTail(right, axismask, axis);
        result->InsertNonEmpty(key, child_map);
    } else {
        Base<item_T> *child_map = MaskAxisTailConcat(left_data, right, axismask,
                axis);
        result->InsertNonEmpty(key, child_map);
    }
}

/*
 * supported operation
 * (A,B,C) Merge (B,C,D,E,F) = (A,B,C,D,E,F), prefix=A
 * (A,B,C,D,E) Merge (D,E,F) = (A,B,C,D,E,F), prefix=A,B,C
 *
 * number of columns to Merge = min(left.ColumnSize, right.ColumnSize) - 1
 */
template<typename item_T>
Base<item_T> *Merge(Base<item_T> *left, Base<item_T> *right) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    size_type left_column_size = left->ColumnSize();
    size_type prefix = left_column_size
            - std::min(left_column_size, right->ColumnSize());
    for (iterator_T<item_T> *pair = left->CreateIterator();
            nestedmap::InRange(pair); pair->Advance()) {
        Base<item_T> *child_map = MergeRecursion(pair->Value(), right, prefix);
        result->InsertNonEmpty(pair->Key(), child_map);
    }
    return result;
}

template<typename item_T>
Base<item_T> *MergeAlign(Base<item_T> *left, Base<item_T> *right) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    Base<item_T> *larger = left;
    Base<item_T> *smaller = right;
    SetLargerSmaller(larger, smaller);
    for (iterator_T<item_T> *pair = smaller->CreateIterator();
            nestedmap::InRange(pair); pair->Advance()) {
        if (larger->KeyMatch(pair->Key())) {
            Base<item_T> *left_data = left->Value(pair->Key());
            if (left_data == nullptr) {
                // end of recursion
                result->Insert(pair->Key(),
                        right->Value(pair->Key())->DeepCopy());
            } else {
                // recursion
                result->InsertNonEmpty(pair->Key(),
                        MergeAlign(left_data, right->Value(pair->Key())));
            }
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *MergeRecursion(Base<item_T> *left, Base<item_T> *right,
        size_type prefix) {
    if (prefix == 0) {
        return MergeAlign(left, right);
    }
    prefix--;
    Base<item_T> *result = new NestedMapUniform<item_T>();
    for (iterator_T<item_T> *pair = left->CreateIterator();
            nestedmap::InRange(pair); pair->Advance()) {
        Base<item_T> *child_map = MergeRecursion(pair->Value(), right, prefix);
        result->InsertNonEmpty(pair->Key(), child_map);
    }
    return result;
}

template<typename item_T>
Base<item_T> *Minus(Base<item_T> *left, Base<item_T> *mask) {
    if (mask->RowSize() == 0) {
        return left->DeepCopy();
    }
    Base<item_T> *result = new NestedMapUniform<item_T>();
    size_type remaining_axis = left->ColumnSize() - 1;
    for (iterator_T<item_T> *head = left->CreateIterator();
            nestedmap::InRange(head); head->Advance()) {
        if (mask->KeyMatch(head->Key())) {
            Base<item_T> *child_map = MinusRecursion(head->Value(),
                    mask->Value(head->Key()), remaining_axis);
            result->InsertNonEmpty(head->Key(), child_map);
        } else {
            result->Insert(head->Key(), head->Value()->DeepCopy());
        }

    }
    return result;
}

template<typename item_T>
Base<item_T> *MinusRecursion(Base<item_T> *left, Base<item_T> *mask_tail,
        size_type remaining_axis) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    if (remaining_axis == 1) {
        // MinusTail
        for (iterator_T<item_T> *pair = left->CreateIterator();
                nestedmap::InRange(pair); pair->Advance()) {
            if (!mask_tail->KeyMatch(pair->Key())) {
                result->Insert(pair->Key());
            }
        }
        return result;
    }
    // recursion
    remaining_axis--;
    for (iterator_T<item_T> *pair = left->CreateIterator();
            nestedmap::InRange(pair); pair->Advance()) {
        result->InsertNonEmpty(pair->Key(),
                MinusRecursion(pair->Value(), mask_tail, remaining_axis));
    }
    return result;
}

template<typename item_T>
Base<item_T> *Pipeline(Base<item_T> *left, axis_1D_T<item_T> &merge_axis_1D,
        storage_1D_T<item_T> &merge_1D_, axis_2D_T<item_T> &mask_axis_2D,
        storage_2D_T<item_T> &mask_2D_) {
    if (merge_axis_1D.size() < 1) {
        // pipeline self
        return left->DeepCopy();
    }
    // format result
    base_1D_T<item_T> merge_1D;
    base_2D_T<item_T> mask_2D;
    for (size_type i = 0; i < merge_axis_1D.size(); i++) {
        merge_1D.push_back((Base<item_T> *) merge_1D_[i]);
        base_1D_T<item_T> *inner = new base_1D_T<item_T>;
        for (auto item : (*mask_2D_[i])) {
            inner->push_back((Base<item_T> *) item);
        }
        mask_2D.push_back(inner);
    }
    Base<item_T> *result = new NestedMapUniform<item_T>();
    item_T candidate[merge_1D.size() + 1];
    for (iterator_T<item_T> *head = left->CreateIterator();
            nestedmap::InRange(head); head->Advance()) {
        Base<item_T> *head_inner = new NestedMapUniform<item_T>();
        candidate[0] = head->Key();
        for (iterator_T<item_T> *tail = head->Value()->CreateIterator();
                nestedmap::InRange(tail); tail->Advance()) {
            candidate[1] = tail->Key();
            head_inner->InsertNonEmpty(tail->Key(),
                    PipelineRecursion(merge_axis_1D, merge_1D, mask_axis_2D,
                            mask_2D, candidate, 0));
        }
        result->InsertNonEmpty(head->Key(), head_inner);
    }
    algebra::DeleteContent(mask_2D);
    return result;
}

template<typename item_T>
bool PipelineMatchAll(axis_1D_T<item_T> *axis_1D, base_1D_T<item_T> *mask_1D,
        item_T *candidate) {
    for (size_type i = 0; i < axis_1D->size(); i++) {
        axis_T<item_T> *axis = algebra::Get(axis_1D, i);
        Base<item_T> *mask = algebra::Get(mask_1D, i);
        item_T head = candidate[algebra::Get(axis, 0)];
        if (mask->KeyMatch(head)
                and mask->Value(head)->KeyMatch(
                        candidate[algebra::Get(axis, 1)])) {
            continue;
        } else {
            return false;
        }
    }
    return true;
}

template<typename item_T>
Base<item_T> *PipelineRecursion(axis_1D_T<item_T> &merge_axis_1D,
        base_1D_T<item_T> &merge_1D, axis_2D_T<item_T> &mask_axis_2D,
        base_2D_T<item_T> &mask_2D, item_T *candidate, size_type level) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    size_type next_level = level + 1;
    size_type index = level + 2;
    if (merge_1D[level]->KeyMatch(
            candidate[algebra::Get(merge_axis_1D[level], 0)])) {
        for (iterator_T<item_T> *pair = merge_1D[level]->Value(
                candidate[merge_axis_1D[level]->at(0)])->CreateIterator();
                nestedmap::InRange(pair); pair->Advance()) {
            candidate[index] = pair->Key();
            if (PipelineMatchAll(mask_axis_2D[level], mask_2D[level],
                    candidate)) {
                if (next_level == merge_axis_1D.size()) {
                    result->Insert(pair->Key());
                } else {
                    result->InsertNonEmpty(pair->Key(),
                            PipelineRecursion(merge_axis_1D, merge_1D,
                                    mask_axis_2D, mask_2D, candidate,
                                    next_level));
                }
            }
        }
    }
    return result;
}

template<typename item_T>
Base<item_T> *Reduce(Base<item_T> *left, axis_T<item_T> *axis) {
    // reduce axis can be nullptr or 2 axis
    Base<item_T> *result = new NestedMapUniform<item_T>();
    size_type head = 0;
    size_type tail = left->ColumnSize() - 1;
    if (axis != nullptr) {
        head = axis->front();
        tail = axis->back();
    }
    item_T dummy = 0;
    return ReduceRecursion(result, left, dummy, dummy, (int) head, (int) tail);
}

template<typename item_T>
Base<item_T> *ReduceRecursion(Base<item_T> *result, Base<item_T> *left,
        item_T head, item_T tail, int head_diff, int tail_diff) {
    bool find_head = (head_diff == 0);
    bool find_tail = (tail_diff == 0);
    bool find_both = (head_diff < 1) && (tail_diff < 1);
    head_diff--;
    tail_diff--;
    for (iterator_T<item_T> *pair = left->CreateIterator();
            nestedmap::InRange(pair); pair->Advance()) {
        if (find_head) {
            head = pair->Key();
        } else if (find_tail) {
            tail = pair->Key();
        }
        if (find_both) {
            Base<item_T> *value = pair->Value();
            item_T count = 1;
            if (value != nullptr) {
                count = value->RowSize();
            }
            result->AddToKey(head, tail, count);
        } else {
            ReduceRecursion(result, pair->Value(), head, tail, head_diff,
                    tail_diff);
        }
    }
    return result;
}

template<typename item_T>
inline Base<item_T> *Scale(Base<item_T> *op, algebra::scalar_t scalar) {
    return ScaleRecursion(op, scalar, op->ColumnSize());
}

template<typename item_T>
Base<item_T> *ScaleRecursion(Base<item_T> *op, algebra::scalar_t scalar,
        size_type remaining_axis) {
    Base<item_T> *result = new NestedMapUniform<item_T>();
    if (remaining_axis == 1) {
        // end of recursion
        for (iterator_T<item_T> *pair = op->CreateIterator();
                nestedmap::InRange(pair); pair->Advance()) {
            result->Insert(pair->Key() * scalar);
        }
        return result;
    }
    remaining_axis--;
    for (iterator_T<item_T> *pair = op->CreateIterator();
            nestedmap::InRange(pair); pair->Advance()) {
        result->Insert(pair->Key(),
                ScaleRecursion(pair->Value(), scalar, remaining_axis));
    }
    return result;
}

template<typename item_T>
inline Base<item_T> *Transpose(Base<item_T> *op, axis_T<item_T> *axis) {
    if (axis == nullptr) {
        return op->DeepCopy();
    }
    Base<item_T> *result = new NestedMapUniform<item_T>();
    std::vector<item_T> partial;
    return TransposeRecursion(result, op, partial, axis);
}

template<typename item_T>
Base<item_T> *TransposeRecursion(Base<item_T> *result, Base<item_T> *op,
        std::vector<item_T> &partial, axis_T<item_T> *axis) {
    for (iterator_T<item_T> *pair = op->CreateIterator();
            nestedmap::InRange(pair); pair->Advance()) {
        partial.push_back(pair->Key());
        if (pair->Value() == nullptr) {
            std::deque<item_T> tranposed;
            for (const auto &index : (*axis)) {
                tranposed.push_back(partial[index]);
            }
            result->PushBack(tranposed);
        } else {
            TransposeRecursion(result, pair->Value(), partial, axis);
        }
        partial.pop_back();
    }
    return result;
}

} // namespace nestedmap_operation

#endif /* ALGEBRA_STORAGE_NESTEDMAP_OPERATION_HPP_ */
