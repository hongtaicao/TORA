/*
 * storage.hpp
 *
 *  Created on: 2020-3-31 6:17
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_STORAGE_STORAGE_HPP_
#define ALGEBRA_STORAGE_STORAGE_HPP_

#include <string>

#include "algebra/argparser.hpp"
#include "algebra/basetype.hpp"
#include "algebra/storage/convert/table2d.hpp"

namespace algebra {

template<typename item_T>
class Storage {
public:
    typedef T_1D<query_size_t> axis_t;
    typedef T_1D<axis_t *> axis_1D_t;
    typedef T_1D<axis_1D_t *> axis_2D_t;
    typedef T_1D<Storage<item_T> *> storage_1D_t;
    typedef T_1D<storage_1D_t *> storage_2D_t;
    Storage() {
    }
    virtual ~Storage() {
    }

    // delete copy
    Storage(const Storage<item_T> &) = delete;
    Storage<item_T> &operator=(const Storage<item_T> &) = delete;

    /*
     * implement all of them in the derived class
     */
    // operation method
    virtual Storage<item_T> *Mask(Storage<item_T> *) = 0;
    virtual Storage<item_T> *MaskMerge(Storage<item_T> *,
            Storage<item_T> *) = 0;
    virtual Storage<item_T> *MaskAxisMerge(Storage<item_T> *, axis_2D_t &,
            storage_1D_t &) = 0;
    virtual Storage<item_T> *MaskAxisMergeAxis(axis_t &, Storage<item_T> *,
            axis_2D_t &, storage_1D_t &) = 0;
    virtual Storage<item_T> *cMaskAxisMergeAxis(axis_t &, Storage<item_T> *,
            axis_1D_t &, storage_1D_t &) = 0;
    virtual Storage<item_T> *Mask_Merge__by(Storage<item_T> *, storage_1D_t &,
            const std::string &) = 0;
    virtual Storage<item_T> *Merge(Storage<item_T> *) = 0;
    virtual Storage<item_T> *Minus(Storage<item_T> *) = 0;
    virtual Storage<item_T> *Pipeline(axis_1D_t &, storage_1D_t &, axis_2D_t &,
            storage_2D_t &) = 0;
    virtual Storage<item_T> *Reduce(axis_t *) = 0;
    virtual Storage<item_T> *Scale(scalar_t) = 0;
    virtual Storage<item_T> *Transpose(axis_t *) = 0;

    // construction
    virtual void Insert(const item_T &, const item_T &) = 0;
    virtual void Sorted() = 0;

    // property function
    virtual size_type ColumnSize() = 0;
    virtual size_type ElementSum() = 0; // sum of values on the 3rd axis
    inline size_type MatchCount() {
        return this->RowSize();
    }
    virtual size_type RowSize() = 0;
    virtual void WriteData(const ArgParser &, const std::string &) = 0;

    // conversion function
    virtual void To_2D(convert::Table2D<item_T> &) = 0;
};

template<typename storage_T>
inline bool EmptyResult(storage_T *storage) {
    return storage->ColumnSize() == 0;
}

template<typename storage1_T, typename storage2_T>
inline bool EmptyResult(storage1_T *left, storage2_T *right) {
    return EmptyResult(left) or EmptyResult(right);
}

template<typename storage1_T, typename storage2_T, typename storage3_T>
inline bool EmptyResult(storage1_T *left, storage2_T *right, storage3_T *mask) {
    return EmptyResult(left, right) or EmptyResult(mask);
}

template<typename storage_1D_T>
bool EmptyResult1D(storage_1D_T &storage_1D) {
    for (auto &storage : storage_1D) {
        if (storage->ColumnSize() == 0) {
            return true;
        }
    }
    return false;
}

template<typename storage_2D_T>
bool EmptyResult2D(storage_2D_T &storage_2D) {
    for (auto &storage_1D : storage_2D) {
        if (EmptyResult1D(*storage_1D)) {
            return true;
        }
    }
    return false;
}

}

#endif /* ALGEBRA_STORAGE_STORAGE_HPP_ */
