/*
 * coordinate2d.hpp
 *
 *  Created on: 2020-4-5 5:40
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_STORAGE_CONVERT_COORDINATE2D_HPP_
#define ALGEBRA_STORAGE_CONVERT_COORDINATE2D_HPP_

#include <algorithm>
#include <unordered_map>
#include <vector>

#include "algebra/basetype.hpp"
#include "algebra/utility/compare.hpp"

/*
 * forward declare is incomplete. can only use it via pointers
 * https://stackoverflow.com/a/15076125/11193802
 */
/*
 * forward declare within namespace
 * https://stackoverflow.com/a/43653736/11193802
 */
namespace relation {

template<typename item_T>
class Operation;

}

namespace convert {

template<typename item_T>
using T_column = std::unordered_map<item_T, item_T>;

template<typename item_T>
class Coordinate2D {
public:
    Coordinate2D() {
    }
    ~Coordinate2D() {
    }

    Coordinate2D(const Coordinate2D<item_T> &) = delete;
    Coordinate2D<item_T> &operator=(const Coordinate2D<item_T> &) = delete;

    template<typename value_T>
    void Add(Coordinate2D<item_T> &other, const value_T scalar) {
        for (const auto &outer : other.data_) {
            item_T coo1 = outer.first;
            if (this->data_.count(coo1) == 0) {
                this->data_[coo1] = T_column<item_T>();
            }
            for (const auto &inner : outer.second) {
                item_T coo2 = inner.first;
                item_T value = inner.second * scalar;
                if (this->data_[coo1].count(coo2) > 0) {
                    value += this->data_[coo1][coo2];
                }
                this->data_[coo1][coo2] = value;
            }
        }
    }

    void Add(item_T coo1, item_T coo2) {
        if (this->data_.count(coo1) == 0) {
            this->data_[coo1] = T_column<item_T>();
            this->data_[coo1][coo2] = 1;
        } else {
            this->data_[coo1][coo2]++;
        }
    }

    void Add(const item_T &coo1, const item_T &coo2, const item_T &value) {
        if (this->data_.count(coo1) == 0) {
            this->data_[coo1] = T_column<item_T>();
            this->data_[coo1][coo2] = 0;
        } else if (this->data_[coo1].count(coo2) == 0) {
            this->data_[coo1][coo2] = 0;
        }
        this->data_[coo1][coo2] += value;
    }

    relation::Operation<item_T> *Create(relation::Operation<item_T> *target) {
        // used for reduce operation using relation
        relation::Operation<item_T> *result = target->CreateRelation();
        std::vector<item_T> outer_keys;
        this->SortKey(outer_keys, this->data_);
        for (const auto &key1 : outer_keys) {
            auto column = this->data_[key1];
            std::vector<item_T> inner_keys;
            this->SortKey(inner_keys, column);
            for (const auto &key2 : inner_keys) {
                result->PushBack(key1, key2, column[key2]);
            }
        }
        return result;
    }

    bool Equal(const Coordinate2D<item_T> &) const;
    inline bool Has(const item_T &row, const item_T &col,
            const item_T &value) const {
        if (this->data_.count(row) > 0) {
            if (this->data_.at(row).count(col) > 0) {
                if (this->data_.at(row).at(col) == value) {
                    return true;
                }
            }
        }
        return false;
    }
    inline bool HasKey(const item_T &key) const {
        return this->data_.count(key) > 0;
    }
    inline algebra::size_type KeySize() const {
        return this->data_.size();
    }
    inline algebra::size_type KeySize(const item_T &key) const {
        return this->data_.at(key).size();
    }
    algebra::size_type Sum() const;

private:
    template<typename map_T>
    void SortKey(std::vector<item_T> &sortedkeys, const map_T &);

    std::unordered_map<item_T, T_column<item_T>> data_;
};

// https://stackoverflow.com/a/8640408/11193802
template<typename item_T>
template<typename map_T>
void Coordinate2D<item_T>::SortKey(std::vector<item_T> &sortedkeys,
        const map_T &data) {
    sortedkeys.reserve(this->data_.size());
    for (const auto &pair : data) {
        sortedkeys.push_back(pair.first);
    }
    std::sort(sortedkeys.begin(), sortedkeys.end());
}

template<typename item_T>
bool Coordinate2D<item_T>::Equal(const Coordinate2D<item_T> &other) const {
    if (this->KeySize() != other.KeySize()) {
        return false;
    }
    for (auto &pair : this->data_) {
        if (not other.HasKey(pair.first)) {
            return false;
        }
        if (pair.second.size() != other.KeySize(pair.first)) {
            return false;
        }
        for (auto &inner : pair.second) {
            if (not other.Has(pair.first, inner.first, inner.second)) {
                return false;
            }
        }
    }
    return true;
}

template<typename item_T>
algebra::size_type Coordinate2D<item_T>::Sum() const {
    algebra::size_type sum = 0;
    for (const auto &pair : this->data_) {
        for (const auto &inner : pair.second) {
            sum += inner.second;
        }
    }
    return sum;
}

} // namespace convert

#endif /* ALGEBRA_STORAGE_CONVERT_COORDINATE2D_HPP_ */
