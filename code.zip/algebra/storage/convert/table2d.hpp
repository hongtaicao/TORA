/*
 * table2d.hpp
 *
 *  Created on: 2020-7-20 17:08
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_STORAGE_CONVERT_TABLE2D_HPP_
#define ALGEBRA_STORAGE_CONVERT_TABLE2D_HPP_

#include <algorithm>

#include "algebra/basetype.hpp"
#include "algebra/utility/access.hpp"
#include "algebra/utility/compare.hpp"

namespace convert {

template<typename item_T>
class Coordinate2D;

template<typename item_T>
class Table2D {
    typedef algebra::size_type size_type;
public:
    typedef algebra::T_1D<item_T> item_1D_t;
    typedef algebra::T_1D<item_1D_t *> item_2D_t;

    Table2D() {
    }
    ~Table2D() {
        algebra::DeleteContent(this->table_2D_);
    }

    Table2D(const Table2D<item_T> &) = delete;
    Table2D<item_T> &operator=(const Table2D<item_T> &) = delete;

    bool operator==(const Table2D<item_T> &) const;

    inline size_type ColumnSize() const {
        if (this->RowSize() == 0) {
            return 0;
        }
        return this->table_2D_[0]->size();
    }
    inline item_1D_t *Get(const size_type index) const {
        return this->table_2D_[index];
    }
    bool IsRectangle() const;
    inline void PushBack(item_1D_t *item) {
        this->table_2D_.push_back(new item_1D_t(*item));
    }
    inline size_type RowSize() const {
        return this->table_2D_.size();
    }
    inline void Sort() {
        this->SortColumn();
        std::sort(this->table_2D_.begin(), this->table_2D_.end(),
                algebra::Compare1DAscend<item_1D_t>);
    }
    void SortColumn();
    void SortRow() {
        std::sort(this->table_2D_.begin(), this->table_2D_.end(),
                algebra::Compare1DHeadAscend<item_1D_t>);
    }
    bool ToCoordinate2D(Coordinate2D<item_T> &) const;

private:
    item_2D_t table_2D_;
};

template<typename item_T>
bool Table2D<item_T>::operator==(const Table2D<item_T> &other) const {
    if (this->RowSize() != other.RowSize()) {
        return false;
    }
    if (this->ColumnSize() != other.ColumnSize()) {
        return false;
    }
    for (size_type i = 0; i < this->RowSize(); i++) {
        if (not algebra::Equal1D(this->Get(i), other->Get(i))) {
            return false;
        }
    }
    return true;
}

template<typename item_T>
bool Table2D<item_T>::IsRectangle() const {
    size_type column_size = this->ColumnSize();
    for (auto &item : this->table_2D_) {
        if (column_size != item->size()) {
            return false;
        }
    }
    return true;
}

template<typename item_T>
void Table2D<item_T>::SortColumn() {
    for (auto &item : this->table_2D_) {
        std::sort(item->begin(), item->end());
    }
}

template<typename item_T>
bool Table2D<item_T>::ToCoordinate2D(Coordinate2D<item_T> &result) const {
    if (this->RowSize() == 0) {
        return true;
    }
    if ((not this->IsRectangle()) or (this->ColumnSize() != 3)) {
        return false;
    }
    for (auto &item_1D : this->table_2D_) {
        result.Add(algebra::Get(item_1D, 0), algebra::Get(item_1D, 1),
                algebra::Get(item_1D, 2));
    }
    return true;
}

} // namespace convert

#endif /* ALGEBRA_STORAGE_CONVERT_TABLE2D_HPP_ */
