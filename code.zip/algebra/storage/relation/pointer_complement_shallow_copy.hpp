/*
 * pointer_complement_shallow_copy.hpp
 *
 *  Created on: 2020-4-3 8:35
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_STORAGE_RELATION_POINTER_COMPLEMENT_SHALLOW_COPY_HPP_
#define ALGEBRA_STORAGE_RELATION_POINTER_COMPLEMENT_SHALLOW_COPY_HPP_

#include <assert.h>
#include <iostream>
#include <stdexcept>

#include "algebra/storage/relation/pointer.hpp"

namespace relation_pointer {

/*
 * search space: all the edges in the total order space
 * data_: the complementary of non-edge
 * head_, tail_: the total order of edge in all node pair
 */
template<typename item_T>
class ComplementShallowCopy: public Pointer<item_T> {
public:
    ComplementShallowCopy(T_tuple_1D<item_T> *data, size_type max_index,
            size_type min_index, size_type max_range, size_type min_range,
            size_type node_count, size_type row_size)
            : Pointer<item_T>(data), max_index_(max_index),
              min_index_(min_index), max_range_(max_range),
              min_range_(min_range), node_count_(node_count),
              row_size_(row_size) {
    }
    virtual ~ComplementShallowCopy() {
    }

    // pipeline method
    inline T_tuple<item_T> &GetTupleAt(size_type total_order) override {
        this->nonedge_ = std::make_shared<T_1D<item_T>>(
                T_1D<item_T> { this->FromNode(total_order), this->ToNode(
                        total_order) });
        return this->nonedge_;
    }
    inline Pointer<item_T> *ShallowCopy() {
        return new ComplementShallowCopy(this->data_, this->max_index_,
                this->min_index_, this->max_range_, this->min_range_,
                this->node_count_, this->row_size_);
    }

    // data read
    T_1D<item_T> *GetMid(size_type &middle, size_type head, size_type tail)
            override;

    // helper method
    inline size_type GetHead(int offset) override {
        // this->head_: the total order of a non-edge
        if (offset < 0) {
            return this->GetHeadClosePrev(this->head_ + offset);
        }
        return this->GetHeadCloseNext(this->head_ + offset);
    }
    inline size_type MaxRange() override {
        // the max total order
        return this->max_range_;
    }
    inline size_type MinRange() override {
        // the max total order
        return this->min_range_;
    }
    /*
     * try to set head with the given total order
     * if given total order is an edge, find the next available non-edge
     */
    inline void SetHeadCloseNext(size_type total_order) override {
        this->head_ = this->GetHeadCloseNext(total_order);
    }
    inline void SetNodeCount(size_type node_count) {
        this->node_count_ = node_count;
        // need to set other parameters
        assert(false);
    }

    // property method
    inline size_type RowSize() override {
        return this->row_size_;
    }

protected:
    // find edge total order given the index
    inline size_type EdgeTotalOrder(size_type index) {
        auto tuple = (*this->data_)[index];
        return (*tuple)[0] * this->node_count_ + (*tuple)[1];
    }

    /*
     * need both
     * externally: binary search space is represented by total order
     * internally: complement search space is represented by index_
     * functions convert the search space from total order -> index
     */
    // index search range, used when binary search directly on this->data_
    size_type max_index_;
    size_type min_index_;
    // total order search range, used when search on the complement
    size_type max_range_;
    size_type min_range_;
    // graph node numbered from 0
    size_type node_count_;
    // total number of non-edge
    size_type row_size_;

private:
    // convert total order <-> total edge
    /*
     * find the edge index in this->data_
     * such that the edge is greater or equal to the given edge
     */
    size_type EdgeCloseNext(item_T from_node, item_T to_node);
    size_type EdgeClosePrev(item_T from_node, item_T to_node);
    // convert total order to node number
    inline item_T FromNode(size_type total_order) {
        return total_order / this->node_count_;
    }
    size_type GetHeadCloseNext(size_type);
    size_type GetHeadClosePrev(size_type);
    inline item_T ToNode(size_type total_order) {
        return total_order % this->node_count_;
    }
    // temporal data
    T_tuple<item_T> nonedge_;

};

/*
 * find the middle that point to an non-edge
 * total order search range [head, tail)
 * it is guaranteed that middle exists within the range
 */
template<typename item_T>
T_1D<item_T> * ComplementShallowCopy<item_T>::GetMid(size_type &middle,
        size_type head, size_type tail) {
    // tail is not a non-edge total order
    middle = head + (tail - head) / 2;
    size_type index_prev = this->EdgeClosePrev(this->FromNode(middle),
            this->ToNode(middle));
    if (this->EdgeTotalOrder(index_prev) != middle) {
        return this->GetAt(middle);
    }
    size_type index_next = this->EdgeCloseNext(this->FromNode(middle),
            this->ToNode(middle));
    if (this->EdgeTotalOrder(index_next) != middle) {
        return this->GetAt(middle);
    }
    auto max_offset = middle - head;
    for (size_type offset = 1; offset <= max_offset; offset++) {
        if (index_prev > this->min_index_) {
            index_prev--;
            if (this->EdgeTotalOrder(index_prev) != middle - offset) {
                middle -= offset;
                return this->GetAt(middle);
            }
        }
        if (index_next < this->max_index_) {
            index_next++;
            if (this->EdgeTotalOrder(index_next) != middle + offset)
                middle += offset;
            return this->GetAt(middle);
        }
    }
    std::cout << "head: " << head << " tail: " << tail << std::endl;
    std::cout << "middle: " << middle << " max_offset: " << max_offset
            << std::endl;
    throw std::runtime_error(
            "ComplementShallowCopy<item_T>::GetMid invalid search space");
}

/*
 * return an index to this->data_
 */
template<typename item_T>
size_type ComplementShallowCopy<item_T>::EdgeCloseNext(item_T from_node,
        item_T to_node) {
    size_type head = this->min_index_;
    size_type mid = 0;
    size_type tail = this->max_index_;
    while (head < tail) {
        mid = head + (tail - head) / 2;
        auto front = (*this->data_)[mid]->front();
        if (front < from_node) {
            head = mid + 1;
        } else if (front > from_node) {
            tail = mid;
        } else {
            auto back = (*this->data_)[mid]->back();
            if (back < to_node) {
                head = mid + 1;
            } else if (back > to_node) {
                tail = mid;
            } else {
                return mid;
            }
        }
    }
    return head;
}

/*
 * return an index to this->data_
 * find an edge smaller or equal to the given edge
 */
template<typename item_T>
size_type ComplementShallowCopy<item_T>::EdgeClosePrev(item_T from_node,
        item_T to_node) {
    size_type head = this->min_index_;
    size_type mid = 0;
    size_type tail = this->max_index_;
    while (head < tail - 1) {
        mid = head + (tail - head) / 2;
        auto front = (*this->data_)[mid]->front();
        if (front < from_node) {
            if (head == mid) {
                return head;
            }
            head = mid;
        } else if (front > from_node) {
            tail = mid;
        } else {
            auto back = (*this->data_)[mid]->back();
            if (back < to_node) {
                head = mid;
            } else if (back > to_node) {
                tail = mid;
            } else {
                return mid;
            }
        }
    }
    return head;
}

/*
 * return the smallest total order of a non-edge larger than the given
 */
template<typename item_T>
size_type ComplementShallowCopy<item_T>::GetHeadCloseNext(
        size_type total_order) {
    size_type index = this->EdgeCloseNext(this->FromNode(total_order),
            this->ToNode(total_order));
    while ((total_order == this->EdgeTotalOrder(index))
            && (total_order < this->max_range_)) {
        if (index < this->max_index_) {
            index++;
        }
        total_order++;
    }
    return total_order;
}

/*
 * return the largest total order of a non-edge smaller than given
 */
template<typename item_T>
size_type ComplementShallowCopy<item_T>::GetHeadClosePrev(
        size_type total_order) {
    size_type index = this->EdgeClosePrev(this->FromNode(total_order),
            this->ToNode(total_order));
    while ((total_order == this->EdgeTotalOrder(index))
            && total_order > this->min_range_) {
        if (index > this->min_index_) {
            index--;
        }
        total_order--;
    }
    return total_order;
}

}

#endif /* ALGEBRA_STORAGE_RELATION_POINTER_COMPLEMENT_SHALLOW_COPY_HPP_ */
