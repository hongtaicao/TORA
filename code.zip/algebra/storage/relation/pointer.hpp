/*
 * pointer.hpp
 *
 *  Created on: 2020-3-26 9:17
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_STORAGE_RELATION_POINTER_HPP_
#define ALGEBRA_STORAGE_RELATION_POINTER_HPP_

#include <memory>

#include "algebra/basetype.hpp"
#include "algebra/storage/relation/operation.hpp"
#include "algebra/storage/storage.hpp"

namespace relation_pointer {

template<typename item_T>
using Operation = relation::Operation<item_T>;

template<typename item_T>
using Storage = relation::Storage<item_T>;

template<typename item_T>
using T_1D = relation::T_1D<item_T>;

template<typename item_T>
using T_tuple = std::shared_ptr<T_1D<item_T>>;

template<typename item_T>
using T_tuple_1D = T_1D<T_tuple<item_T>>;

typedef relation::size_type size_type;

// https://stackoverflow.com/a/18783410/11193802
// struct: actual template argument deduction is postponed until known
struct AscendVector {
    template<typename tuple_T>
    bool operator()(tuple_T &a, tuple_T &b) const {
        if (relation::CompareVector(*a, *b) > 0) {
            return false;
        }
        return true;
    }
};

// forward declaration
template<typename item_T>
class Relation;

template<typename item_T>
class Pointer: public Operation<item_T> {
public:
    typedef typename Operation<item_T>::axis_t axis_t;

    Pointer(T_tuple_1D<item_T> *data)
            : Operation<item_T>(0, 0), data_(data) {
    }
    virtual ~Pointer() {
        // delete is handled by sub-class
        // should not delete this->data_ if it is a ShallowCopy
    }

    virtual Pointer<item_T> *ShallowCopy() override = 0;

    // pipeline method
    inline T_tuple<item_T> &GetTuple() {
        return this->GetTupleAt(this->head_);
    }
    virtual T_tuple<item_T> &GetTupleAt(size_type) = 0;

    // data constructor method
    inline Pointer<item_T> *CreateRelation() override {
        return new Relation<item_T> ;
    }

    // data read method
    inline T_1D<item_T> *Get() override {
        return this->GetTuple().get();
    }
    inline T_1D<item_T> *GetAt(size_type head) override {
        return this->GetTupleAt(head).get();
    }
    virtual T_1D<item_T> *GetMid(size_type &, size_type, size_type)
            override = 0;

    // data write
    inline void PushBack(Operation<item_T> *other) override {
        this->data_->push_back(this->ToThis(other)->GetTuple());
    }
    inline void PushBack(const item_T &a, const item_T &b) override {
        this->data_->push_back(std::make_shared<T_1D<item_T>>(T_1D<item_T> { a,
                b }));
    }
    inline void PushBack(const item_T &a, const item_T &b, const item_T &c)
            override {
        this->data_->push_back(std::make_shared<T_1D<item_T>>(T_1D<item_T> { a,
                b, c }));
    }
    inline void PushBackAt(Operation<item_T> *other, size_type cursor)
            override {
        this->data_->push_back(this->ToThis(other)->GetTupleAt(cursor));
    }
    inline void PushBackAxis(Operation<item_T> *other, axis_t *axis) override {
        T_tuple<item_T> tuple = std::make_shared<T_1D<item_T>>();
        for (const auto &ax : (*axis)) {
            tuple->push_back(other->Element(ax));
        }
        this->data_->push_back(tuple);
    }
    inline void PushBackMerge(const T_1D<item_T> &vec, const item_T &a)
            override {
        T_tuple<item_T> &&result = std::make_shared<T_1D<item_T>>(vec);
        result->push_back(a);
        this->data_->push_back(result);
    }
    inline void PushBackTuple(const T_tuple<item_T> &tuple) {
        this->data_->push_back(tuple);
    }
    inline Operation<item_T> *Sorted() override {
        std::sort(this->data_->begin(), this->data_->end(), AscendVector());
        return this;
    }

    // helper method
    // return the adjusted head with given offset
    virtual size_type GetHead(int) override = 0;
    // search range
    virtual size_type MaxRange() override = 0;
    virtual size_type MinRange() override = 0;
    // set head to the given value greater or equal
    virtual void SetHeadCloseNext(size_type) override = 0;

    // property method
    virtual size_type RowSize() override = 0;

    /*
     * if subclass creates data_, then it is responsible for deletion
     * if subclass is a shallow copy, then don't delete this
     */
    T_tuple_1D<item_T> *data_;

private:
    inline Pointer<item_T> *ToThis(Operation<item_T> *other) {
        return (Pointer<item_T> *) other;
    }
};

} // namespace relation_pointer

#endif /* ALGEBRA_STORAGE_RELATION_POINTER_HPP_ */
