/*
 * operation.hpp
 *
 * implement all the public methods for relation computation operation
 * internal data storage and access are pending
 *
 *  Created on: 2020-3-26 8:52
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_STORAGE_RELATION_OPERATION_HPP_
#define ALGEBRA_STORAGE_RELATION_OPERATION_HPP_

#include <algorithm>
#include <assert.h>
#include <string>
#include <unordered_set>
#include <unordered_map>
#include <vector>

#include "algebra/basetype.hpp"
#include "algebra/storage/convert/coordinate2d.hpp"
#include "algebra/storage/convert/table2d.hpp"
#include "algebra/storage/storage.hpp"
#include "algebra/utility/access.hpp"

namespace relation {

typedef algebra::size_type size_type;

template<typename item_T>
using Storage = algebra::Storage<item_T>;

template<typename item_T>
using T_1D = algebra::T_1D<item_T>;

/*
 * binary search / scanning
 * if the same Front is short, then it is better just scan it
 */

// https://stackoverflow.com/a/9352338/11193802
// template class methods must be in header files
template<typename item_T>
class Operation: public Storage<item_T> {
public:
    typedef typename Storage<item_T>::axis_t axis_t;
    typedef typename Storage<item_T>::axis_2D_t axis_2D_t;
    typedef typename Storage<item_T>::storage_1D_t storage_1D_t;
    typedef algebra::scalar_t scalar_t;

    Operation(size_type head, size_type tail)
            : head_(head), tail_(tail) {
    }
    virtual ~Operation() {
    }

    // operation
    inline Operation<item_T> *Mask(Storage<item_T> *other) override {
        Operation<item_T> *copy = ((Operation<item_T> *) other)->ShallowCopy();
        Operation<item_T> *result = this->MaskSS(copy);
        delete copy;
        return result;
    }
    inline Operation<item_T> *MaskMerge(Storage<item_T> *right,
            Storage<item_T> *mask) override {
        Operation<item_T> *right_copy =
                ((Operation<item_T> *) right)->ShallowCopy();
        Operation<item_T> *mask_copy =
                ((Operation<item_T> *) mask)->ShallowCopy();
        Operation<item_T> *partial = this->Merge(right_copy);
        Operation<item_T> *result = partial->Mask(mask_copy);
        delete right_copy;
        delete mask_copy;
        delete partial;
        return result;
    }
    inline Operation<item_T> *MaskTransposeMerge(Storage<item_T> *,
            storage_1D_t &, axis_2D_t &) override {
        throw "NotImplemented: relation.MaskTransposeMerge()";
    }
    Operation<item_T> *Merge(Storage<item_T> *) override;
    inline Operation<item_T> *Minus(Storage<item_T> *other) override {
        Operation<item_T> *copy = ((Operation<item_T> *) other)->ShallowCopy();
        Operation<item_T> *result = this->MinusSS(copy);
        delete copy;
        return result;
    }
    Operation<item_T> *Reduce(axis_t *) override;
    Operation<item_T> *Scale(scalar_t) override;
    Operation<item_T> *Transpose(axis_t *) override;
    virtual Operation<item_T> *ShallowCopy() = 0;

    // property method
    inline size_type ColumnSize() override {
        if (this->RowSize() > 0) {
            return this->GetAt(0)->size();
        }
        return 0;
    }
    size_type ElementSum() override;
    virtual size_type RowSize() override = 0;

    // conversion
    void To_2D(convert::Table2D<item_T> &) override;

    // computation method
    // MaskBB: (binary_search, binary_search)
    Operation<item_T> *MaskBB(Storage<item_T> *);
    void AddTailOfFrontTarget(const item_T &, std::unordered_set<item_T> &);
    void SetHeadAsFront(const item_T &);
    // MaskSB: (scan, binary_search)
    Operation<item_T> *MaskSB(Storage<item_T> *);
    bool BinarySearchHeadRange(const item_T &);
    bool BinarySearchTail(const item_T &);
    // MaskSS: (scan, scan)
    Operation<item_T> *MaskSS(Storage<item_T> *);
    bool ScanHead(const item_T &);
    // Merge
    bool BinarySearchInRight(const T_1D<item_T> &);
    // MinusSB (scan, binary search)
    Operation<item_T> *MinusSB(Storage<item_T> *);
    bool BinarySearch(const T_1D<item_T> &);
    // MinusSS (scan, scan)
    Operation<item_T> *MinusSS(Storage<item_T> *);
    bool Scan(const T_1D<item_T> &);

    // data constructor method
    virtual Operation<item_T> *CreateRelation() = 0;

    // data read method
    inline item_T Back() {
        return this->Get()->back();
    }
    inline item_T BackAt(size_type head) {
        return this->GetAt(head)->back();
    }
    inline item_T Element(size_type position) {
        return algebra::Get(this->Get(), position);
    }
    inline item_T ElementAt(size_type head, size_type position) {
        return algebra::Get(this->GetAt(head), position);
    }
    inline item_T Front() {
        return this->Get()->front();
    }
    inline item_T FrontAt(size_type head) {
        return this->GetAt(head)->front();
    }
    virtual T_1D<item_T> *Get() = 0;
    virtual T_1D<item_T> *GetAt(size_type) = 0;
    virtual T_1D<item_T> *GetMid(size_type &, size_type, size_type) = 0;

    // data write
    virtual void PushBack(Operation<item_T> *) = 0;
    virtual void PushBack(const item_T &, const item_T &) override = 0;
    virtual void PushBack(const item_T &, const item_T &, const item_T &) = 0;
    virtual void PushBackAt(Operation<item_T> *, size_type) = 0;
    virtual void PushBackAxis(Operation<item_T> *, axis_t *) = 0;
    virtual void PushBackMerge(const T_1D<item_T> &, const item_T &) = 0;
    virtual Operation<item_T> *Sorted() = 0;

    // helper method
    inline void Advance() {
        this->head_ = this->GetHead(1);
    }
    virtual size_type GetHead(int) = 0;
    inline bool Initialize() {
        this->head_ = this->MinRange();
        this->tail_ = this->MaxRange();
        return true;
    }
    inline bool InRange() {
        return this->InRangeAt(this->head_);
    }
    inline bool InRangeAt(size_type cursor) {
        return (cursor >= this->MinRange()) && (cursor < this->MaxRange());
    }
    // search range
    virtual size_type MaxRange() = 0;
    virtual size_type MinRange() = 0;
    virtual void SetHeadCloseNext(size_type) = 0;

    size_type head_, tail_;
};

template<typename item_T>
int CompareVector(const T_1D<item_T> &a, const T_1D<item_T> &b) {
    assert(a.size() == b.size());
    for (size_type i = 0; i < a.size() && i < b.size(); i++) {
        if (a[i] < b[i]) {
            return -1;
        } else if (a[i] > b[i]) {
            return 1;
        }
    }
    return 0;
}

template<typename item_T>
int MergeCompare(const T_1D<item_T> &left_vec, const T_1D<item_T> &right_vec) {
    assert(left_vec.size() == right_vec.size());
    for (size_type i = 1; i < left_vec.size(); i++) {
        if (left_vec[i] < right_vec[i - 1]) {
            return -1;
        } else if (left_vec[i] > right_vec[i - 1]) {
            return 1;
        }
    }
    return 0;
}

// MaskBB
template<typename item_T>
void Operation<item_T>::AddTailOfFrontTarget(const item_T &target,
        std::unordered_set<item_T> &tail) {
    tail.clear();
    while (this->InRange() && (this->Front() == target)) {
        tail.insert(this->Back());
        this->Advance();
    }
}

/*
 * assume front is sorted
 * binary search for the target value such that
 * cursor == this->data_->size()
 * or
 * this->data_->at(cursor)->front() >= target
 */
template<typename item_T>
void Operation<item_T>::SetHeadAsFront(const item_T &target) {
    auto middle = this->MaxRange();
    auto tail = this->MaxRange();
    // search for head
    while (this->head_ < tail) {
        if (this->GetMid(middle, this->head_, tail)->Front() < target) {
            this->SetHeadCloseNext(middle + 1);
        } else {
            tail = middle;
        }
    }
}

template<typename item_T>
Operation<item_T> *Operation<item_T>::MaskBB(Storage<item_T> *other) {
    // binary search / binary search
    Operation<item_T> *result = this->CreateRelation();
    Operation<item_T> *mask = (Operation<item_T> *) other;
    std::unordered_set<item_T> tail_set;
    this->Initialize();
    mask->Initialize();
    while (this->InRange() && mask->InRange()) {
        auto diff = this->Front() - mask->Front();
        if (diff < 0) {
            this->SetHeadAsFront(mask->Front());
        } else if (diff > 0) {
            mask->SetHeadAsFront(this->Front());
        } else {
            item_T target = this->Front();
            bool head_changed = (this->head_ == this->MinRange())
                    || (target != this->FrontAt(this->GetHead(-1)));
            if (head_changed) {
                mask->AddTailOfFrontTarget(target, tail_set);
            }
            if (tail_set.count(this->Back()) != 0) {
                result->PushBack(this);
            }
            this->Advance();
        }
    }
    return result;
}

// MaskSB
/*
 * mask: sorted on its first column
 * return true: mask[head, tail)[0] == value
 * return false: mask[head] > value && mask[head - 1] < value
 * edge cases: head == 0 or head == mask.size()
 */
template<typename item_T>
bool Operation<item_T>::BinarySearchHeadRange(const item_T &target) {
    auto middle = this->head_;
    auto temp = this->MaxRange();
    // search for head
    while (this->head_ < temp) {
        if (this->GetMid(middle, this->head_, temp)->front() < target) {
            this->SetHeadCloseNext(middle + 1);
        } else {
            temp = middle;
        }
    }
    if ((!this->InRange()) || (this->Front() != target)) {
        return false;
    }
    // search for tail
    temp = this->head_;
    this->tail_ = this->MaxRange();
    while (temp < this->tail_) {
        if (this->GetMid(middle, temp, this->tail_)->front() <= target) {
            temp = middle + 1;
        } else {
            this->tail_ = middle;
        }
    }
    return true;
}

/*
 * binary search value in mask[head, tail)[-1]
 * mask has exactly 2 columns
 * mask is hierarchical sorted on 1st column, then 2nd column
 */
template<typename item_T>
bool Operation<item_T>::BinarySearchTail(const item_T &target) {
    if (this->head_ >= this->tail_) {
        return false;
    }
    assert(
            (this->tail_ >= 1)
                    || this->Front() == this->FrontAt(this->tail_ - 1));
    assert(
            (!this->InRangeAt(this->tail_))
                    || (this->Front() != this->FrontAt(this->tail_)));
    auto head = this->head_;
    auto tail = this->tail_;
    auto middle = this->head_;
    // search for head
    while (head < tail) {
        if (this->GetMid(middle, head, tail)->back() < target) {
            head = middle + 1;
        } else {
            tail = middle;
        }
    }
    if ((this->InRangeAt(head)) && (this->BackAt(head) == target)) {
        return true;
    }
    return false;
}

template<typename item_T>
Operation<item_T> *Operation<item_T>::MaskSB(Storage<item_T> *other) {
    // scan / binary search
    Operation<item_T> *result = this->CreateRelation();
    Operation<item_T> *mask = (Operation<item_T> *) other;
    mask->Initialize();
    for (size_type i = 0; this->InRangeAt(i); i++) {
        item_T target = this->FrontAt(i);
        bool same_head = (i > 0) && (target == this->FrontAt(i - 1));
        if (same_head || mask->BinarySearchHeadRange(target)) {
            if (mask->BinarySearchTail(this->BackAt(i))) {
                // left operand is hierarchical sorted,
                // the last axis is not sorted
                // therefore BinarySearchTail can't adjust search range
                // this if condition is not efficient
                // because it search over tails that contain duplicates
                result->PushBackAt(this, i);
            }
        }
    }
    return result;
}

// MaskSS
template<typename item_T>
bool Operation<item_T>::ScanHead(const item_T &target) {
    while (this->InRange() && this->Front() < target) {
        this->Advance();
    }
    if (this->InRange() && (this->Front() == target)) {
        return true;
    }
    return false;
}

template<typename item_T>
Operation<item_T> *Operation<item_T>::MaskSS(Storage<item_T> *other) {
    // scan / scan
    Operation<item_T> *result = this->CreateRelation();
    Operation<item_T> *mask = (Operation<item_T> *) other;
    std::unordered_set<item_T> tail_set;
    mask->Initialize();
    for (this->Initialize(); this->InRange(); this->Advance()) {
        item_T target = this->Front();
        bool head_changed = (this->head_ == 0)
                || (target != this->FrontAt(this->head_ - 1));
        if (head_changed) {
            // need to clear tail
            tail_set.clear();
            if ((mask->InRange()) && (mask->ScanHead(target))) {
                mask->AddTailOfFrontTarget(target, tail_set);
                if (tail_set.count(this->Back()) != 0) {
                    result->PushBack(this);
                }
            }
        } else {
            if (tail_set.count(this->Back()) != 0) {
                result->PushBack(this);
            }
        }
    }
    return result;
}

// Merge
template<typename item_T>
bool Operation<item_T>::BinarySearchInRight(const T_1D<item_T> &left_vec) {
    auto tail = this->MaxRange();
    auto middle = tail;
    // binary search for head
    while (this->head_ < tail) {
        if (MergeCompare(left_vec, *this->GetMid(middle, this->head_, tail))
                > 0) {
            this->SetHeadCloseNext(middle + 1);
        } else {
            tail = middle;
        }
    }
    if ((this->InRange()) && (!MergeCompare(left_vec, *this->Get()))) {
        return true;
    }
    // ensure right[head] is the smallest >= left_vec
    return false;
}

template<typename item_T>
Operation<item_T> *Operation<item_T>::Merge(Storage<item_T> *other) {
    // scan / binary search
    Operation<item_T> *result = this->CreateRelation();
    Operation<item_T> *right = ((Operation<item_T> *) other)->ShallowCopy();
    for (this->Initialize(); this->InRange(); this->Advance()) {
        auto left_vec = this->Get();
        // find range
        right->Initialize();
        if (right->BinarySearchInRight(*left_vec)) {
            while ((right->InRange())
                    && (!MergeCompare(*left_vec, *right->Get()))) {
                result->PushBackMerge(*left_vec, right->Back());
                right->Advance();
            }
        }
    }
    delete right;
    return result;
}

// MinusSB
template<typename item_T>
bool Operation<item_T>::BinarySearch(const T_1D<item_T> &vector) {
    size_type middle = this->head_;
    size_type tail = this->MaxRange();
    int find = 0;
    while (this->head_ < tail) {
        find = CompareVector(*this->GetMid(middle, this->head_, tail), vector);
        if (find == 0) {
            this->SetHeadCloseNext(middle);
            return true;
        } else if (find < 0) {
            this->SetHeadCloseNext(middle + 1);
        } else {
            tail = middle;
        }
    }
    return false;
}

template<typename item_T>
Operation<item_T> *Operation<item_T>::MinusSB(Storage<item_T> *other) {
    // scan / binary search
    Operation<item_T> *result = this->CreateRelation();
    Operation<item_T> *right = (Operation<item_T> *) other;
    right->Initialize();
    for (this->Initialize(); this->InRange(); this->Advance()) {
        auto it = this->Get();
        if (!right->BinarySearch(*it)) {
            result->PushBack(this);
        }
    }
    return result;
}

// MinusSS
template<typename item_T>
bool Operation<item_T>::Scan(const T_1D<item_T> &vector) {
    while (this->InRange() && CompareVector(*this->Get(), vector) < 0) {
        this->Advance();
    }
    if (this->InRange() && CompareVector(*this->Get(), vector) == 0) {
        return true;
    }
    return false;
}

template<typename item_T>
Operation<item_T> *Operation<item_T>::MinusSS(Storage<item_T> *other) {
    // scan / scan
    Operation<item_T> *result = this->CreateRelation();
    Operation<item_T> *right = (Operation<item_T> *) other;
    right->Initialize();
    for (this->Initialize(); this->InRange(); this->Advance()) {
        auto it = this->Get();
        if (!right->Scan(*it)) {
            result->PushBack(this);
        }
    }
    return result;
}

template<typename item_T>
Operation<item_T> *Operation<item_T>::Reduce(axis_t *axis) {
    convert::Coordinate2D<item_T> coordinate;
    // reduce axis
    auto head = 0;
    auto tail = this->ColumnSize() - 1;
    if (axis != nullptr) {
        head = axis->front();
        tail = axis->back();
    }
    for (this->Initialize(); this->InRange(); this->Advance()) {
        coordinate.Add(this->Element(head), this->Element(tail));
    }
    return coordinate.Create(this);
}

template<typename item_T>
Operation<item_T> *Operation<item_T>::Scale(scalar_t scalar) {
    Operation<item_T> *result = this->CreateRelation();
    for (this->Initialize(); this->InRange(); this->Advance()) {
        result->PushBack(this->Front(), this->Element(1),
                scalar * this->Back());
    }
    return result;
}

template<typename item_T>
Operation<item_T> *Operation<item_T>::Transpose(axis_t *axis) {
    Operation<item_T> *result = this->CreateRelation();
    for (this->Initialize(); this->InRange(); this->Advance()) {
        result->PushBackAxis(this, axis);
    }
    return result->Sorted();
}

// report function
template<typename item_T>
size_type Operation<item_T>::ElementSum() {
    // requirement: a 3 attribute relation
    // (from_node, to_node, count)
    assert((this->RowSize() == 0) || (this->ColumnSize() == 3));
    size_type sum = 0;
    for (this->Initialize(); this->InRange(); this->Advance()) {
        sum += this->Back();
    }
    return sum;
}

template<typename item_T>
void Operation<item_T>::To_2D(convert::Table2D<item_T> &result) {
    for (this->Initialize(); this->InRange(); this->Advance()) {
        result.PushBack(this->Get());
    }
}

} //namespace algebra

#endif /* ALGEBRA_STORAGE_RELATION_OPERATION_HPP_ */
