/*
 * pointer_complement.hpp
 *
 *  Created on: 2020-4-2 11:49
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_STORAGE_RELATION_POINTER_COMPLEMENT_HPP_
#define ALGEBRA_STORAGE_RELATION_POINTER_COMPLEMENT_HPP_

#include <assert.h>
#include <memory>

#include "algebra/storage/relation/pointer.hpp"
#include "algebra/storage/relation/pointer_complement_shallow_copy.hpp"
#include "algebra/storage/relation/pointer_relation.hpp"

namespace relation_pointer {

template<typename item_T>
class Complement: public ComplementShallowCopy<item_T> {
public:
    Complement()
            : ComplementShallowCopy<item_T>(new T_tuple_1D<item_T>, 0, 0, 0, 0,
                    0, 0) {
    }
    Complement(Storage<item_T> *adj, Storage<item_T> *ut)
            : ComplementShallowCopy<item_T>(new T_tuple_1D<item_T>, 0, 0, 0, 0,
                    0, 0) {
        Adjacency<item_T> *adjacency = (Adjacency<item_T> *) adj;
        this->node_count_ = adjacency->NodeCount();
        this->CreateComplementary(adjacency, (Pointer<item_T> *) ut);
        this->SetRange();
        this->row_size_ = this->node_count_ * this->node_count_
                - this->data_->size();

    }
    ~Complement() {
        delete this->data_;
    }

private:
    void AddRemaining(item_T &, Pointer<item_T> *);
    inline void AddSelfLoop(item_T &self_loop, Pointer<item_T> *pointer) {
        while ((self_loop < pointer->Front())
                || ((self_loop == pointer->Front())
                        && (self_loop < pointer->Back()))) {
            // https://stackoverflow.com/a/28877675/11193802
            /*
             * Brace initializer list cannot be used in most
             * type deduction contexts.
             * If you explicitly specify the type it works
             */
            this->data_->push_back(std::make_shared<T_1D<item_T>>(T_1D<item_T> {
                    self_loop, self_loop }));
            self_loop++;
        }
    }
    void CreateComplementary(Adjacency<item_T> *, Pointer<item_T> *);
    void SetRange();
};

template<typename item_T>
void Complement<item_T>::AddRemaining(item_T &self_loop,
        Pointer<item_T> *pointer) {
    while (pointer->InRange()) {
        this->AddSelfLoop(self_loop, pointer);
        this->data_->push_back(pointer->GetTuple());
        pointer->Advance();
    }
}

template<typename item_T>
void Complement<item_T>::CreateComplementary(Adjacency<item_T> *adj,
        Pointer<item_T> *ut) {
    item_T self_loop = 0;
    adj->Initialize();
    ut->Initialize();
    while (adj->InRange() && ut->InRange()) {
        if (relation::CompareVector(*adj->Get(), *ut->Get()) < 0) {
            this->AddSelfLoop(self_loop, adj);
            this->data_->push_back(adj->GetTuple());
            adj->Advance();
        } else {
            this->AddSelfLoop(self_loop, ut);
            this->data_->push_back(ut->GetTuple());
            ut->Advance();
        }
    }
    this->AddRemaining(self_loop, adj);
    this->AddRemaining(self_loop, ut);
    this->data_->push_back(std::make_shared<T_1D<item_T>>(T_1D<item_T> {
            self_loop, self_loop }));
    assert(self_loop + 1 == this->node_count_);
}

template<typename item_T>
void Complement<item_T>::SetRange() {
    /*
     * binary search in this->data_ (existing edges)
     * for any index of existing edges
     * EdgeTotalOrder(index) + data_->size() - index <= n^2
     *
     * find min index such that
     * EdgeTotalOrder(index) + data_->size() - index == n^2
     * then max_index_ = index
     * max_index_ value range: [0, n^2 - 1]
     *
     * data_[max_index_]: the first edge after the last non-edge
     *
     * total order of non-edge in range [, )
     * [EdgeTotalOrder(max_index_ - 1) + 1, EdgeTotalOrder(max_index_))
     */
    this->max_index_ = 0;
    size_type target = this->node_count_ * this->node_count_
            - this->data_->size();
    size_type tail = this->data_->size();
    size_type middle;
    while (this->max_index_ < tail) {
        middle = this->max_index_ + (tail - this->max_index_) / 2;
        if (this->EdgeTotalOrder(middle) - middle < target) {
            this->max_index_ = middle + 1;
        } else {
            tail = middle;
        }
    }
    /*
     * binary search in this->data_ (existing edges)
     * for any existing edges: EdgeTotalOrder(index) >= index
     * if complete graph, then: EdgeTotalOrder(index) == index
     *
     * find max index, such that EdgeTotalOrder(index) == index
     * then min_index_ = index
     * min_index_: index of the last edge before the first non-edge
     * min_index_ value range: [0, n^2 - 1]
     *
     * property
     * first non-edge
     * FromNode(EdgeTotalOrder(min_index_)+1)
     * ToNode(EdgeTotalOrder(min_index_)+1)
     *
     * can be (n, 0), means no non-edge
     * first edge after non-edge: this->data_->at(min_index_ + 1)
     * can be out of range of this->data_, if no non-edge
     *
     * data[min_index_]: the last edge before the first non-edge
     * min_index_: the total order of this edge
     *
     * total order of non-edges in range [, ):
     * [EdgeTotalOrder(min_index_) + 1, EdgeTotalOrder(min_index_ + 1))
     */
    this->min_index_ = 0;
    tail = this->max_index_;
    while (this->min_index_ < tail) {
        middle = this->min_index_ + (tail - this->min_index_) / 2;
        if (this->EdgeTotalOrder(middle) > middle) {
            tail = middle;
        } else {
            this->min_index_ = middle + 1;
        }
    }
    this->min_index_--;

    // search total order range, used for binary search
    this->min_range_ = this->EdgeTotalOrder(this->min_index_) + 1;
    this->max_range_ = this->EdgeTotalOrder(this->max_index_);
}

}

#endif /* ALGEBRA_STORAGE_RELATION_POINTER_COMPLEMENT_HPP_ */
