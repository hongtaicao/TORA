/*
 * pointer_relation.hpp
 *
 *  Created on: 2020-4-2 11:50
 *      Author: Hongtai Cao
 */

#ifndef ALGEBRA_STORAGE_RELATION_POINTER_RELATION_HPP_
#define ALGEBRA_STORAGE_RELATION_POINTER_RELATION_HPP_

#include <algorithm>
#include <queue>
#include <vector>

#include "algebra/io/filereader.hpp"
#include "algebra/storage/relation/pointer.hpp"

namespace relation_pointer {

template<typename item_T>
class RelationShallowCopy: public Pointer<item_T> {
public:
    RelationShallowCopy(T_tuple_1D<item_T> *data)
            : Pointer<item_T>(data) {
    }
    virtual ~RelationShallowCopy() {
    }

    // pipeline method
    inline T_tuple<item_T> &GetTupleAt(size_type head) override {
        return (*this->data_)[head];
    }
    inline Pointer<item_T> *ShallowCopy() override {
        return new RelationShallowCopy(this->data_);
    }

    // data read
    inline T_1D<item_T> *GetMid(size_type &middle, size_type head,
            size_type tail) override {
        middle = head + (tail - head) / 2;
        return this->GetAt(middle);
    }

    // helper method
    inline size_type GetHead(int offset) override {
        return this->head_ + offset;
    }
    inline size_type MaxRange() override {
        return this->RowSize();
    }
    inline size_type MinRange() override {
        return 0;
    }
    inline void SetHeadCloseNext(size_type head) override {
        this->head_ = head;
    }

    // property method
    inline size_type RowSize() override {
        return this->data_->size();
    }
};

template<typename item_T>
class Relation: public RelationShallowCopy<item_T> {
public:
    Relation()
            : RelationShallowCopy<item_T>(new T_tuple_1D<item_T>) {
    }
    virtual ~Relation() {
        delete this->data_;
    }
};

template<typename item_T>
using EdgeStore = Relation<item_T>;

template<typename item_T>
class Adjacency: public Relation<item_T> {
public:
    Adjacency(const std::string &in_file)
            : Relation<item_T>() {
        this->node_count_ = 0;
        item_T from_node, to_node;
        algebra::FileReader reader(in_file);
        while (reader.Read(from_node, to_node)) {
            item_T max_node = from_node > to_node ? from_node : to_node;
            if (this->node_count_ < max_node) {
                this->node_count_ = max_node;
            }
            this->data_->push_back(std::make_shared<T_1D<item_T>>(T_1D<item_T> {
                    from_node, to_node }));
        }
        // node is labeled from 0. so far this->node_count_ is max_label
        // node count should be max_label + 1
        this->node_count_++;
        std::sort(this->data_->begin(), this->data_->end(), AscendVector());
    }

    inline size_type NodeCount() {
        return this->node_count_;
    }
private:
    size_type node_count_;
};

/*
 * fully store all the non-edges
 * can run out of memory on large sparse graph
 */
template<typename item_T>
class NonEdge: public Relation<item_T> {
public:
    NonEdge(Adjacency<item_T> *adj, Pointer<item_T> *ut)
            : Relation<item_T>() {
        adj->Initialize();
        ut->Initialize();
        size_type max_node = adj->NodeCount();
        for (size_type from_node = 0; from_node < max_node; from_node++) {
            for (size_type to_node = 0; to_node < max_node; to_node++) {
                if (this->MatchEdge(adj, from_node, to_node)) {
                    continue;
                }
                if (this->MatchEdge(ut, from_node, to_node)) {
                    continue;
                }
                if (from_node == to_node) {
                    continue;
                }
                this->PushBack(from_node, to_node);
            }
        }
    }
};

/*
 * Compare parameter is defined such that it returns true if its
 * first argument comes before its second argument in a weak ordering
 *
 * the front of the queue contains the "last" element according to
 * the weak ordering imposed by Compare.
 */
template<typename item_T>
class PointerAscend {
public:
    PointerAscend() {
    }
    inline bool operator()(Pointer<item_T> *left, Pointer<item_T> *right) {
        return (relation::CompareVector(*left->Get(), *right->Get()) > 0);
    }
};

template<typename item_T>
class StorageSum: public Relation<item_T> {
public:
    typedef typename Storage<item_T>::storage_1D_t storage_1D_t;
    StorageSum(storage_1D_t &storage_1D)
            : Relation<item_T>() {
        // each item is already sorted
        // use priority queue to perform sort merge
        std::priority_queue<Pointer<item_T> *, std::vector<Pointer<item_T> *>,
                PointerAscend<item_T>> priorityqueue;
        for (auto &item : storage_1D) {
            Pointer<item_T> *relation =
                    ((Pointer<item_T> *) item)->ShallowCopy();
            if (relation->Initialize() && relation->InRange()) {
                priorityqueue.push(relation);
            }
        }
        while (!priorityqueue.empty()) {
            Pointer<item_T> *relation = priorityqueue.top();
            priorityqueue.pop();
            item_T first = relation->Front();
            item_T second = relation->Element(1);
            item_T count = relation->Back();
            size_type last = this->RowSize();
            if ((last > 0) && (this->FrontAt(last - 1) == first)
                    && (this->ElementAt(last - 1, 1) == second)) {
                // an existing coordinate
                (*this->Get())[2] += count;
            } else {
                // a new coordinate
                this->PushBack(first, second, count);
            }
            // if relation has next, add back to the queue
            relation->Advance();
            if (relation->InRange()) {
                priorityqueue.push(relation);
            } else {
                delete relation;
            }
        }
    }
};

} // namespace relation_pointer

#endif /* ALGEBRA_STORAGE_RELATION_POINTER_RELATION_HPP_ */
